package cn.itcast.picture.ui;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 * 图片的预览区
 * 
 * @author 张弛有度！
 *
 */
public class PicturePreview extends JPanel {
	// 重写绘制组件的方法，显示图片
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		// 指定图片的路径
		String filename = "picture/" + PictureCanvas.pictureID + ".jpg";
		// 通过图片的路径，获取对应的图片中的图像
		ImageIcon icon = new ImageIcon(filename);
		Image image = icon.getImage();
		// 把图像绘制在预览区的面板中
		g.drawImage(image, 20, 20, 450, 600, this);
	}
}