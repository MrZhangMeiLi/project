package cn.itcast.picture.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

public class PictureMainFrame extends JFrame {

	private String[] items = { "小女孩", "女明星", "baby", "来日可期" };
	private PictureCanvas canvas; // 拼图区
	private PicturePreview preview; // 预览区
	private JRadioButton addNumInfo; // 数字提示
	private ButtonGroup buttonGroup;
	private JRadioButton clearNumInfo; // 清除提示
	private JComboBox<String> box; // 下拉框
	private JTextField name; // 名称
	public static JTextField step; // 步数
	private JButton start; // 开始按钮

	// 空参数构造方法
	public PictureMainFrame() {
		init(); // 界面初始化操作
		addCompont(); // 添加组件
		addPreviewImage(); // 添加预览图片和拼图图片
		addActionListener(); // 为组件添加事件监听
	}

	// 为组件添加事件监听
	public void addActionListener() {
		// 数字提示
		addNumInfo.addActionListener(new ActionListener() {
			// 点击时运行的方法
			@Override
			public void actionPerformed(ActionEvent arg0) {
				canvas.reLoadPictureAddNumber();
			}

		});

		// 消除提示
		clearNumInfo.addActionListener(new ActionListener() {
			// 点击时运行的方法
			@Override
			public void actionPerformed(ActionEvent arg0) {
				canvas.reLoadPictureClearNumber();
			}

		});

		// 下拉框
		box.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				// 获取到选择的图片的序号
				int num = box.getSelectedIndex(); // 默认从0开始
				PictureCanvas.pictureID = num + 1;
				// 更新预览区
				preview.repaint(); // 重新绘制预览区界面
				// 更新拼图区
				canvas.reLoadPictureClearNumber();
				// 更新游戏状态区
				name.setText("图片名称：" + box.getSelectedItem()); // 设置图片名称

				int stepNum = PictureCanvas.stepNum = 0; // 游戏步数清零
				step.setText("步数：" + stepNum); // 设置步数显示

				// 按钮区
				clearNumInfo.setSelected(true);
			}
		});

		// 开始按钮
		start.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// 已移动的步数清零
				PictureCanvas.stepNum = 0;
				// 游戏状态区 进行步数的更新
				step.setText("步数：" + PictureCanvas.stepNum);
				// 对小方格进行重新的位置排序 打乱顺序
				canvas.start();

			}
		});

	}

	// 添加预览图片和拼图图片
	public void addPreviewImage() {
		/**
		 * 1.创建一个面板，包含预览区和拼图区 2.把预览图片和拼图图片添加进去 3.显示在主界面中
		 */
		// 创建一个面板，包含预览区和拼图区
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(1, 2));// 设置布局为表格布局
		canvas = new PictureCanvas();
		canvas.setBorder(new TitledBorder("拼图区")); // 添加边框

		preview = new PicturePreview();
		preview.setBorder(new TitledBorder("预览区")); // 添加边框
		/**
		 * 把拼图区与预览区添加到中间面板中
		 */
		panel.add(canvas, BorderLayout.WEST);
		panel.add(preview, BorderLayout.EAST);
		////////////////////
		/**
		 * 3.把面板显示在主界面中
		 */
		this.add(panel, BorderLayout.CENTER);
	}

	// 添加组件方法
	public void addCompont() {
		// 创建用来在主界面上方显示的面板，在面板中要包括含按钮区与游戏状态区
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(1, 2));

		/**
		 * 创建左边按钮区面板
		 */
		JPanel leftPanel = new JPanel();
		// 添加边框
		leftPanel.setBorder(new TitledBorder("按钮区"));
		// 设置背景色
		leftPanel.setBackground(Color.pink);
		// 放在左边

		addNumInfo = new JRadioButton("数字提示", false);
		clearNumInfo = new JRadioButton("清除提示", true);
		buttonGroup = new ButtonGroup();
		box = new JComboBox<String>(items);
		start = new JButton("Start");

		// 添加单选按钮到按钮组中
		buttonGroup.add(addNumInfo);
		buttonGroup.add(clearNumInfo);
		// 设置背景色
		addNumInfo.setBackground(Color.pink);
		clearNumInfo.setBackground(Color.pink);
		start.setBackground(Color.pink);
		// 添加组件到面板中
		leftPanel.add(addNumInfo);
		leftPanel.add(clearNumInfo);
		leftPanel.add(new JLabel("            选择图片： "));
		leftPanel.add(box);
		leftPanel.add(start);

		panel.add(leftPanel, BorderLayout.WEST);

		///////////////////////////////////////////////////////////////////////////////////////////

		/**
		 * 创建右边游戏状态区面板
		 */
		JPanel rightPanel = new JPanel();
		// 添加边框
		rightPanel.setBorder(new TitledBorder("游戏状态"));
		// 设置背景色
		rightPanel.setBackground(Color.pink);

		rightPanel.setLayout(new GridLayout(1, 2)); // 设置布局为表格
		name = new JTextField("图片名称：小女孩儿");
		step = new JTextField("步数：0");

		// 设置文本框不能编辑
		name.setEditable(false);
		step.setEditable(false);

		// 把组件添加到游戏状态面板中
		rightPanel.add(name, BorderLayout.WEST);
		rightPanel.add(step, BorderLayout.EAST);

		// 添加画布到右边
		panel.add(rightPanel, BorderLayout.EAST);
		/////////////////////////////////////////////
		// 设置panel 在界面的上方显示
		this.add(panel, BorderLayout.NORTH);
	}

	/**
	 * 界面初始化方法
	 */
	public void init() {
		// 设置窗口的标题
		this.setTitle("拼图游戏");
		// 设置窗体的大小
		this.setSize(1000, 720);
		// 设置窗口的显示位置
		this.setLocation(180, 10);
		// 设置窗体大小固定
		this.setResizable(false);
		// 设置默认程序关闭操作
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
