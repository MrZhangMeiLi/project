(function() {
	var A = {};
	A.registControl = $.Base.Event.extend({
		init: function(B) {
			$.extend(this, {
				panel: null
			}, B);
			$.extend(this, B);
			this.setOptions();
			this.bindEvent();
			this.clause();
		},
		setOptions: function() {
			this.phonePanel = this.panel.find("#regPhonePanel");
			this.mailPanel = this.panel.find("#regMailPanel");
			this.switchTab = this.panel.find(".zc_tab a");
			this.activityTipUrl = this.panel.find("#registerActivity").data("url");
			this.activityName = this.panel.find(".gift");
			this.activityRule = this.panel.find(".ruleout");
			this.activityLimt = this.panel.find("#activityLimit");
			this.activityRuleClose = this.activityRule.find(".closeout span");
			new A.phoneRegist({
				panel: this.phonePanel
			});
			new A.mailRegist({
				panel: this.mailPanel
			});
		},
		bindEvent: function() {
			var B = this;
			this.switchTab.bind("click", function() {
				var C = $(this).index();
				$(this).addClass("on").siblings().removeClass("on");
				if (C == 0) {
					B.mailPanel.hide();
					B.phonePanel.fadeIn(500);
				} else {
					B.phonePanel.hide();
					B.mailPanel.fadeIn(500);
				}
			});
			$(".yzm_a").bind("click", function() {
				$(".yzm_img").attr("src", $(this).data("url") + Math.random());
			});
			$$.ajax({
				type: "get",
				url: B.activityTipUrl,
				success: function(C) {
					if (C) {
						B.activityName.show();
						B.activityName.find("#activityName").html(C.activityName);
						if (C.activityLimit) {
							B.activityLimt.html(C.activityLimit.replace(/↵↵/g, "<br />").replace(/\n/g, "<br />"));
							B.activityRule.show();
							B.activityName.hover(function() {
								B.activityRule.show();
							}, function() {
								B.activityRule.hide();
							});
							B.activityRule.hover(function() {
								B.activityRule.show();
							}, function() {
								B.activityRule.hide();
							});
						} else {
							B.activityRule.hide();
						}
						B.activityRuleClose.bind("click", function() {
							B.activityRule.hide();
						});
					}
				}
			});
		},
		clause: function() {
			var B = $("#tos_wrap");
			$(".clause").bind("click", function() {
				B.mask();
			});
			$("#tos_sub,.exit").bind("click", function() {
				B.unmask();
			});
		}
	});
	A.phoneRegist = $.Base.Event.extend({
		init: function(B) {
			$.extend(this, {
				panel: null,
				regType: 0
			}, B);
			$.extend(this, B);
			this.setOptions();
			this.bindEvent();
		},
		setOptions: function() {
			this.phoneInputs = this.panel.find("input");
			this.btnSendSmsCode = this.panel.find("#btnSendSmsCode");
			this.isAgree = this.panel.find("#ckbPhone");
			this.errorPanel = this.panel.find(".err");
			this.submitBtn = this.panel.find("#regPhoneBtn");
			this.SendSmsTimer = false;
			this.sendRegCodeTimes = 60;
			this.regPhoneCode = /(^1\d{10}$)/;
			this.sendBtnState = false;
		},
		bindEvent: function() {
			var B = this;
			this.isAgree.bind("click", function() {
				if (this.checked) {
					B.removeError();
				}
			});
			this.phoneInputs.each(function(C) {
				if (C < B.phoneInputs.length - 1) {
					$(this).bind({
						"blur": function() {
							B.checkForm(B.phoneInputs.eq(C), C, true);
						},
						"keyup": function() {
							B.checkForm(B.phoneInputs.eq(C), C);
						}
					});
				}
			});
			this.submitBtn.bind("click", function() {
				var C = $(this).data("success");
				if ($(this).hasClass("loading")) {
					return;
				}
				if (!B.validation()) {
					return false;
				}
				$(this).addClass("loading");
				B.Loading(true);
				var D = B.getPhoneData();
				$$.ajax({
					url: $(this).data("url"),
					type: "post",
					dataType: "json",
					data: D,
					success: function(E) {
						if (!E) {
							B.ErrMessOpt("未知的服务端错误，请您重试");
						} else {
							if (E.code == 0) {
								window.location.href = C;
							} else {
								B.ErrMessOpt(E.messageText);
								B.submitBtn.removeClass("loading");
								B.Loading(false);
								$(".yzm_a").click();
							}
						}
					}
				});
			});
		},
		sendSmsCode: function() {
			var B = this;
			B.btnSendSmsCode.unbind("click").bind("click", function() {
				if ($(this).attr("sendFlag") == "T") {
					return false;
				}
				$(this).attr("sendFlag", "T");
				$$.ajax({
					url: $(this).data("url"),
					type: "post",
					dataType: "json",
					data: {
						"phone": B.phoneInputs.eq(0).val(),
						"code": $("#CheckCode1").val()
					},
					success: function(C) {
						if (+C.code == 0) {
							B.autoTime();
						} else {
							B.ErrMessOpt(C.messageText);
							B.btnSendSmsCode.removeAttr("sendFlag");
							$(".yzm_a").click();
						}
					}
				});
			});
		},
		Loading: function(C) {
			var B = this;
			if (C) {
				B.submitBtn.css("position", "relative").css("opacity", "0.7");
				B.submitBtn.html("正在提交数据");
				var E = B.submitBtn.find("span").eq(0);
				if (!E.length) {
					B.submitBtn.append("<span><span>");
					E = B.submitBtn.find("span").eq(0);
					E.css({
						position: "absolute",
						display: "block",
						height: "40px",
						"line-height": "35px",
						width: "50px",
						right: "20%",
						top: "0px",
						"font-size": "24px"
					});
				}
				var D = ".";
				this.loadingTimer = setInterval(function() {
					if (D.length > 3) {
						D = ".";
					}
					E.html(D);
					D += ".";
				}, 500);
			} else {
				clearInterval(this.loadingTimer);
				B.submitBtn.removeAttr("style");
				B.submitBtn.html("注册");
			}
		},
		validation: function() {
			var C = true;
			for (var B = 0; B < this.phoneInputs.length; B++) {
				C = C && this.checkForm($(this.phoneInputs[B]), B);
			}
			return C;
		},
		checkPhone: function() {
			var B = this;
			$$.ajax({
				url: B.phoneInputs.eq(0).data("checkphoneurl"),
				type: "post",
				dataType: "json",
				data: {
					"name": B.phoneInputs.eq(0).val()
				},
				success: function(C) {
					if (+C.code != 0) {
						B.showError(B.phoneInputs.eq(0));
						B.ErrMessOpt(C.messageText);
					} else {
						B.sendSmsCode();
					}
				}
			});
		},
		ErrMessOpt: function(B) {
			var C = this;
			C.errorPanel.html(B + "<i></i>");
			C.errorPanel.fadeIn("fast");
		},
		checkForm: function(F, E, D) {
			var C = true,
				B = this;
			switch (E) {
			case 0:
				if (!this.regPhoneCode.test(F.val())) {
					B.showError(F);
					B.ErrMessOpt("请填写正确的手机号码");
					C = false;
				} else {
					B.removeError();
					if (D) {
						B.checkPhone();
					}
				}
				break;
			case 1:
				if ( !! $("#CheckCode1").val() && $("#CheckCode1").val().length == 4) {
					if (!this.btnSendSmsCode.hasClass("disabled")) {
						this.btnSendSmsCode.removeClass("yzm_phoneDisEnable hui");
						this.btnSendSmsCode.addClass("yzm_phone");
					}
					B.removeError();
				} else {
					this.btnSendSmsCode.addClass("yzm_phoneDisEnable hui");
					B.showError(F);
					B.ErrMessOpt("请填写验证码");
					C = false;
				}
				break;
			case 2:
				if (F == null || F.val == "" || F.val().length < 1) {
					B.showError(F);
					B.ErrMessOpt("请填写密码");
					C = false;
				} else {
					C = true;
					B.removeError();
				}
				break;
			case 3:
				if (8 > F.val().length || F.val().length > 16) {
					B.showError(F);
					B.ErrMessOpt("密码长度必须在8-16个字符之间");
					C = false;
				} else {
					C = true;
					B.removeError();
				}
				break;
			case 4:
				if (B.phoneInputs.eq(E - 1).val() != F.val()) {
					B.ErrMessOpt("两次输入密码不一致");
					B.showError(F);
					C = false;
				} else {
					B.removeError();
				}
				break;
			case 5:
				if (!B.isAgree.is(":checked")) {
					B.ErrMessOpt("请勾选接受服务条款");
					C = false;
				} else {
					B.removeError();
				}
				break;
			}
			return C;
		},
		autoTime: function() {
			var B = this;
			this.btnSendSmsCode.addClass("yzm_phoneDisEnable hui disabled");
			var C = this.sendRegCodeTimes;
			this.btnSendSmsCode.html(C + "秒后重新获取");
			sendClock = setInterval(function() {
				C--;
				B.btnSendSmsCode.html(C + "秒后重新获取");
				if (C <= 0) {
					B.btnSendSmsCode.removeClass("yzm_phoneDisEnable hui disabled");
					B.btnSendSmsCode.html("获取验证码");
					B.btnSendSmsCode.removeAttr("sendFlag");
					clearInterval(sendClock);
				}
			}, 1000);
		},
		showError: function(B) {
			this.phoneInputs.removeClass("onerror");
			B.addClass("onerror");
		},
		removeError: function() {
			this.errorPanel.fadeOut("fast");
			this.phoneInputs.removeClass("onerror");
		},
		getPhoneData: function() {
			var B = this;
			return {
				"RegPhone": B.phoneInputs.eq(0).val(),
				"CheckCode": $("#ValidatorCode").val(),
				"RegistPassword": $("#RegistPasswordPhone").val(),
				"ConfirmPassword": $("#ConfirmPasswordPhone").val(),
				"RegFlag": B.regType
			};
		}
	});
	A.mailRegist = $.Base.Event.extend({
		init: function(B) {
			$.extend(this, {
				panel: null,
				regType: 3
			}, B);
			$.extend(this, B);
			this.setOptions();
			this.bindEvent();
		},
		setOptions: function() {
			this.checkFlag = true;
			this.errorPanel = this.panel.find(".err");
			this.regMail = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
			this.mailInputs = this.panel.find("input");
			this.mailSubmit = this.panel.find("#regEmailBtn");
			this.isAgree = this.panel.find("#ckbEmail");
			this.changeImgbtn = this.panel.find("#changepic_btn");
		},
		bindEvent: function() {
			var B = this;
			if (B.mailInputs && B.mailInputs.length > 0) {
				B.mailInputs.each(function(D, C) {
					if (D < B.mailInputs.length - 1) {
						$(this).bind({
							"blur": function() {
								B.checkFlag = B.checkForm($(this), D, true);
							},
							"keyup": function() {
								B.checkFlag = B.checkForm($(this), D);
							}
						});
					}
				});
			}
			this.isAgree.bind("click", function() {
				if (this.checked) {
					B.removeError();
				}
			});
			B.mailSubmit.bind("click", function() {
				var C = $(this).data("url"),
					E = $(this).data("success");
				if ($(this).hasClass("loading")) {
					return;
				}
				if (!B.validation()) {
					return;
				}
				$(this).addClass("loading");
				B.Loading(true);
				var D = B.getEmailData();
				$$.ajax({
					url: C,
					type: "post",
					dataType: "json",
					data: D,
					success: function(F) {
						if (!F) {
							B.ErrMessOpt("未知的服务端错误，请您重试");
						} else {
							if (F.code == 0) {
								window.location.href = E;
							} else {
								B.ErrMessOpt(F.messageText);
								B.mailSubmit.removeClass("loading");
								B.Loading(false);
								$(".yzm_a").click();
							}
						}
					}
				});
			});
		},
		validation: function() {
			var C = true;
			for (var B = 0; B < this.mailInputs.length; B++) {
				C = C && this.checkForm($(this.mailInputs[B]), B);
			}
			return C;
		},
		Loading: function(C) {
			var B = this;
			if (C) {
				B.mailSubmit.css("position", "relative").css("opacity", "0.7");
				B.mailSubmit.html("正在提交数据");
				var E = B.mailSubmit.find("span").eq(0);
				if (!E.length) {
					B.mailSubmit.append("<span><span>");
					E = B.mailSubmit.find("span").eq(0);
					E.css({
						position: "absolute",
						display: "block",
						height: "40px",
						"line-height": "35px",
						width: "50px",
						right: "20%",
						top: "0px",
						"font-size": "24px"
					});
				}
				var D = ".";
				this.loadingTimer = setInterval(function() {
					if (D.length > 3) {
						D = ".";
					}
					E.html(D);
					D += ".";
				}, 500);
			} else {
				clearInterval(this.loadingTimer);
				B.mailSubmit.removeAttr("style");
				B.mailSubmit.html("注册");
			}
		},
		checkEmail: function(C) {
			var B = this;
			$$.ajax({
				url: C.data("checkphoneurl"),
				type: "post",
				dataType: "json",
				data: {
					"name": C.val()
				},
				success: function(D) {
					if (!D) {
						B.ErrMessOpt("未知的服务端错误，请您重试");
					} else {
						if (D.code == 0) {} else {
							B.ErrMessOpt(D.messageText);
							B.showError(C);
						}
					}
				}
			});
		},
		ErrMessOpt: function(B) {
			var C = this;
			C.errorPanel.html(B + "<i></i>");
			C.errorPanel.fadeIn("fast");
		},
		checkForm: function(F, C, E) {
			var B = this;
			var D = true;
			switch (C) {
			case 0:
				if (B.regMail.test(F.val())) {
					B.removeError();
					if (E) {
						B.checkEmail(F);
					}
				} else {
					B.ErrMessOpt("请填写正确的邮箱地址");
					B.showError(F);
					D = false;
				}
				break;
			case 1:
				if (8 > F.val().length || F.val().length > 16) {
					B.ErrMessOpt("密码长度必须在8-16个字符之间");
					B.showError(F);
					D = false;
				} else {
					B.removeError();
				}
				break;
			case 2:
				if (B.mailInputs.eq(C - 1).val() != F.val()) {
					B.ErrMessOpt("两次输入密码不一致");
					B.showError(F);
					D = false;
				} else {
					B.removeError();
				}
				break;
			case 3:
				if (F == null || F.val == "" || F.val().length < 1) {
					B.ErrMessOpt("请填写验证码");
					B.showError(F);
					D = false;
				} else {
					B.removeError();
				}
				break;
			case 4:
				if (!B.isAgree.is(":checked")) {
					B.ErrMessOpt("请勾选接受服务条款");
					D = false;
				} else {
					B.removeError();
				}
				break;
			}
			return D;
		},
		showError: function(B) {
			this.mailInputs.removeClass("onerror");
			B.addClass("onerror");
		},
		removeError: function() {
			this.errorPanel.fadeOut("fast");
			this.mailInputs.removeClass("onerror");
		},
		getEmailData: function() {
			var B = this;
			return {
				"RegEmail": B.mailInputs.eq(0).val(),
				"RegistPassword": B.mailInputs.eq(1).val(),
				"ConfirmPassword": B.mailInputs.eq(2).val(),
				"CheckCode": B.mailInputs.eq(3).val(),
				"RegFlag": B.regType
			};
		}
	});
	$(document).ready(function() {
		new A.registControl({
			panel: $("#contentBox")
		});
	});
})();