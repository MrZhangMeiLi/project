(function (i, s, o, g, r, a, m) {
    i['GoogleAnalyticsObject'] = r; i[r] = i[r] || function () {
        (i[r].q = i[r].q || []).push(arguments)
    }, i[r].l = 1 * new Date(); a = s.createElement(o),
  m = s.getElementsByTagName(o)[0]; a.async = 1; a.src = g; m.parentNode.insertBefore(a, m)
})(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

if ($("body").hasClass("ch")) {
    ga('create', 'UA-54697886-1', 'auto');
    ga('create', 'UA-54697886-3', 'auto', { 'name': 'lang' });
    ga('require', 'displayfeatures');
    ga('lang.require', 'displayfeatures');
    ga('send', 'pageview');
    ga('lang.send', 'pageview');
} else {
    ga('create', 'UA-19705401-1', queryDomain.SLD);
    ga('send', 'pageview');
}


/*
* the initail mod ga
* @Author:      dingyantao
* @CreateDate:  2014-01-14
*/
(function ($) {
    var GAControl = function (pObj) {
        this.dataTag = {
            Event: "event",
            Category: "category",
            Done: "done",
            Tag: "tag"
        };
        this.target = $(pObj);
        this.init();
    }
    GAControl.prototype = {
        init: function () {
            this.setOptions();
        },
        setOptions: function () {
            for (var key in this.dataTag) {
                this[key] = this.target.data(this.dataTag[key]);
            };
            window.ga('send', this.Event, this.Category, this.Done, this.Tag);
        }
    }
    $(document).ready(function () {
        if (window.ga !== undefined && window.ga !== null) {
            $("[data-role='ga']").live("click", function () {
                new GAControl(this);
            });
        }
    });
})(jQuery);