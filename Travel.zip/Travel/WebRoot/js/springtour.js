!
function() {
	var t = window,
		e = t.Spring ||
	function(t) {
		return t instanceof e ? t : this instanceof e ? void(this._wrapped = t) : new e(t)
	};
	t.Spring = e
}(), function() {
	function accAdd(t, e) {
		var n, i, r, a;
		try {
			n = t.toString().split(".")[1].length
		} catch (s) {
			n = 0
		}
		try {
			i = e.toString().split(".")[1].length
		} catch (s) {
			i = 0
		}
		if (a = Math.abs(n - i), r = Math.pow(10, Math.max(n, i)), 0 < a) {
			var o = Math.pow(10, a);
			i < n ? (t = Number(t.toString().replace(".", "")), e = Number(e.toString().replace(".", "")) * o) : (t = Number(t.toString().replace(".", "")) * o, e = Number(e.toString().replace(".", "")))
		} else t = Number(t.toString().replace(".", "")), e = Number(e.toString().replace(".", ""));
		return (t + e) / r
	}

	function accSub(t, e) {
		var n, i, r;
		try {
			n = t.toString().split(".")[1].length
		} catch (a) {
			n = 0
		}
		try {
			i = e.toString().split(".")[1].length
		} catch (a) {
			i = 0
		}
		return ((t * (r = Math.pow(10, Math.max(n, i))) - e * r) / r).toFixed(i <= n ? n : i) - 0
	}

	function accMul(t, e) {
		var n = 0,
			i = t.toString(),
			r = e.toString();
		try {
			n += i.split(".")[1].length
		} catch (a) {}
		try {
			n += r.split(".")[1].length
		} catch (a) {}
		return Number(i.replace(".", "")) * Number(r.replace(".", "")) / Math.pow(10, n)
	}
	Number.prototype.div = function(t) {
		return accDiv(this, t)
	}, Number.prototype.mul = function(t) {
		return accMul(this, t)
	}, Number.prototype.sub = function(t) {
		return accSub(this, t)
	}, Number.prototype.add = function(t) {
		return accAdd(this, t)
	}
}(), function() {
	if (!Array.prototype.find) try {
		Object.defineProperty(Array.prototype, "find", {
			value: function(t) {
				if (null == this) throw new TypeError("Array.prototype.find called on null or undefined");
				if ("function" != typeof t) throw new TypeError("predicate must be a function");
				for (var e, n = Object(this), i = n.length >>> 0, r = arguments[1], a = 0; a < i; a++) if (e = n[a], t.call(r, e, a, n)) return e;
				return undefined
			}
		})
	} catch (t) {}
	Array.prototype.indexOf || (Array.prototype.indexOf = function(t, e) {
		var n;
		if (null == this) throw new TypeError('"this" is null or not defined');
		var i = Object(this),
			r = i.length >>> 0;
		if (0 === r) return -1;
		var a = +e || 0;
		if (Math.abs(a) === Infinity && (a = 0), r <= a) return -1;
		for (n = Math.max(0 <= a ? a : r - Math.abs(a), 0); n < r;) {
			if (n in i && i[n] === t) return n;
			n++
		}
		return -1
	}), Array.prototype.forEach || (Array.prototype.forEach = function(t) {
		var e = this.length;
		if ("function" != typeof t) throw new TypeError;
		for (var n = arguments[1], i = 0; i < e; i++) i in this && t.call(n, this[i], i, this)
	}), String.prototype.replaceWith || (String.prototype.replaceWith = function(n) {
		return this.replace(/\{\$(\w+)\}/g, function(t, e) {
			return e in n ? n[e] : t
		})
	}), String.prototype.toPrice || (String.prototype.toPrice = function(t, e) {
		e = e || "ceil";
		var n = this.toString();
		t = t || 1;
		var i = n.split(".");
		if (-1 < n.indexOf(".")) {
			var r = Math.pow(10, t);
			1 < i.length && i[1].length > t && (n = Math[e](n * r) / r), n = (n - 0).toFixed(t)
		}
		return n
	}), Spring._unique = function(t) {
		if ("function" != typeof Array.from) {
			for (var e = [], n = 0, i = t.length; n < i; n++) {
				for (var r = n + 1; r < i; r++) t[n].toLocaleLowerCase() === t[r].toLocaleLowerCase() && (r = ++n);
				t[n] && e.push(t[n])
			}
			return e
		}
		return Array.from(new Set(t))
	}, String.prototype.toInt = function() {
		return ~~this
	}, String.prototype.isDate = function() {
		var t = this.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
		if (t) {
			var e = t[1].toInt(),
				n = t[2].toInt() - 1,
				i = t[3].toInt(),
				r = new Date(e, n, i);
			if (r.getFullYear() == e && r.getMonth() == n && r.getDate() == i) return !0
		}
		return !1
	}, String.prototype.toDate = function() {
		var t = this.match(/^(\d{4})-(\d{1,2})-(\d{1,2})( \d{1,2}:\d{1,2}:\d{1,2}(\.\d+)?)?$/);
		if (t) {
			var e = t[1].toInt(),
				n = t[2].toInt() - 1,
				i = t[3].toInt(),
				r = new Date(e, n, i);
			if (r.getFullYear() == e && r.getMonth() == n && r.getDate() == i) return r
		}
		return null
	};
	var g, m, y, v, S = (g = /d{1,4}|m{1,4}|yy(?:yy)?|([HhMsTt])\1?|[LloSZ]|"[^"]*"|'[^']*'/g, m = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g, y = /[^-+\dA-Z]/g, v = function(t, e) {
		for (t = String(t), e = e || 2; t.length < e;) t = "0" + t;
		return t
	}, function(t, e, n) {
		var i = S;
		1 != arguments.length || "[object String]" != Object.prototype.toString.call(t) || /\d/.test(t) || (e = t, t = undefined), t = t ? new Date(t) : new Date, "UTC:" == (e = String(i.masks[e] || e || i.masks["default"])).slice(0, 4) && (e = e.slice(4), n = !0);
		var r = n ? "getUTC" : "get",
			a = t[r + "Date"](),
			o = t[r + "Day"](),
			s = t[r + "Month"](),
			c = t[r + "FullYear"](),
			u = t[r + "Hours"](),
			l = t[r + "Minutes"](),
			f = t[r + "Seconds"](),
			p = t[r + "Milliseconds"](),
			h = n ? 0 : t.getTimezoneOffset(),
			d = {
				d: a,
				dd: v(a),
				ddd: i.i18n.dayNames[o],
				dddd: i.i18n.dayNames[o + 7],
				m: s + 1,
				mm: v(s + 1),
				mmm: i.i18n.monthNames[s],
				mmmm: i.i18n.monthNames[s + 12],
				yy: String(c).slice(2),
				yyyy: c,
				h: u % 12 || 12,
				hh: v(u % 12 || 12),
				H: u,
				HH: v(u),
				M: l,
				MM: v(l),
				s: f,
				ss: v(f),
				l: v(p, 3),
				L: v(99 < p ? Math.round(p / 10) : p),
				t: u < 12 ? "a" : "p",
				tt: u < 12 ? "am" : "pm",
				T: u < 12 ? "A" : "P",
				TT: u < 12 ? "AM" : "PM",
				Z: n ? "UTC" : (String(t).match(m) || [""]).pop().replace(y, ""),
				o: (0 < h ? "-" : "+") + v(100 * Math.floor(Math.abs(h) / 60) + Math.abs(h) % 60, 4),
				S: ["th", "st", "nd", "rd"][3 < a % 10 ? 0 : (a % 100 - a % 10 != 10) * a % 10]
			};
		return e.replace(g, function(t) {
			return t in d ? d[t] : t.slice(1, t.length - 1)
		})
	});
	S.masks = {
		"default": "ddd mmm dd yyyy HH:MM:ss",
		shortDate: "m/d/yy",
		mediumDate: "mmm d, yyyy",
		longDate: "mmmm d, yyyy",
		fullDate: "dddd, mmmm d, yyyy",
		shortTime: "h:MM TT",
		mediumTime: "h:MM:ss TT",
		longTime: "h:MM:ss TT Z",
		isoDate: "yyyy-mm-dd",
		isoTime: "HH:MM:ss",
		isoDateTime: "yyyy-mm-dd'T'HH:MM:ss",
		isoUtcDateTime: "UTC:yyyy-mm-dd'T'HH:MM:ss'Z'"
	}, S.i18n = {
		dayNames: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
		monthNames: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
	}, Date.prototype.format = function(t, e) {
		return S(this, t, e)
	}
}(), function() {
	var h = Spring.forEach = function(t, e, n) {
			if (null == t) return t;
			if (s && t.forEach === s) t.forEach(e, n);
			else if (t.length === +t.length) {
				for (var i = 0, r = t.length; i < r; i++) if (e.call(n, t[i], i, t) === o) return
			} else {
				var a = a(t);
				for (i = 0, r = a.length; i < r; i++) if (e.call(n, t[a[i]], a[i], t) === o) return
			}
			return t
		};
	Spring.template = function(a, t, e) {
		var n;
		e = function(n) {
			return h(u.call(arguments, 1), function(t) {
				if (t) for (var e in t) void 0 === n[e] && (n[e] = t[e])
			}), n
		}({}, e, Spring.templateSettings);
		var i = new RegExp([(e.escape || l).source, (e.interpolate || l).source, (e.evaluate || l).source].join("|") + "|$", "g"),
			o = 0,
			s = "__p+='";
		a && a.replace(i, function(t, e, n, i, r) {
			return s += a.slice(o, r).replace(p, function(t) {
				return "\\" + f[t]
			}), e && (s += "'+\n((__t=(" + e + "))==null?'':_.escape(__t))+\n'"), n && (s += "'+\n((__t=(" + n + "))==null?'':__t)+\n'"), i && (s += "';\n" + i + "\n__p+='"), o = r + t.length, t
		}), s += "';\n", e.variable || (s = "if(data){\n" + s + "}\n"), s = "var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};\n" + s + "return __p;\n";
		try {
			n = new Function(e.variable || "data", "_", s)
		} catch (c) {
			throw c.source = s, c
		}
		if (t) return n(t, Spring);
		var r = function(t) {
				return n.call(this, t, Spring)
			};
		return r.source = "function(" + (e.variable || "data") + "){\n" + s + "}", r
	}, Spring.template.render = function(t, i) {
		return t.replace(/\%\{.*?\}/g, function(t, e) {
			var n = t.replace(/\%|\{|\}/g, "");
			return i.hasOwnProperty(n) ? i[n] : t
		})
	}
}(), function(t) {
	var s = {
		checkObject: function(t, e) {
			var n = "[object " + e + "]";
			return Object.prototype.toString.call(t) == n
		},
		urlParam: function(t, e) {
			e = e || !1;
			var n = window.location.href;
			e && (t = t.toLocaleLowerCase(), n = n.toLocaleLowerCase());
			var i = new RegExp(t + "=([^&#]*)"),
				r = n.match(i);
			return null != r ? decodeURI(r[1]) : null
		},
		isEmptyObject: function(t) {
			var e = !0;
			for (var n in t) {
				e = !1;
				break
			}
			return e
		},
		trim: function(t) {
			if ("" != t && t) {
				for (var e = (t = t.replace(/^(\s| )+/, "")).length - 1; 0 <= e; e--) if (/\S/.test(t.charAt(e))) {
					t = t.substring(0, e + 1);
					break
				}
				return t
			}
			return t
		},
		clearTag: function(t) {
			if (t && "" != t) return t = (t = (t = t.replace(/<\/?[^>]*>/g, "")).replace(/[ | ]*\n/g, "\n")).replace(/\n[\s| | ]*\r/g, "\n")
		},
		filterStrFormat: function(t) {
			return '"' === (t = (t = (t = (t = '"' + t + '"').replace(/^\s+/, "").replace(/\s+$/, "")).replace(/<\s?(br).*?>/g, "\\n")).replace(/<\/?[^>]*>/g, "")).substr(0, 1) && '"' === t.substr(-1, 1) && (t = (t = (t = t.replace(/\n/g, "\\n").replace(/\r/g, "").replace(/\t/g, "\\t")).replace(/\"/g, "")).replace(/\\n/g, "<br />")), t
		},
		jsonToString: function(t) {
			var e = navigator.userAgent;
			if (250 < e.length && (e = e.substring(0, 250)), !(e = e.toLowerCase()).match(/(msie\s|trident.*rv:)([\w.]+)/)) return JSON.stringify(t);
			var n = $.type(t);
			switch ("object" == n && (n = Array == t.constructor ? "array" : RegExp == t.constructor ? "regexp" : "object"), n) {
			case "undefined":
			case "unknown":
				return;
			case "function":
			case "boolean":
			case "regexp":
				return t.toString();
			case "number":
				return isFinite(t) ? t.toString() : "null";
			case "string":
				return '"' + t.replace(/(\\|\")/g, "\\$1").replace(/\n|\r|\t/g, function() {
					var t = arguments[0];
					return "\n" == t ? "\\n" : "\r" == t ? "\\r" : "\t" == t ? "\\t" : ""
				}) + '"';
			case "object":
				if (null === t) return "null";
				var i = [];
				for (var r in t) {
					(o = s.jsonToString(t[r])) !== undefined && i.push(s.jsonToString(r) + ":" + o)
				}
				return "{" + i.join(",") + "}";
			case "array":
				i = [];
				for (var a = 0; a < t.length; a++) {
					var o;
					(o = s.jsonToString(t[a])) !== undefined && i.push(o)
				}
				return "[" + i.join(",") + "]"
			}
		},
		parseJSON: function(t) {
			return "undefined" != typeof JSON && JSON.stringify && JSON.parse ? JSON.parse(t) : $.parseJSON(t)
		},
		isClass: function(t) {
			return null === t ? "Null" : t === undefined ? "Undefined" : Object.prototype.toString.call(t).slice(8, -1)
		},
		loadJSandStyle: function(t, e, n) {
			var i = document.createElement(t),
				r = document.getElementsByTagName(t)[0];
			i.async = 1, i.src = e, "link" === t && (i.href = e), i.onload = i.onreadystatechange = function() {
				this.readyState && "loaded" !== this.readyState && "complete" !== this.readyState || ("function" == typeof n && n(), this.onload = this.onreadystatechange = null, this.parentNode.removeChild(this))
			}, r.parentNode.insertBefore(i, r)
		}
	};
	s.browser = new function() {
		var n = {
			Chrome: {
				Reg: /.*(chrome)\/([\w.]+).*/,
				Core: "Webkit"
			},
			Firefox: {
				Reg: /.*(firefox)\/([\w.]+).*/,
				Core: "Moz"
			},
			Opera: {
				Reg: /(opera).+version\/([\w.]+)/,
				Core: "O"
			},
			Safari: {
				Reg: /.*version\/([\w.]+).*(safari).*/,
				Core: "Webkit"
			},
			Ie: {
				Reg: /.*(msie) ([\w.]+).*/,
				Core: "Ms"
			}
		},
			i = navigator.userAgent.toLowerCase();
		this.Detail = function() {
			for (var t in n) {
				var e = n[t].Reg.exec(i);
				if (null != e) return {
					Browser: e[1] || "",
					Version: e[2] || "0",
					Core: n[t].Core
				}
			}
			return {
				Browser: "UNKNOWN",
				Version: "UNKNOWN",
				Core: "UNKNOWN"
			}
		}(), this.IsChrome = n.Chrome.Reg.test(i), this.IsFirefox = n.Firefox.Reg.test(i), this.IsOpera = n.Opera.Reg.test(i), this.IsSafari = n.Safari.Reg.test(i), this.IsIE = n.Ie.Reg.test(i), this.IsIE6 = /msie 6.0/.test(i), this.IsIE7 = /msie 7.0/.test(i), this.IsIE8 = /msie 8.0/.test(i), this.IsIE10 = /msie 10.0/.test(i), this.IsIpad = /ipad/.test(i)
	}, t.utils = s
}(Spring), function(t) {
	var n, e = t.storeApi || {},
		i = window,
		r = i.document,
		a = "localStorage",
		o = "globalStorage";
	e.isOpen = !0;
	try {
		a in i && i[a] ? (n = i[a], e.set = function(t, e) {
			n.setItem(t, e)
		}, e.get = function(t) {
			return n.getItem(t)
		}, e.remove = function(t) {
			n.removeItem(t)
		}, e.clear = function() {
			n.clear()
		}) : o in i && i[o] ? (n = i[o][i.location.hostname], e.set = function(t, e) {
			n[t] = e
		}, e.get = function(t) {
			return n[t] && n[t].value
		}, e.remove = function(t) {
			delete n[t]
		}, e.clear = function() {
			for (var t in n) delete n[t]
		}) : r.documentElement.addBehavior
	} catch (s) {
		e.set = function(t, e) {}, e.get = function(t) {}, e.remove = function(t) {}, e.clear = function() {}
	}
	t.storeApi = e
}(Spring), function(nameSpace) {
	var _utils = nameSpace.utils || {};
	nameSpace.getLocalData = function(t) {
		var e = Spring.storeApi.get(t);
		return e && (e = nameSpace.utils.parseJSON(e)), e
	}, nameSpace.setLocalData = function(t, e) {
		if (e) {
			var n = Spring.storeApi;
			"string" != typeof e && (e = nameSpace.utils.jsonToString(e)), n.set(t, e)
		}
	}, nameSpace.ajax = function(t) {
		var e = $.extend({}, {}, t);
		if (nameSpace.config.sign) {
			var n = _sha._setDataSign(e.url, e.data);
			e.url = n.url, n.data && (e.data = n.data)
		}
		return $.ajax(e)
	}, nameSpace.get = function(t, e, n, i) {
		_sha._getAjaxType(t, e, n, i, "get")
	}, nameSpace.post = function(t, e, n, i) {
		_sha._getAjaxType(t, e, n, i, "post")
	};
	var _sha = {
		_getAjaxType: function(t, e, n, i, r) {
			if ("function" == typeof e && (i = i || n ? n : "json", n = e, e = {}), nameSpace.config.sign) {
				var a = _sha._setDataSign(t, e);
				t = a.url, a.data && (e = a.data)
			}
			return r = r || "get", $.ajax({
				url: t,
				type: r,
				dataType: i,
				data: e,
				success: n
			})
		},
		_setDataSign: function(t, e) {
			var n = "",
				i = _sha._resetData(t, e);
			if (!_utils.isEmptyObject(i)) if (n = _sha._getSign(i), _utils.isEmptyObject(e)) t += "&springsign=" + n;
			else if ("string" == typeof e) try {
				(e = $.parseJSON(e)).springsign = n, e = _utils.jsonToString(e)
			} catch (r) {
				1 < e.split("&") && (e += "&springsign=" + n)
			} else "object" == typeof e && (e.springsign = n);
			return {
				url: t,
				data: e
			}
		},
		_resetData: function(t, e, n) {
			var i, r, a = new Object;
			if (t && -1 != t.indexOf("?")) for (var o = t.substr(t.indexOf("?") + 1).split("&"), s = 0; s < o.length; s++) a[o[s].split("=")[0]] = unescape(o[s].split("=")[1]);
			if (e && "string" == typeof e) try {
				r = $.parseJSON(e), a = $.extend({}, r, a)
			} catch (u) {
				var c = e.split("&");
				if (c && 1 < c.length) for (s = 0; s < c.length; s++) a[c[s].split("=")[0]] = unescape(c[s].split("=")[1])
			}
			return e && "object" == typeof e ? (i = _sha._extend({}, e), i = _sha._extend(i, a)) : i = a, i
		},
		_getSign: function(data) {
			var sign = [],
				shaObj = new jsSHA("SHA-1", "TEXT"),
				_prefix = eval(function(t, e, n, i, r, a) {
					if (r = function(t) {
						return t
					}, !"".replace(/^/, String)) {
						for (; n--;) a[n] = i[n] || n;
						i = [function(t) {
							return a[t]
						}], r = function() {
							return "\\w+"
						}, n = 1
					}
					for (; n--;) i[n] && (t = t.replace(new RegExp("\\b" + r(n) + "\\b", "g"), i[n]));
					return t
				}('"0"', 0, 1, "s1f4569scdsac23dsf34".split("|"), 0, {}));
			switch (sign.push(_prefix), data.constructor) {
			case Object:
				for (var keys = _sha._getKeys(data), i = 0; i < keys.length; i++) {
					var key = keys[i],
						_data = data[key];
					null != _data && _data != undefined || (_data = ""), "object" == typeof _data && (_data = _utils.jsonToString(_data)), sign.push(key), sign.push(_data)
				}
				break;
			case Array:
				for (var i = 0, len = data.length; i < len; i++) sign.push(_utils.jsonToString(data[i]));
				break;
			case String:
				sign.push(data);
				break;
			case Date:
				sign.push("new Date(" + data.getTime() + ")");
				break;
			case Number:
				isFinite(data) && sign.push(data.toString());
				break;
			case Boolean:
			case Function:
			case RegExp:
				sign.push(data.toString())
			}
			return sign.push(_prefix), shaObj.update(sign.join("")), shaObj.getHash("HEX").toUpperCase()
		},
		_getKeys: function(t) {
			if (t !== Object(t)) throw new TypeError("Invalid object");
			var e = [];
			for (var n in t) e.push(n);
			return e.sort()
		},
		_extend: function(t, e) {
			for (var n in e) e.hasOwnProperty(n) && !t.hasOwnProperty(n) && (t[n] = e[n]);
			return t
		}
	}
}(Spring), function(n, c) {
	var u = {
		container: function() {
			var t = document.createElement("container");
			t.style.cssText = "position:absolute;top:0px;left:0px;width:100%;height:0px;z-index:99999;", t.innerHTML = '<span style="font-size:0; overflow:hidden;"></span>';
			var e = document.body;
			e || document.write('<span id="__body__" style="display:none;">chunqiu</span>'), (e = document.body.firstChild) ? document.body.insertBefore(t, e) : document.body.appendChild(t), (e = document.getElementById("__body__")) && e.parentNode.removeChild(e), n.container = c(t)
		},
		mask: function(t, e) {
			if (!t) return !1;
			var n, i, r = t[0];
			u.unmask(t);
			var a = {},
				o = document.documentElement;
			a.cssText = r.style.cssText, a.nextSibling = r.nextSibling, a.parentNode = r.parentNode, r.style.display = "block", Spring.container.append(r), r.style.position = "absolute";
			var s = "background:#000;position:absolute;left:0;top:0;width:" + Math.max(o.clientWidth, o.scrollWidth, document.body.clientWidth, document.body.scrollWidth) + "px;height:" + Math.max(o.clientHeight, o.scrollHeight, document.body.clientHeight, document.body.scrollHeight) + "px;";
			a.maskDiv = document.createElement("div"), a.maskDiv.style.cssText = s + "filter:progid:DXImageTransform.Microsoft.Alpha(opacity=50);opacity:0.5;", c(a.maskDiv).insertBefore(r), e ? (n = c(r).offset().left, i = c(r).offset().top, r.style.left = n + "px", r.style.top = i + "px") : (r.style.left = o.scrollLeft + document.body.scrollLeft + Math.max(0, (o.clientWidth - r.offsetWidth) / 2) + "px", r.style.top = Math.max(o.scrollTop, document.body.scrollTop) + Math.max(0, (o.clientHeight - r.offsetHeight) / 2) + "px"), Spring.utils.browser.IsIE && (a.maskIframe = document.createElement("iframe"), a.maskIframe.style.cssText = s + "filter:progid:DXImageTransform.Microsoft.Alpha(opacity=0);opacity:0;", c(a.maskIframe).insertBefore(a.maskDiv)), t.data("__mask__", a)
		},
		unmask: function(t) {
			if (!t) return !1;
			var e = t.data("__mask__");
			e && (t[0].style.cssText = e.cssText, e.nextSibling ? t.first().insertBefore(e.nextSibling) : t.first().appendTo(e.parentNode), c(e.maskDiv).remove(), e.maskIframe && (c(e.maskIframe).remove(), t.removeData("__mask__")))
		},
		beforeSend: function(t) {
			var e = {
				left: (t = t[0] || document.body).offsetLeft,
				top: t.offsetTop,
				width: t.clientWidth,
				height: t.clientHeight
			};
			c('<div class="js-load"><div class="load-bg"></div></div>').css(e).appendTo(Spring.container)
		},
		afterSend: function() {
			c(".js-load").remove()
		},
		msgTips: function() {}
	};
	u.container(), n.dom = u
}(Spring, jQuery), function(i) {
	i.config = {
		sign: !0,
		portUrl: window.location.origin
	}, i.Regx = {
		phone: /(^(([0\+]\d{2,3}-)?(0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$)|(^0{0,1}1[3|4|5|6|7|8|9][0-9]{9}$)/,
		email: /^([a-zA-Z0-9]+[_|\_|\.|-]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.|-]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/
	}, i.PRODUCT_TYPE = {
		Ticket: 1,
		Cruise: 4,
		Visa: 6,
		Tour: 7,
		Free: 13,
		Flight: 3
	}, i._getKeys = function(t) {
		if (t !== Object(t)) throw new TypeError("Invalid object");
		var e = [];
		for (var n in t) e.push(n);
		return e.sort()
	}, i.cookie = function(t, e, n) {
		if (void 0 === e) {
			var i = null;
			if (document.cookie && "" != document.cookie) for (var r = document.cookie.split(";"), a = 0; a < r.length; a++) {
				var o = $.trim(r[a]);
				if (o.substring(0, t.length + 1) == t + "=") {
					i = decodeURIComponent(o.substring(t.length + 1));
					break
				}
			}
			return i
		}
		n = n || {}, null === e && (e = "", n.expires = -1);
		var s, c = "";
		n.expires && ("number" == typeof n.expires || n.expires.toUTCString) && ("number" == typeof n.expires ? (s = new Date).setTime(s.getTime() + 24 * n.expires * 60 * 60 * 1e3) : s = n.expires, c = "; expires=" + s.toUTCString());
		var u = n.path ? "; path=" + n.path : "",
			l = n.domain ? "; domain=" + n.domain : "",
			f = n.secure ? "; secure" : "",
			p = n.encode ? e : encodeURIComponent(e);
		document.cookie = [t, "=", p, c, u, l, f].join("")
	}, i.createLinkA = function(t) {
		var e = document.createElement("a");
		e.href = t, e.target = "_blank", document.body.appendChild(e), e.click(), $(e).remove(), e = null
	}, i.cps = function() {
		var t = i.utils.urlParam("utm_medium") || "",
			e = [t, i.utils.urlParam("utm_campaign") || "", i.utils.urlParam("utm_source") || "", i.utils.urlParam("utm_content") || ""].join("|");
		if (t) i.cookie("c_source", e, {
			path: "/",
			expires: 30,
			encode: !0,
			domain: "." + WIN_CONFIG_SP.Cdomain
		});
		else {
			var n = i.cookie("c_source") || "";
			0 < (n = n.split(",")).length && (2 == n.length && (n.splice(1, 0, ""), n.push("")), i.cookie("c_source", n.join("|"), {
				path: "/",
				expires: 30,
				encode: !0,
				domain: "." + WIN_CONFIG_SP.Cdomain
			}))
		}
	}, i.cps()
}(Spring), function(e) {
	e.extend({
		KEY_ESC: 27,
		KEY_F1: 112,
		KEY_F2: 113,
		KEY_F3: 114,
		KEY_F4: 115,
		KEY_F5: 116,
		KEY_F6: 117,
		KEY_F7: 118,
		KEY_F8: 119,
		KEY_F9: 120,
		KEY_F10: 121,
		KEY_F11: 122,
		KEY_F12: 123,
		KEY_UP: 38,
		KEY_DOWN: 40,
		KEY_LEFT: 37,
		KEY_RIGHT: 39,
		KEY_ENTER: 13,
		KEY_SPACE: 32,
		KEY_TAB: 9,
		KEY_HOME: 36,
		KEY_END: 35,
		KEY_PAGEUP: 33,
		KEY_PAGEDOWN: 34,
		KEY_BACKSPACE: 8
	});
	var r, s, t, a, o, n, i, c, u = ((c = {}).Callbacks = (r = {}, s = 1, (t = function(t) {
		e.extend(!0, this, {
			flags: t ? r[t] ||
			function(t) {
				var e, n, i = r[t] = {};
				for (e = 0, n = (t = t.split(/\s+/)).length; e < n; e++) i[t[e]] = !0;
				return i
			}(t) : {},
			list: [],
			stack: [],
			needSort: !1
		})
	}).prototype = {
		sort: function() {
			this.list.sort(function(t, e) {
				return e[1] - t[1]
			})
		},
		add: function(t, e) {
			e = e || 0;
			var n, i = this.list,
				r = this.flags;
			if (!(!i || r.unique && (n = this.has(t)))) {
				if (s++, this.firing) {
					for (var a = this.firingIndex + 1; a < this.firingLength && !(e > i[a][1]); a++);
					i.splice(a, 0, [t, e, s]), this.firingLength++, e > i[this.firingIndex][1] && (this.needSort = !0)
				} else {
					var o = i.length;
					i.push([t, e, s]), this.memory && !0 !== this.memory ? (0 < o && e > i[o - 1][1] && (this.needSort = !0), this.firingStart = o, this._fire(this.memory[0], this.memory[1])) : this.sort()
				}
				return s
			}
			return n ? n[2] : -1
		},
		_remove: function(t) {
			this.firing && t <= this.firingLength && (this.firingLength--, t <= this.firingIndex && this.firingIndex--), this.list.splice(t, 1)
		},
		remove: function(t) {
			var e = this.list,
				n = this.flags;
			if (e) {
				var i = typeof t,
					r = 0,
					a = e.length;
				if ("function" === i) for (; r < a && (e[r][0] !== t || (this._remove(r), r--, a--, !n.unique)); r++);
				else if ("number" === i) for (; r < a && (e[r][2] !== t || (this._remove(r), r--, a--, !n.unique)); r++);
			}
			return this
		},
		has: function(t) {
			var e = this.list;
			if (e) {
				var n = 0,
					i = e.length,
					r = typeof t;
				if ("function" === r) {
					for (; n < i; n++) if (t === e[n][0]) return e[n]
				} else if ("number" === r) for (; n < i; n++) if (t === e[n][2]) return e[n]
			}
			return !1
		},
		_fire: function(t, e) {
			e = e || [];
			var n = this.flags,
				i = this.list;
			for (this.memory = !n.memory || [t, e], this.firing = !0, this.firingIndex = this.firingStart || 0, this.firingStart = 0, this.firingLength = i.length; i && this.firingIndex < this.firingLength; this.firingIndex++) if (!1 === i[this.firingIndex][0].apply(t, e) && n.stopOnFalse) {
				this.memory = !0;
				break
			}
			this.firing = !1, i && (n.once ? !0 === this.memory ? this.disable() : this.empty() : (this.needSort && (this.sort(), this.needSort = !1), this.stack && this.stack.length && (this.memory = this.stack.shift(), this.fire(memory[0], memory[1]))))
		},
		fire: function(t, e) {
			this.stack && (this.firing ? this.flags.once || this.stack.push([t, e]) : this.flags.once && this.memory || this._fire(t, e))
		},
		empty: function() {
			this.list = []
		},
		disable: function() {
			this.list = this.stack = this.memory = undefined
		},
		disabled: function() {
			return !this.list
		}
	}, t), c.Core = (a = !1, o = /xyz/.test(function() {
		xyz
	}) ? /\b_super\b/ : /.*/, (n = function() {}).extend = function(t) {
		var r = this.prototype;
		a = !0;
		var e = new this;
		for (var n in a = !1, t) e[n] = "function" == typeof t[n] && "function" == typeof r[n] && o.test(t[n]) ?
		function(n, i) {
			return function() {
				var t = this._super;
				this._super = r[n];
				var e = i.apply(this, arguments);
				return this._super = t, e
			}
		}(n, t[n]) : t[n];

		function i() {
			if (!a && this.init) {
				var t = this.init.apply(this, arguments);
				if (void 0 !== t) return t
			}
		}
		return i.prototype = e, (i.constructor = i).extend = arguments.callee, i
	}, n), c.Event = (i = c.Callbacks, c.Core.extend({
		newEvent: function(t, e) {
			this.eventHandle || (this.eventHandle = {}), this.events || (this.events = {}), this.events[t] = new i(e)
		},
		addEvent: function(t, e, n) {
			if (this.events && this.events[t]) {
				var i = this.events[t].add(e, n);
				return this.eventHandle[i] = t, i
			}
			return -1
		},
		removeEvent: function() {
			return this.events && ("number" == typeof arguments[0] ? (e = arguments[0], t = this.eventHandle[e], this.events[t] && this.events[t].remove(e)) : "string" == typeof arguments[0] && "function" == typeof arguments[1] ? (t = arguments[0], n = arguments[1], this.events[t] && this.events[t].remove(n)) : "string" == typeof arguments[0] && "number" == typeof arguments[1] ? (t = arguments[0], e = arguments[1], this.events[t] && this.events[t].remove(e)) : "string" == typeof arguments[0] && "undefined" == typeof arguments[1] ? (t = arguments[0], this.events[t] && this.events[t].empty()) : "undefined" == typeof arguments[0] && (this.events = {})), !1;
			var t, e, n
		},
		unEvent: function(t) {
			if ("string" == typeof t) this.events[t] && this.events[t].disable();
			else for (t in this.events) this.events[t].disable()
		},
		triggerEvent: function(t) {
			this.events && this.events[t] && this.events[t].fire(this, Array.prototype.slice.call(arguments, 1))
		}
	})), c.TemplateBox = (c.TReplace, c.Core.extend({
		init: function(t) {
			t = e.extend(!0, {
				template: null,
				box: null,
				data: null
			}, t), e.extend(!0, this, t), this.load()
		},
		load: function() {
			var t = Spring.template(this.template, this.data);
			this.box.innerHTML = t
		},
		request: function(t) {
			this.data = t, this.load()
		}
	})), c);
	e.extend({
		Base: u
	})
}(jQuery), function(c) {
	c.getRange = function(t, e) {
		return t = new Date(t), e = new Date(e), parseInt(Math.abs(e - t) / 1e3 / 60 / 60 / 24)
	}, c.XSS = {
		toStr: function(t) {
			return t && "string" == typeof t ? t.replace(/[<>&\r\n"]/g, function(t) {
				return {
					"&": "&amp;",
					"<": "&lt;",
					">": "&gt;",
					"\r": "<br>",
					"\n": "<br>",
					'"': "&quot;"
				}[t]
			}) : t
		},
		html: function(t) {
			return t ? t.replace(/[\r\n]/g, "<br>") : ""
		}
	}, c.lastRun = function(i) {
		var r;
		return i = i || 1, function(t) {
			r && clearTimeout(r);
			var e = this,
				n = Array.prototype.slice.call(arguments, 1);
			r = setTimeout(function() {
				r = null, t.apply(e, n)
			}, i)
		}
	}, c.LazyList = function(t, n) {
		var i = t.length,
			r = [];
		t && 0 < i ? t.forEach(function(t, e) {
			t(function(t) {
				r[e] = t, 0 === --i && n.apply(null, r)
			})
		}) : n()
	};
	var u = [];
	c.getMask = function() {
		return $('<div class="load-mask js-load-mask dn"> <div class="bg js-bg"></div> <div class="loading-img js-content"></div></div>').appendTo(c.container)
	}, c.loadMask = function(t, e) {
		if (t.is(":hidden")) return {
			close: function() {}
		};
		var n = t.parents(".mask-container"),
			i = u.pop() || c.getMask(),
			r = {
				left: 0,
				top: 0
			};
		n.length ? (i.appendTo(n), (r = n.offset()).left -= n.scrollLeft(), r.top -= n.scrollTop()) : i.appendTo(c.container);
		var a = i.find(".js-content");
		a.text(e || "").css({
			marginLeft: -a.outerWidth()
		});
		var o = i.find(".js-bg"),
			s = t.offset();
		return o.removeClass("dn"), i.css({
			left: s.left - r.left,
			top: s.top - r.top,
			width: t.outerWidth(),
			height: t.outerHeight() || n.outerHeight()
		}).removeClass("dn"), {
			close: function() {
				i.addClass("dn"), o.addClass("dn"), setTimeout(function() {
					i.addClass("dn"), u.push(i)
				}, 1e3)
			}
		}
	}, c.PageLoading = function() {
		var t = $('<div class="gd" id="loading_create_panel"><div class="jdthui"></div></div>').appendTo(c.container);
		return {
			panel: t,
			box: t.find(">div").eq(0),
			qiqiu: t.find(">div").eq(1),
			show: function() {
				c.dom.mask(this.panel)
			},
			hide: function() {
				c.dom.unmask(this.panel)
			},
			play: function() {
				var t = this;
				this.index = 0, this.box.stop().animate({
					width: "0px"
				}, 4e3), this.qiqiu.stop().animate({
					marginLeft: "490px"
				}, 4e3), this.timer = setInterval(function() {
					100 <= t.index && (t.index = 0, t.box.stop().animate({
						width: "490px"
					}, 0).animate({
						width: "0px"
					}, 4e3), t.qiqiu.stop().animate({
						marginLeft: "0px"
					}, 0).animate({
						marginLeft: "490px"
					}, 4e3)), t.index++
				}, 40)
			},
			stop: function() {
				clearInterval(this.timer), this.box.stop().animate({
					width: "490px"
				}, 0), this.qiqiu.stop().animate({
					marginLeft: "0px"
				}, 0)
			}
		}
	}, c.sysErrTips = function(t) {
		var e = $('<div class="prodt-tc error-tc" style="display:none;" id="sysErrTips"><h3 class="prodt-title"><a class="dicon-close" href="javascript:;"></a></h3><div class="tc-txt">' + t + '</div><a class="tc-know" href="javascript:;">知道了</a></div>').appendTo(c.container);
		c.dom.mask(e), e.on("click", "a.dicon-close,a.tc-know", function() {
			c.dom.unmask(e)
		})
	}
}(Spring), function() {
	var i = "",
		t = function(t) {
			this.dataTag = {
				Event: "event",
				Category: "category",
				Done: "done",
				Tag: "tag",
				Type: "type",
				Title: "title"
			}, this.target = $(t), this.init()
		};
	t.prototype = {
		init: function() {
			this.setOptions()
		},
		setOptions: function() {
			for (var t in this.dataTag) this[t] = this.target.data(this.dataTag[t]);
			this.Event = this.Event || "event", this.Category = this.Category || i || "", this.Done = this.Done + "/" + this.Tag;
			try {
				CHstat.stat({
					type: "click",
					event: this.Type,
					area: this.Category + "/" + this.Done
				})
			} catch (n) {}
			if (window.ga !== undefined && null !== window.ga) {
				if (!this.Category && !this.Tag) return !1;
				var e = this.Tag + this.Title ? "/" + this.Title : this.Tag;
				window.ga("send", this.Event, this.Category, this.Done, e)
			}
		}
	}, $(document).ready(function() {
		i = $("#BI-track").attr("data-page"), $(document).on("click", "[data-role='ga']", function() {
			new t(this)
		})
	})
}();