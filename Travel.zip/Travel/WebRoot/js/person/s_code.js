var s= {};

!function(){
	s.__t = function(){};
	s.__tl = function(a, b, c){};
	s.t = function () { }
	s.tl = function () { }
}();


!function(d){
	RATE = {
		"THB": 0.1886,
		"CNY": 1,
		"JPY": 0.0513,
		"USD": 6.1237,
		"HKD": 0.7896,
		"KRW": 0.0056,
		"MOP": 0.7783,
		"TWD": 0.195,
		"SGD": 4.6187
	};
	d.onclick = function(e){
		try{
			var gatrack = (target.getAttribute('data-gatrack') || '').split(' ');
			if(gatrack.length && window.ga){
				ga('send', 'event', gatrack[0], 'click', gatrack[1]);
			}
		}catch(e){}
	};


}(document);
