function jsonCallback(data){

}

function deepCopy(p, c){
    var c = c || {};
    for (var i in p) {
        if (typeof p[i] === 'object') {
            if(p[i] !=null){
                c[i] = (p[i].constructor === Array) ? [] : {};
                deepCopy(p[i], c[i]);
            }
        } else {
            c[i] = p[i];
        }
    }
    return c;
}


window.SA = window.SA || {}

deepCopy({
    trackUrl : '', //pjson
    param : null,
    data : [],
    browser : {
        versions:function(){
            var u = window.navigator.userAgent;
            return {
                trident: u.indexOf('Trident') > -1,  //IE内核
                presto: u.indexOf('Presto') > -1, //opera内核
                webKit: u.indexOf('AppleWebKit') > -1, //苹果，谷歌内核
                gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核
                mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
                ios: !!u.match(/\(i[^;]+;(U;)? CPU.+Mac OS X/), //ios终端
                android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //Android终端或者UC浏览器
                iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1, //是否为iPhone或者qq浏览器
                iPad: u.indexOf('iPad') > -1,//是否为iPad
                webApp: u.indexOf('Safari') == -1,//是否为web应用
                weixin: u.indexOf('MicroMessenger') == -1 //是否为微信浏览器
            };
        }()
    },
    stack: [],
    getData : function(){
        this.param = {
            's1' : this.getOS(),        //操作系统
            's2' : this.getINTFC_TP(),  //终端类型
            's3' : this.getLanguage(),  //语言
            's6' : this.getDeviceId(),  //访问者唯一标识
            'p1' : this.getPAGE_URL(),  //页面URL
            'p2' : this.getPAGE_TYPE(), //页面类型URL
            'p3' : this.getPAGE_NAME(), //页面名称
            'p4' : this.getPV_TIME(),   //页面进入时间
            'p5' : this.getPV_ID(),     //页面PV_ID
            'c1' : this.getPid().cmpid || "", //站外来源
            'c2' : this.getPid().inpid || "", //站内营销
            'u1' : this.getUserID(),
            'u2' : this.getUserID() ? 'Y' :'N',
            's7':encodeURIComponent(document.referrer),
            's8':window.navigator.userAgent,
            's14': encodeURIComponent(document.referrer ? document.referrer : "")
        };
    },
    getUserID: function() {
        var userID = document.getElementsByName("SF.UD");
        if (userID.length) {
            return userID[0].content;
        }
        return "";
    },
    newGuid: function() {
        var guid = "";
        for (var i = 1; i <= 32; i++){
            var n = Math.floor(Math.random()*16.0).toString(16);
            guid +=   n;
            if((i==8)||(i==12)||(i==16)||(i==20))
                guid += "-";
        }
        return guid;
    },
    //发送
    track: function(isyiqi) {
        this.param['s3'] = this.getLanguage();  //實時計算语言（有些cshtml  加載的方式）
        var newGuid=this.newGuid();
        if (isyiqi) {
            this.param['o2'] = newGuid;  //增加guid排查错误
        } else {
            this.param['pr30'] = newGuid;  //增加guid排查错误
        }
        this.dotrack(deepCopy(this.param));
    },
    trackSet: function(json){
        this.param['e_time']=this.getPV_TIME();
        for(var i in json){
            if(json[i]){
                this.param[i] = encodeURIComponent(json[i]);
            }else{
                this.param[i] = json[i];
            }

        }
    },
    trackSetClear:function(json){
        for(var i in json){
            this.param[i] = null;
        }
    },
    trackSetSend: function(json) {
        this.trackSet(json);
        this.track();
        if(/^EVENT\d+/.test(json.event)){
            this.trackSetClear(json);
        }
    },
    dotrack: function (param) {
        if (this.finished) {
            this.JSONP(param);
        } else if (this.isInterval) {
            this.stack.push(param);
        } else {
            this.isInterval = true;
            this.stack.push(param);
            this.seconds = 0;
            var that = this;
            var circle = setInterval(function() {
                if (document.getElementsByName("xhr-info").length > 0 ||
                    that.seconds > 5000) {
                    clearInterval(circle);
                    that.getData();
                    that.finished = true;
                    that.sendAllStack();
                }
                that.seconds += 1000;
            }, 1000);
        }
    },
    sendAllStack: function() {
        for (var i = 0; i < this.stack.length; i++) {
            this.JSONP(this.stack[i]);
        }
    },
    JSONP : function(param) {
        param.u1 = this.getUserID();
        param.u2 = param.u1 ? 'Y' :'N';
        var pname = '?';
        for (var p in param) {
            pname += p + "=" + param[p] + "&";
        }
        var url = this.trackUrl + pname.substring(0, pname.length - 1);
        console.log(this.trackUrl, param);
        var script = new Image;
        script.onload = script.onerror = script.onabort = function() {
            script.onload = script.onerror = script.onabort = null,
            script = null;
        }
        script.src = url.indexOf('?') > 0 ? url+'&callback=jsonCallback' : url+'?callback=jsonCallback';
        SA.trackUrl = 'https://lc.ch.com/self/CollectV2';
        //页面加载完后清空标签
        setTimeout (function (){
            try{
                document.getElementsByTagName('head')[0].removeChild(script);
            }
            catch(e){
            }
        }, 1000);
    },
    //页面PV_ID
    getPV_ID : function(){
        var pvid = '';
        if(document.getElementsByName('WT.dcsvid').length > 0){
            pvid = document.getElementsByName('WT.dcsvid')[0].getAttribute("content");
        }
        return pvid;
    },
    getPAGE_TYPE : function(){
        var url = window.location+"";
        var index = url.indexOf('?');
        if(index > 0){
            return encodeURIComponent(url.substring(0, index));
        }
        else{
            return encodeURIComponent(url);
        }
    },
    //操作系统
    getOS : function(){
        var OS = '';
        if(this.browser.versions.mobile){
            if(this.browser.versions.ios){
                OS =  'Ios';
            } else if(this.browser.versions.android){
                OS =  'Android';
            } else{
                OS = 'Other';
            }
        } else {
            var ua = window.navigator.userAgent;
            var isWin = (window.navigator.platform == 'Win32') || (window.navigator.platform == 'Windows');
            var isMac = (window.navigator.platform == 'Mac68K') || (window.navigator.platform == 'MacPPC') || (window.navigator.platform == 'Macintosh') || (window.navigator.platform == 'MacIntel');
            if(isMac){
                OS = 'Mac';
            }
            var isUnix = (window.navigator.platform == 'X11') && !isWin && !isMac;
            if(isUnix){
                OS = 'Unix';
            }
            var isLinux = (String(window.navigator.platform).indexOf('Linux') > -1);
            if(isLinux){
                OS = 'Linux';
            }
            if(isWin){
                var isWin2K = ua.indexOf('Windows NT 5.0') > -1 || ua.indexOf('Windows 2000') > -1;
                if(isWin2K){
                    OS = 'Win2000';
                }
                var isWinXP = ua.indexOf('Windows NT 5.1') > -1 || ua.indexOf('Windows XP') > -1;
                if(isWin2K){
                    OS = 'WinXP';
                }
                var isWin2003 = ua.indexOf('Windows NT 5.2') > -1 || ua.indexOf('Windows 2003') > -1;
                if(isWin2003){
                    OS = 'Win2003';
                }
                var isWinVista = ua.indexOf('Windows NT 6.0') > -1 || ua.indexOf('Windows Vista') > -1;
                if(isWinVista){
                    OS = 'WinVista';
                }
                var isWin7 = ua.indexOf('Windows NT 6.1') > -1 || ua.indexOf('Windows 7') > -1;
                if(isWin7){
                    OS = 'Win7';
                }
            }
            if(OS == ''){
                OS = 'Other'
            }
        }
        return OS;
    },
    //终端类型
    getINTFC_TP : function(){
        var type = '';
        if(this.browser.versions.mobile){
            /**if(this.browser.versions.iPhone){
                type =  'iPhone';
                } else if(this.browser.versions.iPad){
                    type =  'iPad';
                } else{
                    type =  'other';
                }**/
            type =  'WAP';
        } else{
            type =  'WEB';
        }
        return type;
    },
    //获取浏览器内核
    getLanguage : function(){
        var language = '';
        /**if(this.browser.versions.trident){
            language = 'IE';
        }
         else if(this.browser.versions.presto){
            language = 'opera';
        }
         else if(this.browser.versions.webKit){
            language = 'webKit';
        }
         else if(this.browser.versions.gecko){
            language = 'gecko';
        }**/
        if(typeof(seajs) != 'undefined'){
            try{
                if(seajs.data && seajs.data.vars && seajs.data.vars.lang){
                    language = seajs.data.vars.lang;
                } else{
                    language = this.searchField('lang')
                }
            }
            catch(e){
            }
        } else{
            language = this.searchField('lang')
        }
        return  language == '' ? 'zh-cn' : language;
    },
    //访问者唯一标识
    getDeviceId : function(){
        return this.searchField('deviceid');
    },
    searchField : function(name){
        var Field = '';
        var urlName = window.location.search;
        if(urlName != ''){
            var url = urlName.substring(1, urlName.length);
            arr = url.split('&');
            if(arr.length > 0){
                for(var i = 0; i < arr.length; i++){
                    if(arr[i].split('=')[0] == name){
                        Field = arr[i].split('=')[1];
                        break;
                    }
                }
            }
        }
        return Field;
    },
    getPAGE_URL : function(){
        return encodeURIComponent(window.location);
    },
    getPAGE_NAME : function(){
        return document.title;
    },
    getPV_TIME : function(){
        var now = new Date();
        var year = now.getFullYear();
        var month = now.getMonth() + 1;
        var day = now.getDate();
        var hh = now.getHours();
        var mm = now.getMinutes();
        var ss = now.getSeconds();
        var clock = year + '-';
        if(month < 10){
            clock += '0';
        }
        clock += month + '-';
        if(day < 10){
            clock += '0';
        }
        clock += day + " ";
        if(hh < 10){
            clock += '0';
        }
        clock += hh + ':';
        if(mm < 10){
            clock += '0';
        }
        clock += mm + ':';
        if(ss < 10){
            clock += '0';
        }
        clock += ss;
        return clock;
    },
    getPid : function(){
        var url = window.location.search;
        var arr = [];
        var pid = {
            cmpid : '',
            inpid : ''
        }
        if(url != ''){
            url = url.substring(1, url.length);
            arr = url.split('&');
            if(arr.length > 0){
                for(var i = 0; i < arr.length; i++){
                    if(arr[i].split('=')[0] == 'cmpid'){
                        pid.cmpid = arr[i].split('=')[1];
                    }
                    else if(arr[i].split('=')[0] == 'intcmp'){
                        pid.inpid = arr[i].split('=')[1];
                    }
                }
            }
        }
        return pid;
    }
}, window.SA);
var SAOld=deepCopy(window.SA,{},{});
SAOld.trackUrl='https://lc.ch.com/self/CollectForPC';
SA.trackUrl = 'https://lc.ch.com/self/CollectV2';
SA.getData();
SAOld.getData();

setTimeout(function(){
    if(window.SAloaded){
        return;
    }
    window.SAOld.param["o1"]=window.SA.param["o1"]||"";
    window.SAOld.param["title"]=window.SA.param["title"]||"";
    window.SAOld.param["p3"]=window.SA.param["p3"]||"";
    window.SAOld.param["c1"]=window.SA.param["c1"]||"";
    SAOld.track(true)
    window.SAloaded=true;
}, 2000);



// gio插码
(function () {
  // 防止重复
  if (window.View5) {
    return;
  }

  var _View = function () {
    this.gaMessage = [];
  };
  _View.prototype = {
    constructor: _View,
    init: function () {
      this.initGa();
      this.fnTrack();
    },
    setCookie: function (c_name, value, expiredays) {
      var exdate = new Date();
      exdate.setDate(exdate.getDate() + expiredays);
      document.cookie = c_name + "=" + escape(value) + ((expiredays == null) ? "" : ";domain=.ch.com;path=/;expires=" + exdate.toGMTString());
    },
    getCookie: function (c_name) {
      if (document.cookie.length > 0) {
        c_start = document.cookie.lastIndexOf(c_name + "=");
        if (c_start != -1) {
          c_start = c_start + c_name.length + 1;
          c_end = document.cookie.indexOf(";", c_start);
          if (c_end == -1) {
            c_end = document.cookie.length;
          }
          return unescape(document.cookie.substring(c_start, c_end));
        }
      }
      return "";
    },
    //ga消息队列保存ga还没有加载前的消息队列
    initGa: function () {
      var index = 0;
      // GA统计方法
      var gaMessage = this.gaMessage;
      var gaTimer = setInterval(function () {
        if (window.ga || index > 10) {
          clearInterval(gaTimer);
          if (gaMessage.length > 0) {
            for (var i = 0; i < gaMessage.length; i++) {
              var current = gaMessage[i];
              window.ga && window.ga(current[0], current[1], current[2]);
            }
          }
        } else {
          index++;
        }
      }, 2000)
    },
    // GA统计方法
    ga: function (category, event, label) {
      if (window.ga) {
        ga && ga('send', 'event', category, event || 'click', label);
      } else {
        this.gaMessage.push([category, event, label])
      }
      //var ga = window.ga;
      //ga && ga('send', 'event', category, event || 'click', label);
    },
    gioTrackTempArray:[],
    gioTrack: function () {
      console.log(arguments[1])
      if(window.gio){
        // gio2.0
        window.gio('track', arguments[0], arguments[1]);
      }else if(window._vds){
        // gio1.0
        window._vds && window._vds.track && window._vds.track(arguments[0],arguments[1]);
      }else{
        var _arguments = arguments;
        this.gioTrackTempArray.push(function(){
          window.gio('track', _arguments[0], _arguments[1])
        })
      }
    },
    gioSet: function () {
      if(window.gio){
        // gio2.0
        window.gio("evar.set", arguments[0]);
      }else{
        var _arguments = arguments;
        this.gioTrackTempArray.push(function(){
          window.gio("evar.set", _arguments[0])
        })
        window.gioTrackTempArray = this.gioTrackTempArray;
      }
    },
    fnTrack: function () {
      var that = this;
      var oTrack = {};
      oTrack.ga = fnGa;
      oTrack.gio = fnGio;
	    oTrack.fnApex = fnApex;
      oTrack.SeoBaidu = SeoBaidu;
      oTrack.Seo360 = Seo360;
	    oTrack.TingYun = TingYun;
      var bOpen = true;
      //GA
      function fnGa() {
        var codemap = {
          "zh-cn": "UA-54697886-3",
          "en-us": "UA-54697886-5",
          "zh-hk": "UA-54697886-4",
          "ko-kr": "UA-54697886-7",
          "ja-jp": "UA-54697886-6",
          "th-th": "UA-54697886-8",
          'app': "UA-54697886-2",
          'wx': "UA-1325289-30"
        };
        var isSite = true;
        var lang = 'zh-cn';
        try {
          lang = seajs.data.vars.lang
        } catch (e) {
        };
        var analyticsUrl = '//www.google-analytics.com/analytics.js';
        if (location.href.indexOf('//news.ch.com') != -1){
          analyticsUrl = 'https://ajax.springairlines.com/js/3rd/analytics.js'
        }
        try{
          // 微信 4// app 2 // m 3
          switch (parseInt(window.globalData.channel)) {
            case 2:
              !function (a, b, c, d, e, f, g) {
                a.GoogleAnalyticsObject = e, a[e] = a[e] || function () {
                  (a[e].q = a[e].q || []).push(arguments)
                }, a[e].l = 1 * new Date, f = b.createElement(c), g = b.getElementsByTagName(c)[0], f.async = 1, f.src = d, g.parentNode.insertBefore(f, g)
              }(window, document, "script", analyticsUrl, "ga"), ga("create", codemap.app, "auto"), ga("send", "pageview", {'dimension4': lang});
              isSite = false;
              break;
            case 4:
              !function (a, b, c, d, e, f, g) {
                a.GoogleAnalyticsObject = e, a[e] = a[e] || function () {
                  (a[e].q = a[e].q || []).push(arguments)
                }, a[e].l = 1 * new Date, f = b.createElement(c), g = b.getElementsByTagName(c)[0], f.async = 1, f.src = d, g.parentNode.insertBefore(f, g)
              }(window, document, "script", analyticsUrl, "ga"), ga("create", codemap.wx, "auto"), ga("send", "pageview", {'dimension4': lang});
              isSite = false;
              break;
          }
        }catch (e) {}
        if (isSite){
          if (lang == 'zh-cn') {
            !function (a, b, c, d, e, f, g) {
              a.GoogleAnalyticsObject = e, a[e] = a[e] || function () {
                (a[e].q = a[e].q || []).push(arguments)
              }, a[e].l = 1 * new Date, f = b.createElement(c), g = b.getElementsByTagName(c)[0], f.async = 1, f.src = d, g.parentNode.insertBefore(f, g)
            }(window, document, "script", analyticsUrl, "ga"), ga("create", "UA-54697886-1", "auto"), ga("send", "pageview", {'dimension4': lang});
          } else {
            !function (a, b, c, d, e, f, g) {
              a.GoogleAnalyticsObject = e, a[e] = a[e] || function () {
                (a[e].q = a[e].q || []).push(arguments)
              }, a[e].l = 1 * new Date, f = b.createElement(c), g = b.getElementsByTagName(c)[0], f.async = 1, f.src = d, g.parentNode.insertBefore(f, g)
            }(window, document, "script", analyticsUrl, "ga"), ga("create", "UA-54697886-1", "auto"), ga("create", codemap[lang], "auto", {name: "lang"}), ga("send", "pageview", {'dimension4': lang}), ga("lang.send", "pageview");
          };
        }

      };
			//apex
	    function fnApex () {
		    var ApexUrl = 'ajax.springairlines.com/cache/js/3rd/apex.analytic.min.js' + '?vs=20181229';

		    !function (e, t, n, g, i) {
			    e[i] = e[i] || function () {
				    (e[i].q = e[i].q || []).push(arguments)
			    }, n = t.createElement("script"), tag = t.getElementsByTagName("script")[0], n.async = 1, n.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + g, tag.parentNode.insertBefore(n, tag);
			    n.onload = function(){
				    window.autoTrigger(true, true)
			    }
		    }(window, document, "script", ApexUrl, "autoTrigger");
	    }

	    var getIsMobile = function () {
		    var u = navigator.userAgent;
		    var app = navigator.appVersion;
		    var list = [
			    'iPhone', 'Android', 'iPad'
		    ];
		    var ret = false;
		    for (i in list) {
			    if (u.indexOf(list[i]) >= 0) {
				    ret = true;
				    break;
			    }
		    }
		    return ret;
	    };

      //GIO
      function fnGio() {
        var oId = {
          m: 'a7294e3b92c392af',
          pc: '9683d26dac59f3e8',
          app: 'afb25308914cbbcb',
          wx: '95b6405fe79fabc2'
        };
        var sId = '';

        var getIsPad = function () {
          var u = navigator.userAgent;
          var app = navigator.appVersion;
          var list = [
            'iPad'
          ];
          var ret = false;
          for (i in list) {
            if (u.indexOf(list[i]) >= 0) {
              ret = true;
              break;
            }
          }
          return ret;
        }
        var getDeviceType = function () {
          var type = {
            pc: 0,
            mobile: 1,
            pad: 2
          }, ret = type.pc;

          if (getIsMobile()) {
            ret = type.mobile;
          } else if (getIsPad()) {
            ret = type.pad;
          }
          return ret;
        }
        var isMobile = getDeviceType() != 0 && getDeviceType() != 2;
        if (isMobile) {
          sId = oId.m;
        } else {
          sId = oId.pc;
        }
        // 微信 4
        // app 2
        // m 3
        // pc 1或者undefined
        //活动页面用window.globalData.channel判断环境
        try{
          switch (parseInt(window.globalData.channel)) {
            case 2:
              sId = oId.app;
              break;
            case 4:
              sId = oId.wx;
              break;
          }
        }catch (e) {}
        var gioUrl = 'assets.growingio.com/2.1/gio.js';
        if (location.href.indexOf('//news.ch.com') != -1){
          gioUrl = 'ajax.springairlines.com/cache/js/3rd/gio.js'
        }
        !function (e, t, n, g, i) {
          e[i] = e[i] || function () {
            (e[i].q = e[i].q || []).push(arguments)
          }, n = t.createElement("script"), tag = t.getElementsByTagName("script")[0], n.async = 1, n.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + g, tag.parentNode.insertBefore(n, tag)
        }(window, document, "script", gioUrl, "gio");
        gio('init', sId, {});
        try{
          if(that.gioTrackTempArray.length){
            for(var i=0;i<that.gioTrackTempArray.length;i++){
              that.gioTrackTempArray[i]();
            }
          }
        }catch (e) {};

        if (document.domain == "pages.ch.com" || location.href.indexOf("https://help.ch.com/cn/coupon/getcoupon")!=-1) {
          window.gio('track', "promoPageView", {
            "promoName_var": document.title
          })
          window.gio("evar.set", {"promoName_evar": document.title});
        };
        gio('send');
      }

      //SeoBaidu
      function SeoBaidu() {
        (function(){
          var bp = document.createElement('script');
          var curProtocol = window.location.protocol.split(':')[0];
          if (curProtocol === 'https') {
            bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
          }
          else {
            bp.src = 'http://push.zhanzhang.baidu.com/push.js';
          }
          var s = document.getElementsByTagName("script")[0];
          s.parentNode.insertBefore(bp, s);
        })();
      }

      //SeoBaidu
      function Seo360() {
        (function(){
          var src = (document.location.protocol == "http:") ? "http://s6.qhres.com/static/ab77b6ea7f3fbf79.js?8623c2759dc3ec4809fdda8394f2cc48":"https://s.ssl.qhres.com/ssl/ab77b6ea7f3fbf79.js?8623c2759dc3ec4809fdda8394f2cc48";
          var n = document.createElement("script");
          var tag = document.getElementsByTagName("script")[0];
          n.id = "sozz";
          n.src = src;
          tag.parentNode.insertBefore(n, tag);
        })();
      }

      //TingYun
	    function TingYun() {
        if(getIsMobile()){
	        (function(){
		        var src = '//ajax.springairlines.com/cache/js/3rd/tingyun-rum.js';
		        var n = document.createElement("script");
		        var tag = document.getElementsByTagName("script")[0];
		        n.src = src;
		        tag.parentNode.insertBefore(n, tag);
	        })();
        }
	    }


      //防止s_code全局变量报错
      window.s = window.s || {};

      if (bOpen) {
        //插码延迟加载
        setTimeout(function () {
          for (var track in oTrack) {
            oTrack[track]();
          }
        }, 3200)
      }
    },
    ifInternational:function(Routes){
      var ifInternational = false;
      for(var i=0;i<Routes.length;i++){
        if(Routes[i].RouteArea && Routes[i].RouteArea !=1){
          ifInternational = true;
        }
      }
      return ifInternational;
    },
    gioTrackFns: {
      //搜索
      search: function (params) {
        // search1	自定义事件	首页搜索
        // search2	自定义事件	机票频道页搜索
        // search3	自定义事件	搜索结果页搜索
        var _location = location.href.split('#')[0].split('?')[0];
        var __fn = "search1";

        if(_location.indexOf('flights.ch.com')!=-1 || /^https:\/\/.*.ch.com\/flights/ig.test(_location)){
          __fn = "search2"
        }
        if(/^https:\/\/.*\.ch\.com\/(flights\/)?(Round-)?[A-Z]{3}-[A-Z]{3}\.html/ig.test(_location)){
          __fn = "search3"
        }

        _View.prototype.gioTrack(__fn, params)
      },
      //注册成功
      regSuccess: function () {
        _View.prototype.gioTrack("regSuccess", {
          "userId_var": 1
        })
      },
      //航班列表页点击预订按钮
      flightListPageClck: function (searchPara,ifRet) {
        _View.prototype.gioTrack("flightListPageClck", {
          "deptCity_var": ifRet ? searchPara.ACode : searchPara.DCode,
          "destCity_var": ifRet ? searchPara.DCode : searchPara.ACode,
          "deptDate_var": ifRet ? searchPara.ReturnDate : searchPara.DepartureDate
        })
      },
      //用户在乘机人信息页填写完乘机人信息，点击下一步（预订增值服务）
      passInfoConfirm: function (form) {
        var Router0 = form.Route[0];
        _View.prototype.gioTrack("passInfoConfirm", {
          "deptCity_var": form.DCode,
          "destCity_var": form.ACode,
          "deptDate_var": form.DepartureDate,
          "ifRoundTrip_var": form.IfRet,
          "ifInternational_var": _View.prototype.ifInternational(form.Route),
          "ticketLevel_var": Router0.AircraftCabins.CabinLevel
        })
      },
      //一次增值提交订单按钮处
      additionalServiceConfirm: function (BookingData,data,_) {
        var Router0 = data.Route[0];
        var servers = _.flatten(_.pluck(_.flatten(_.pluck(data.PassengerWithPros,"AllIncreases")),"Products"));
        var ifInsurance_var = _.find(servers,function(item){return _.indexOf([0,1,3,9],item.Type)!=-1});
        var ifBaggageService_var = _.find(servers,function(item){return _.indexOf([4,8,15],item.Type)!=-1});
        var ifCateringService_var = _.find(servers,function(item){return _.indexOf([5],item.Type)!=-1});
        _View.prototype.gioTrack("additionalServiceConfirm", {
          "deptCity_var": Router0.DepartureCode,
          "destCity_var": Router0.ArrivalCode,
          "ifRoundTrip_var": (/^1/).test(Router0.RouteType) && data.Route.length ==2,
          "ifInternational_var": BookingData.IsInternational,
          "deptDate_var": (BookingData.Route || BookingData.routes)[0].DepartureTime,
          "ticketLevel_var": (BookingData.Route || BookingData.routes)[0].AircraftCabin.CabinLevel,
          "ifInsurance_var": !!ifInsurance_var,
          "ifBaggageService_var": !!ifBaggageService_var,
          "ifCateringService_var": !!ifCateringService_var
        })
      },
      //立即支付按钮
      orderSubmit: function (orderData,OrderDetailOnPay,_) {
        if(seajs.data.vars.lang == 'ja-jp'){
          _View.prototype.gioTrack("orderSubmit", {
            "orderID_var": $('.w-main .col-orange').text()
          });
          return;
        }
        var servers = _.flatten(_.pluck(_.pluck(orderData.OrderDetail.OrderDetails,'Passenger'),"HasBuyIncreaseProducts"))
        var ifInsurance_var = _.find(servers,function(item){return _.indexOf([0,1,3,9],item.Type)!=-1});
        var ifBaggageService_var = _.find(servers,function(item){return _.indexOf([4,8,15],item.Type)!=-1});
        var ifCateringService_var = _.find(servers,function(item){return _.indexOf([5],item.Type)!=-1});
        var RouteInfos = _.flatten(_.pluck(orderData.OrderDetail.OrderDetails,'RouteInfo'));
        var ifInternational_var = _.find(RouteInfos,function(item){return item.RouteArea != 1});
        var getifRoundTrip_var = function(){
          var routerLength = 0;
          var groupSegmentId = _.groupBy(_.pluck(orderData.OrderDetail.OrderDetails,'RouteInfo'),'SegmentId');
          for(var i in  groupSegmentId){
            routerLength++;
          }
          return (/^1/).test(orderData.OrderDetail.OrderDetails[0].RouteInfo.RouteType) && routerLength > 1;
        }

        var getFirstRoute = function(){
          _.map(orderData.OrderDetail.OrderDetails,function(item1){
            return item1.RouteInfo.CabinLevel = item1.CabinLevel;
          })
          var groupSegmentId = _.groupBy(_.pluck(orderData.OrderDetail.OrderDetails,'RouteInfo'),'SegmentId');
          var Routes = [];
          for(var i in groupSegmentId){
            Routes.push(groupSegmentId[i][0]);
          }
          Routes = Routes.sort(function(a,b){return a.RouteType - b.RouteType});
          return Routes[0];
        }
        var FirstRoute = getFirstRoute();

        _View.prototype.gioTrack("orderSubmit", {
          "orderID_var": orderData.OrderNo,
          // "deptCity_var": FirstRoute.DepartureCityCode,
          // "destCity_var": FirstRoute.ArrivalCityCode,
          "ifRoundTrip_var": getifRoundTrip_var(),
          "ifInternational_var": !!ifInternational_var,
          // "deptDate_var": (FirstRoute.DepartureTime || "").split(' ')[0],
          "ticketLevel_var": FirstRoute.CabinLevel,
          "paymentChannel_var": $("#PayChannel").val(),
          "ifInsurance_var": !!ifInsurance_var,
          "ifBaggageService_var": !!ifBaggageService_var,
          "ifCateringService_var": !!ifCateringService_var
        });
      },
      // 用户站内搜索的航线，如“北京-上海”
      searchKW_evar:function(searchPara){
        _View.prototype.gioSet({"searchKW_evar": searchPara.Departure+'-'+searchPara.Arrival});
      }
    }
  }
  window.View5 = new _View();
  window.View5.init();
})()