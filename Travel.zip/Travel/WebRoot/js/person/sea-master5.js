﻿!
function() {
	function a(a) {
		return a.replace(t, "").replace(u, ",").replace(v, "").replace(w, "").replace(x, "").split(/^$|,+/)
	}
	function b(a) {
		return "'" + a.replace(/('|\\)/g, "\\$1").replace(/\r/g, "\\r").replace(/\n/g, "\\n") + "'"
	}
	function c(c, d) {
		function e(a) {
			return m += a.split(/\n/).length - 1, k && (a = a.replace(/\s+/g, " ").replace(/<!--.*?-->/g, "")), a && (a = s[1] + b(a) + s[2] + "\n"), a
		}
		function f(b) {
			var c = m;
			if (j ? b = j(b, d) : g && (b = b.replace(/\n/g, function() {
				return m++, "$line=" + m + ";"
			})), 0 === b.indexOf("=")) {
				var e = l && !/^=[=#]/.test(b);
				if (b = b.replace(/^=[=#]?|[\s;]*$/g, ""), e) {
					var f = b.replace(/\s*\([^\)]+\)/, "");
					n[f] || /^(include|print)$/.test(f) || (b = "$escape(" + b + ")")
				} else b = "$string(" + b + ")";
				b = s[1] + b + s[2]
			}
			return g && (b = "$line=" + c + ";" + b), r(a(b), function(a) {
				if (a && !p[a]) {
					var b;
					b = "print" === a ? u : "include" === a ? v : n[a] ? "$utils." + a : o[a] ? "$helpers." + a : "$data." + a, w += a + "=" + b + ",", p[a] = !0
				}
			}), b + "\n"
		}
		var g = d.debug,
			h = d.openTag,
			i = d.closeTag,
			j = d.parser,
			k = d.compress,
			l = d.escape,
			m = 1,
			p = {
				$data: 1,
				$filename: 1,
				$utils: 1,
				$helpers: 1,
				$out: 1,
				$line: 1
			},
			q = "".trim,
			s = q ? ["$out='';", "$out+=", ";", "$out"] : ["$out=[];", "$out.push(", ");", "$out.join('')"],
			t = q ? "$out+=text;return $out;" : "$out.push(text);",
			u = "function(){var text=''.concat.apply('',arguments);" + t + "}",
			v = "function(filename,data){data=data||$data;var text=$utils.$include(filename,data,$filename);" + t + "}",
			w = "'use strict';var $utils=this,$helpers=$utils.$helpers," + (g ? "$line=0," : ""),
			x = s[0],
			y = "return new String(" + s[3] + ");";
		r(c.split(h), function(a) {
			a = a.split(i);
			var b = a[0],
				c = a[1];
			1 === a.length ? x += e(b) : (x += f(b), c && (x += e(c)))
		});
		var z = w + x + y;
		g && (z = "try{" + z + "}catch(e){throw {filename:$filename,name:'Render Error',message:e.message,line:$line,source:" + b(c) + ".split(/\\n/)[$line-1].replace(/^\\s+/,'')};}");
		try {
			var A = new Function("$data", "$filename", z);
			return A.prototype = n, A
		} catch (B) {
			throw B.temp = "function anonymous($data,$filename) {" + z + "}", B
		}
	}
	var d = function(a, b) {
			return "string" == typeof b ? q(b, {
				filename: a
			}) : g(a, b)
		};
	d.version = "3.0.0", d.config = function(a, b) {
		e[a] = b
	};
	var e = d.defaults = {
		openTag: "<%",
		closeTag: "%>",
		escape: !0,
		cache: !0,
		compress: !1,
		parser: null
	},
		f = d.cache = {};
	d.render = function(a, b) {
		return q(a, b)
	};
	var g = d.renderFile = function(a, b) {
			var c = d.get(a) || p({
				filename: a,
				name: "Render Error",
				message: "atemplate not found"
			});
			return b ? c(b) : c
		};
	d.get = function(a) {
		var b;
		if (f[a]) b = f[a];
		else if ("object" == typeof document) {
			var c = document.getElementById(a);
			if (c) {
				var d = (c.value || c.innerHTML).replace(/^\s*|\s*$/g, "");
				b = q(d, {
					filename: a
				})
			}
		}
		return b
	};
	var h = function(a, b) {
			return "string" != typeof a && (b = typeof a, "number" === b ? a += "" : a = "function" === b ? h(a.call(a)) : ""), a
		},
		i = {
			"<": "&#60;",
			">": "&#62;",
			'"': "&#34;",
			"'": "&#39;",
			"&": "&#38;"
		},
		j = function(a) {
			return i[a]
		},
		k = function(a) {
			return h(a).replace(/&(?![\w#]+;)|[<>"']/g, j)
		},
		l = Array.isArray ||
	function(a) {
		return "[object Array]" === {}.toString.call(a)
	}, m = function(a, b) {
		var c, d;
		if (l(a)) for (c = 0, d = a.length; d > c; c++) b.call(a, a[c], c, a);
		else for (c in a) b.call(a, a[c], c)
	}, n = d.utils = {
		$helpers: {},
		$include: g,
		$string: h,
		$escape: k,
		$each: m
	};
	d.helper = function(a, b) {
		o[a] = b
	};
	var o = d.helpers = n.$helpers;
	d.onerror = function(a) {
		var b = "";
		for (var c in a) b += "<" + c + ">\n" + a[c] + "\n\n";
		"object" == typeof console && console.error(b)
	};
	var p = function(a) {
			return d.onerror(a), function() {
				return ""
			}
		},
		q = d.compile = function(a, b) {
			function d(c) {
				try {
					return new i(c, h) + ""
				} catch (d) {
					return b.debug ? p(d)() : (b.debug = !0, q(a, b)(c))
				}
			}
			b = b || {};
			for (var g in e) void 0 === b[g] && (b[g] = e[g]);
			var h = b.filename;
			try {
				var i = c(a, b)
			} catch (j) {
				return j.filename = h || "anonymous", j.name = "Syntax Error", p(j)
			}
			return d.prototype = i.prototype, d.toString = function() {
				return i.toString()
			}, h && b.cache && (f[h] = d), d
		},
		r = n.$each,
		s = "break,case,catch,continue,debugger,default,delete,do,else,false,finally,for,function,if,in,instanceof,new,null,return,switch,this,throw,true,try,typeof,var,void,while,with,abstract,boolean,byte,char,class,const,double,enum,export,extends,final,float,goto,implements,import,int,interface,long,native,package,private,protected,public,short,static,super,synchronized,throws,transient,volatile,arguments,let,yield,undefined",
		t = /\/\*[\w\W]*?\*\/|\/\/[^\n]*\n|\/\/[^\n]*$|"(?:[^"\\]|\\[\w\W])*"|'(?:[^'\\]|\\[\w\W])*'|\s*\.\s*[$\w\.]+/g,
		u = /[^\w$]+/g,
		v = new RegExp(["\\b" + s.replace(/,/g, "\\b|\\b") + "\\b"].join("|"), "g"),
		w = /^\d[^,]*|,\d[^,]*/g,
		x = /^,+|,+$/g;
	e.openTag = "{{", e.closeTag = "}}";
	var y = function(a, b) {
			var c = b.split(":"),
				d = c.shift(),
				e = c.join(":") || "";
			return e && (e = ", " + e), "$helpers." + d + "(" + a + e + ")"
		};
	e.parser = function(a, b) {
		a = a.replace(/^\s/, "");
		var c = a.split(" "),
			e = c.shift(),
			f = c.join(" ");
		switch (e) {
		case "if":
			a = "if(" + f + "){";
			break;
		case "else":
			c = "if" === c.shift() ? " if(" + c.join(" ") + ")" : "", a = "}else" + c + "{";
			break;
		case "/if":
			a = "}";
			break;
		case "each":
			var g = c[0] || "$data",
				h = c[1] || "as",
				i = c[2] || "$value",
				j = c[3] || "$index",
				k = i + "," + j;
			"as" !== h && (g = "[]"), a = "$each(" + g + ",function(" + k + "){";
			break;
		case "/each":
			a = "});";
			break;
		case "echo":
			a = "print(" + f + ");";
			break;
		case "print":
		case "include":
			a = e + "(" + c.join(",") + ");";
			break;
		default:
			if (-1 !== f.indexOf("|")) {
				var l = b.escape;
				0 === a.indexOf("#") && (a = a.substr(1), l = !1);
				for (var m = 0, n = a.split("|"), o = n.length, p = l ? "$escape" : "$string", q = p + "(" + n[m++] + ")"; o > m; m++) q = y(q, n[m]);
				a = "=#" + q
			} else a = d.helpers[e] ? "=#" + e + "(" + c.join(",") + ");" : "=" + a
		}
		return a
	}, "function" == typeof define ? define(function() {
		return d
	}) : "undefined" != typeof exports ? module.exports = d : this.atemplate = d;
	atemplate.config('openTag', "{");
	atemplate.config('closeTag', "}");
}();
if (!Date.prototype.Format) {
	Date.prototype.Format = function(fmt) {
		var o = {
			"M+": this.getMonth() + 1,
			"d+": this.getDate(),
			"h+": this.getHours(),
			"m+": this.getMinutes(),
			"s+": this.getSeconds(),
			"q+": Math.floor((this.getMonth() + 3) / 3),
			"S": this.getMilliseconds()
		};
		if (/(y+)/.test(fmt)) {
			fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length))
		}
		for (var k in o) {
			if (new RegExp("(" + k + ")").test(fmt)) {
				fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)))
			}
		}
		return fmt
	}
};
(function(t, u) {
	function v(b) {
		return function(c) {
			return Object.prototype.toString.call(c) === "[object " + b + "]"
		}
	}
	function Q() {
		return w++
	}
	function I(b, c) {
		var a;
		a = b.charAt(0);
		if (R.test(b)) a = b;
		else if ("." === a) {
			a = (c ? c.match(E)[0] : h.cwd) + b;
			for (a = a.replace(S, "/"); a.match(J);) a = a.replace(J, "/")
		} else a = "/" === a ? (a = h.cwd.match(T)) ? a[0] + b.substring(1) : b : h.base + b;
		return a
	}
	function K(b, c) {
		if (!b) return "";
		var a = b,
			d = h.alias,
			a = b = d && F(d[a]) ? d[a] : a,
			d = h.paths,
			g;
		if (d && (g = a.match(U)) && F(d[g[1]])) a = d[g[1]] + g[2];
		g = a;
		var e = h.vars;
		e && -1 < g.indexOf("{") && (g = g.replace(V, function(a, b) {
			return F(e[b]) ? e[b] : a
		}));
		a = g.length - 1;
		d = g.charAt(a);
		b = "#" === d ? g.substring(0, a) : ".js" === g.substring(a - 2) || 0 < g.indexOf("?") || ".css" === g.substring(a - 3) || "/" === d ? g : g + ".js";
		g = I(b, c);
		var a = h.map,
			l = g;
		if (a) for (var d = 0, f = a.length; d < f && !(l = a[d], l = x(l) ? l(g) || g : g.replace(l[0], l[1]), l !== g); d++);
		return l
	}
	function L(b, c) {
		var a = b.sheet,
			d;
		if (M) a && (d = !0);
		else if (a) try {
			a.cssRules && (d = !0)
		} catch (g) {
			"NS_ERROR_DOM_SECURITY_ERR" === g.name && (d = !0)
		}
		setTimeout(function() {
			d ? c() : L(b, c)
		}, 20)
	}
	function W() {
		if (y) return y;
		if (z && "interactive" === z.readyState) return z;
		for (var b = s.getElementsByTagName("script"), c = b.length - 1; 0 <= c; c--) {
			var a = b[c];
			if ("interactive" === a.readyState) return z = a
		}
	}
	function e(b, c) {
		this.uri = b;
		this.dependencies = c || [];
		this.exports = null;
		this.status = 0;
		this._waitings = {};
		this._remain = 0
	}
	if (!t.seajs) {
		var f = t.seajs = {
			version: "2.1.1"
		},
			h = f.data = {},
			X = v("Object"),
			F = v("String"),
			A = Array.isArray || v("Array"),
			x = v("Function"),
			w = 0,
			p = h.events = {};
		f.on = function(b, c) {
			(p[b] || (p[b] = [])).push(c);
			return f
		};
		f.off = function(b, c) {
			if (!b && !c) return p = h.events = {}, f;
			var a = p[b];
			if (a) if (c) for (var d = a.length - 1; 0 <= d; d--) a[d] === c && a.splice(d, 1);
			else delete p[b];
			return f
		};
		var m = f.emit = function(b, c) {
				var a = p[b],
					d;
				if (a) for (a = a.slice(); d = a.shift();) d(c);
				return f
			},
			E = /[^?#]*\//,
			S = /\/\.\//g,
			J = /\/[^/]+\/\.\.\//,
			U = /^([^/:]+)(\/.+)$/,
			V = /{([^{]+)}/g,
			R = /^\/\/.|:\//,
			T = /^.*?\/\/.*?\//,
			n = document,
			q = location,
			B = q.href.match(E)[0],
			k = n.getElementsByTagName("script"),
			k = n.getElementById("seajsnode") || k[k.length - 1],
			k = ((k.hasAttribute ? k.src : k.getAttribute("src", 4)) || B).match(E)[0],
			s = n.getElementsByTagName("head")[0] || n.documentElement,
			N = s.getElementsByTagName("base")[0],
			O = /\.css(?:\?|$)/i,
			Y = /^(?:loaded|complete|undefined)$/,
			y, z, M = 536 > 1 * navigator.userAgent.replace(/.*AppleWebKit\/(\d+)\..*/, "$1"),
			Z = /"(?:\\"|[^"])*"|'(?:\\'|[^'])*'|\/\*[\S\s]*?\*\/|\/(?:\\\/|[^\/\r\n])+\/(?=[^\/])|\/\/.*|\.\s*require|(?:^|[^$])\brequire\s*\(\s*(["'])(.+?)\1\s*\)/g,
			$ = /\\\\/g,
			r = f.cache = {},
			C, G = {},
			H = {},
			D = {},
			j = e.STATUS = {
				FETCHING: 1,
				SAVED: 2,
				LOADING: 3,
				LOADED: 4,
				EXECUTING: 5,
				EXECUTED: 6
			};
		e.prototype.resolve = function() {
			for (var b = this.dependencies, c = [], a = 0, d = b.length; a < d; a++) c[a] = e.resolve(b[a], this.uri);
			return c
		};
		e.prototype.load = function() {
			if (!(this.status >= j.LOADING)) {
				this.status = j.LOADING;
				var b = this.resolve();
				m("load", b);
				for (var c = this._remain = b.length, a, d = 0; d < c; d++) a = e.get(b[d]), a.status < j.LOADED ? a._waitings[this.uri] = (a._waitings[this.uri] || 0) + 1 : this._remain--;
				if (0 === this._remain) this.onload();
				else {
					for (var g = {}, d = 0; d < c; d++) a = r[b[d]], a.status < j.FETCHING ? a.fetch(g) : a.status === j.SAVED && a.load();
					for (var h in g) if (g.hasOwnProperty(h)) g[h]()
				}
			}
		};
		e.prototype.onload = function() {
			this.status = j.LOADED;
			this.callback && this.callback();
			var b = this._waitings,
				c, a;
			for (c in b) if (b.hasOwnProperty(c) && (a = r[c], a._remain -= b[c], 0 === a._remain)) a.onload();
			delete this._waitings;
			delete this._remain
		};
		e.prototype.fetch = function(b) {
			function c() {
				var a = g.requestUri,
					b = g.onRequest,
					c = g.charset,
					d = O.test(a),
					e = n.createElement(d ? "link" : "script");
				if (c && (c = x(c) ? c(a) : c)) e.charset = c;
				var f = e;
				d && (M || !("onload" in f)) ? setTimeout(function() {
					L(f, b)
				}, 1) : f.onload = f.onerror = f.onreadystatechange = function() {
					Y.test(f.readyState) && (f.onload = f.onerror = f.onreadystatechange = null, !d && !h.debug && s.removeChild(f), f = null, b())
				};
				d ? (e.rel = "stylesheet", e.href = a) : (e.async = !0, e.src = a);
				y = e;
				N ? s.insertBefore(e, N) : s.appendChild(e);
				y = null
			}
			function a() {
				delete G[f];
				H[f] = !0;
				C && (e.save(d, C), C = null);
				var a, b = D[f];
				for (delete D[f]; a = b.shift();) a.load()
			}
			var d = this.uri;
			this.status = j.FETCHING;
			var g = {
				uri: d
			};
			m("fetch", g);
			var f = g.requestUri || d;
			!f || H[f] ? this.load() : G[f] ? D[f].push(this) : (G[f] = !0, D[f] = [this], m("request", g = {
				uri: d,
				requestUri: f,
				onRequest: a,
				charset: h.charset
			}), g.requested || (b ? b[g.requestUri] = c : c()))
		};
		e.prototype.exec = function() {
			function b(a) {
				return e.get(b.resolve(a)).exec()
			}
			if (this.status >= j.EXECUTING) return this.exports;
			this.status = j.EXECUTING;
			var c = this.uri;
			b.resolve = function(a) {
				return e.resolve(a, c)
			};
			b.async = function(a, g) {
				e.use(a, g, c + "_async_" + w++);
				return b
			};
			var a = this.factory,
				a = x(a) ? a(b, this.exports = {}, this) : a;
			a === u && (a = this.exports);
			null === a && !O.test(c) && m("error", this);
			delete this.factory;
			this.exports = a;
			this.status = j.EXECUTED;
			m("exec", this);
			return a
		};
		e.resolve = function(b, c) {
			var a = {
				id: b,
				refUri: c
			};
			m("resolve", a);
			return a.uri || K(a.id, c)
		};
		e.define = function(b, c, a) {
			var d = arguments.length;
			1 === d ? (a = b, b = u) : 2 === d && (a = c, A(b) ? (c = b, b = u) : c = u);
			if (!A(c) && x(a)) {
				var g = [];
				a.toString().replace($, "").replace(Z, function(a, b, c) {
					c && g.push(c)
				});
				c = g
			}
			d = {
				id: b,
				uri: e.resolve(b),
				deps: c,
				factory: a
			};
			if (!d.uri && n.attachEvent) {
				var f = W();
				f && (d.uri = f.src)
			}
			m("define", d);
			d.uri ? e.save(d.uri, d) : C = d
		};
		e.save = function(b, c) {
			var a = e.get(b);
			a.status < j.SAVED && (a.id = c.id || b, a.dependencies = c.deps || [], a.factory = c.factory, a.status = j.SAVED)
		};
		e.get = function(b, c) {
			return r[b] || (r[b] = new e(b, c))
		};
		e.use = function(b, c, a) {
			var d = e.get(a, A(b) ? b : [b]);
			d.callback = function() {
				for (var a = [], b = d.resolve(), e = 0, f = b.length; e < f; e++) a[e] = r[b[e]].exec();
				c && c.apply(t, a);
				delete d.callback
			};
			d.load()
		};
		e.preload = function(b) {
			var c = h.preload,
				a = c.length;
			a ? e.use(c, function() {
				c.splice(0, a);
				e.preload(b)
			}, h.cwd + "_preload_" + w++) : b()
		};
		f.use = function(b, c) {
			e.preload(function() {
				e.use(b, c, h.cwd + "_use_" + w++)
			});
			return f
		};
		e.define.cmd = {};
		t.define = e.define;
		f.Module = e;
		h.fetchedList = H;
		h.cid = Q;
		f.resolve = K;
		f.require = function(b) {
			return (r[e.resolve(b)] || {}).exports
		};
		h.base = (k.match(/^(.+?\/)(\?\?)?(seajs\/)+/) || ["", k])[1];
		h.dir = k;
		h.cwd = B;
		h.charset = "utf-8";
		var B = h,
			P = [],
			q = q.search.replace(/(seajs-\w+)(&|$)/g, "$1=1$2"),
			q = q + (" " + n.cookie);
		q.replace(/(seajs-\w+)=1/g, function(b, c) {
			P.push(c)
		});
		B.preload = P;
		f.config = function(b) {
			for (var c in b) {
				var a = b[c],
					d = h[c];
				if (d && X(d)) for (var e in a) d[e] = a[e];
				else A(d) ? a = d.concat(a) : "base" === c && ("/" === a.slice(-1) || (a += "/"), a = I(a)), h[c] = a
			}
			m("config", b);
			return f
		}
	}
})(this);
!
function() {
	function a(a) {
		h[a.name] = a
	}
	function b(a) {
		return a && h.hasOwnProperty(a)
	}
	function c(a) {
		for (var c in h) if (b(c)) {
			var d = "," + h[c].ext.join(",") + ",";
			if (d.indexOf("," + a + ",") > -1) return c
		}
	}
	function d(a, b) {
		var c = g.ActiveXObject ? new g.ActiveXObject("Microsoft.XMLHTTP") : new g.XMLHttpRequest;
		return c.open("GET", a, !0), c.onreadystatechange = function() {
			if (4 === c.readyState) {
				if (c.status > 399 && c.status < 600) throw new Error("Could not load: " + a + ", status = " + c.status);
				b(c.responseText)
			}
		}, c.send(null)
	}
	function e(a) {
		a && /\S/.test(a) && (g.execScript ||
		function(a) {
			(g.eval || eval).call(g, a)
		})(a)
	}
	function f(a) {
		return a.replace(/(["\\])/g, "\\$1").replace(/[\f]/g, "\\f").replace(/[\b]/g, "\\b").replace(/[\n]/g, "\\n").replace(/[\t]/g, "\\t").replace(/[\r]/g, "\\r").replace(/[]/g, "\ ").replace(/[ ]/g, "\ ")
	}
	var g = window,
		h = {},
		i = {};
	a({
		name: "text",
		ext: [".tpl", ".html"],
		exec: function(a, b) {
			e('define("' + a + '#", [], "' + f(b) + '")')
		}
	}), a({
		name: "json",
		ext: [".json"],
		exec: function(a, b) {
			e('define("' + a + '#", [], ' + b + ")")
		}
	}), a({
		name: "handlebars",
		ext: [".handlebars"],
		exec: function(a, b) {
			var c = ['define("' + a + '#", ["handlebars"], function(require, exports, module) {', '  var source = "' + f(b) + '"', '  var Handlebars = require("handlebars")', "  module.exports = function(data, options) {", "    options || (options = {})", "    options.helpers || (options.helpers = {})", "    for (var key in Handlebars.helpers) {", "      options.helpers[key] = options.helpers[key] || Handlebars.helpers[key]", "    }", "    return Handlebars.compile(source)(data, options)", "  }", "})"].join("\n");
			e(c)
		}
	}), seajs.on("resolve", function(a) {
		var d = a.id;
		if (!d) return "";
		var e, f;
		(f = d.match(/^(\w+)!(.+)$/)) && b(f[1]) ? (e = f[1], d = f[2]) : (f = d.match(/[^?]+(\.\w+)(?:\?|#|$)/)) && (e = c(f[1])), e && -1 === d.indexOf("#") && (d += "#");
		var g = seajs.resolve(d, a.refUri);
		e && (i[g] = e), a.uri = g
	}), seajs.on("request", function(a) {
		var b = i[a.uri];
		b && (d(a.requestUri, function(c) {
			h[b].exec(a.uri, c), a.onRequest()
		}), a.requested = !0)
	}), define("seajs/seajs-text/1.0.2/seajs-text", [], {})
}();
!
function() {
	if (!window.console) {
		window.console = {};
		window.console.log = function() {};
	}
	window.isOpen524 = false;
	// global version
	var verCtrol = 'v2018122121';
	var fCtrol = 'v2018122121';
	var protocol = location.protocol.indexOf('http') > -1 ? '' : 'http:';
	// var tmpVer = Math.ceil(new Date().getTime() / 60000) * 1;
	var tmpVer = verCtrol;
	// merge file versons
	var mergeVer = verCtrol;
	// homepage merge js file
	var homepageTmplJS = ['/js/modules/modules/view.js', '/js/modules/lib/jquery-1.7.2.min.js', '/js/modules/lib/underscore-min.js', '/js/modules/plugin/ui-slides.js', '/js/modules/plugin5/slider.js', '/js/modules/plugin5/ui-calendar-v5.js', '/js/modules/plugin5/ui-datepicker-v5.js', '/js/modules/plugin5/ui-citytip.js', '/js/modules/plugin5/ui-dialog.js', '/js/modules/plugin5/ui-swiper.js', '/js/modules/plugin5/ui-person-selector.js', '/js/modules/plugin5/listView.js', '/js/modules/plugin5/ui-inputtip.js', '/js/modules/plugin5/ui-ripple-touch.js', '/js/modules/plugin5/ui-travel-city-list.js', '/js/modules/plugin/ui-overlay.js', '/js/modules/site5/sso.js', '/js/modules/site5/fn-head.js', '/js/modules/plugin5/fn-cookieManage.js'].join(",");
	var flightDateJS = ['/Content/jointdata.js', '/Content/lyflydate.js', '/Content/flydate.js', '/Content/lybusflydate.js'].join(",");
	// flight plugin merge file
	var flightTmplJS = ['/js/modules/modules/view.js', '/js/modules/lib/jquery-1.7.2.min.js', '/js/modules/lib/underscore-min.js', '/js/modules/plugin/ui-slides.js', '/js/modules/plugin5/vi-datepicker.js', '/js/modules/plugin5/ui-citytip.js', '/js/modules/plugin5/ui-dialog.js', '/js/modules/plugin5/ui-person-selector.js', '/js/modules/plugin/ui-overlay.js', '/js/modules/plugin5/vi-calendar.js', '/js/modules/plugin5/si-calendar.js', '/js/modules/plugin5/si-datepicker.js'].join(",");
	//ticket-hotels-v3 merge file
	var tichethotelTmplJS = ['/js/modules/modules/view.js', '/js/modules/lib/jquery-1.7.2.min.js', '/js/modules/lib/underscore-min.js', '/js/modules/site/fn-searchform.js', '/js/modules/site/fn-cart.js', '/js/modules/site/fn-cabinrules.js', '/js/modules/site/fn-hotel-date.js', '/js/modules/site/fn-hotel-city.js', '/js/modules/plugin/ui-scrollfix.js', '/js/modules/plugin/ui-citytip.js', '/js/modules/plugin/ui-selection.js', '/js/modules/plugin/ui-slides.js', '/js/modules/plugin/ui-datepicker.js', '/js/modules/plugin/ui-placeholder.js', '/js/modules/plugin5/ui-radio-selector.js', '/js/modules/plugin5/fn-changePolicy.js', '/js/modules/site5/fn-head.js', '/js/modules/plugin/ui-overlay.js', '/js/modules/site5/sso.js', '/js/modules/plugin5/ui-dialog.js', '/js/modules/plugin/ui-dialog.js', '/js/modules/plugin/ui-calendar.js', '/js/modules/site/fn-book-view.js'].join(",");

	var homepageJS = {},
		flightJS = {},
		tickethotelJS = {};
	var langs = ['zh-cn', 'zh-hk', 'en-us', 'ja-jp', 'ko-kr'],
		length = langs.length;
	for (var i = 0; i < length; i++) {
		var langFile = ['/js/modules/site5/lang-' + langs[i] + '.js', '/js/modules/data/citydict-' + langs[i] + '.js', '/js/modules/data/cityassort-' + langs[i] + '.js', '/js/modules/data/cityassort-' + langs[i] + '-v5.js', '/js/modules/site/lang-' + langs[i] + '.js'].join(",");
		var v = homepageTmplJS + "," + langFile;
		if (langs[i] == 'zh-cn') {
			v += "," + ['/js/modules/plugin5/ui-travel-city-depart.js', '/js/modules/plugin5/ui-travel-city-input.js'].join(",");
		}
		homepageJS[langs[i]] = v;
		flightJS[langs[i]] = flightTmplJS + "," + langFile;
		tickethotelJS[langs[i]] = tichethotelTmplJS + "," + langFile;
	}

	var mergeFile = function(url, updateByDay) {
			return protocol + '//ajax.springairlines.com/MergeFile/MergeFile?url=' + url + '&FileType=js&Version=' + mergeVer + '&IsMinify=true';
		};
	var mergeFileNoMinify = function(url, updateByDay) {
			return protocol + '//ajax.springairlines.com/MergeFile/MergeFile?url=' + url + '&FileType=js&Version=' + mergeVer + '&IsMinify=false';
		};

	// 海外
	var getSearch = function(hash) {
			if (!hash || hash.split("?").length < 2) {
				return {};
			}
			var pairs = hash.split("?")[1].split("&"),
				length = pairs.length,
				params = {};
			for (var i = 0; i < length; i++) {
				var pair = pairs[i].split("=");
				params[pair[0]] = pair[1] ? pair[1] : null;
			}
			return params;
		};
	window.gInternational = false, params = {};
	if (document.currentScript) {
		params = getSearch(document.currentScript.src);
	} else {
		var reg = new RegExp(/sea-master5/),
			length = document.scripts.length;
		for (var i = 0; i < length; i++) {
			if (reg.test(document.scripts[i].src)) {
				params = getSearch(document.scripts[i].src);
				break;
			}
		}
	}
	if (params.cdnurlarea == 1) {
		window.gInternational = true;
	}
	var NOW = new Date();
	var formateD = function(d) {
			return d > 9 ? "" + d : "0" + d;
		}
		//模块全局配置
		seajs.config({
			base: 'modules',
			alias: {
				'jquery': 'lib/jquery-1.7.2.min',
				'backbone': 'lib/backbone-min',
				'underscore': 'lib/underscore-min',
				'easing': 'lib/jquery-easing.min',
				'rotate': 'lib/jquery-rotate-2.2.min',
				'highcharts': 'lib/highcharts',
				'flydatedata': protocol + '//ajax.springairlines.com/Content/flydate.js?vs=' + new Date().getTime(),
				'jointdata': protocol + '//ajax.springairlines.com/Content/jointdata.js?vs=' + Math.ceil(new Date().getTime() / 86400000),
				'lyflydate': protocol + '//ajax.springairlines.com/Content/lyflydate.js?vs=' + Math.ceil(new Date().getTime() / 86400000),
				'lybusflydate': protocol + '//ajax.springairlines.com/Content/lybusflydate.js?vs=' + Math.ceil(new Date().getTime() / 86400000),
				'flexible': '//ajax.springairlines.com/MergeFile/MergeFile?url=/js/modules/lib/flexible.js?vs=2016092705&FileType=js&Version=1.1.1&IsMinify=true',
				'view': 'modules/view',
				'skype': 'modules/skype-uri-dev',
				'auth': protocol + '//ajax.springairlines.com/js/api/auth.js?pn=9C00211312241938530009&return_url=' + location.protocol + '//' + location.host + '/sso/Login&lang={lang}&vs=' + Math.ceil(new Date().getTime() / 86400000),
				'ui-scrollbar': 'plugin/ui-scrollbar',
				'ui-scrollfix': 'plugin/ui-scrollfix',
				'ui-selection': 'plugin/ui-selection',
				'ui-dialog': 'plugin/ui-dialog',
				'ui-overlay': 'plugin/ui-overlay',
				'ui-placeholder': 'plugin/ui-placeholder',
				'ui-tip': 'plugin/ui-tip',
				'ui-slides': 'plugin/ui-slides',
				'ui-roller': 'plugin/ui-roller',
				'ui-calendar': 'plugin/ui-calendar',
				'ui-datepicker': 'plugin/ui-datepicker',
				'ui-citytip': 'plugin/ui-citytip.js',
				'ui-citytipOld': 'plugin/ui-citytipOld.js',
				'plugin/ui-festival': 'plugin/ui-festival.js?vs=2017012011',
				'si-calendar': 'plugin5/si-calendar',
				'si-datepicker': 'plugin5/si-datepicker',
				'vi-city': 'plugin5/vi-city.js',
				'fn-filepreview': 'plugin/fn-filepreview',
				'fn-validate': 'plugin/fn-validate',
				'fn-cityrelated': 'plugin/fn-cityrelated',
				'app/main-search-tickethotels-v3': 'app/main-search-tickethotels-v3.js',
				'app/main-search-tickethotels-v3-merge': mergeFileNoMinify(['/js/modules/site/main-search-tickethotels-v3.js', '/springairlines/scripts/site/zh/g-base.js', '/springairlines/scripts/site/zh/c-hotel.js']),
				'app/main-search': 'app/main-search.js',
				'app/fn-cart': 'app/fn-cart.js',
				'app/fn-paycodes': 'app/fn-paycodes.js?vs=' + new Date().getTime(),
				'app5/listView': 'plugin5/listView.js',
				'fn-flight': 'plugin5/fn-flight.js=20161130',
				'ui-calendar5': 'plugin5/ui-calendar',
				'vi-calendar': 'plugin5/vi-calendar.js',
				'vi-datepicker': 'plugin5/vi-datepicker.js',
				'vi-citytip': 'plugin5/vi-citytip.js',
				'app5/fn-hotel-city': 'plugin5/fn-hotel-city.js',
				'app5/main-search': 'app5/main-search.js',
				'app5/main-search-new': 'app5/main-search-new.js',
				'app5/flight-search': 'app5/flight-search.js',
				'app5/fn-head': 'app5/fn-head.js',
				'app5/slider': 'plugin5/slider.js',
				'ui-dialog5': 'plugin5/ui-dialog',
				'app5/fn-mobile': 'plugin5/fn-mobile.js',
				'ui-inputtip': 'plugin5/ui-inputtip.js',
				'ui-travel-city-depart': 'plugin5/ui-travel-city-depart.js',
				'ui-travel-city-input': 'plugin5/ui-travel-city-input.js',
				'ui-swiper': 'plugin5/ui-swiper.js',
				'ui-iScroll': 'plugin5/ui-iScroll.js',
				'ui-person-selector': 'plugin5/ui-person-selector.js',
				//'main-home': 'site5/main-home.js',
				'main-home': mergeFile('/js/modules/site5/main-home.js'),
				'main-flight-status': 'site5/main-flight-status.js',
				'main-orderList': 'site5/main-orderList.js',
				'main-order-detail': 'site5/main-order-detail.js',
				'main-person-management': 'site5/main-person-management.js',
				'main-login': 'site5/main-login.js',
				'main-home-merge-zh-cn': mergeFile(homepageJS['zh-cn']),
				'main-home-merge-zh-hk': mergeFile(homepageJS['zh-hk']),
				'main-home-merge-en-us': mergeFile(homepageJS['en-us']),
				'main-home-merge-ja-jp': mergeFile(homepageJS['ja-jp']),
				'main-home-merge-ko-kr': mergeFile(homepageJS['ko-kr']),
				'flight-plugin-zh-cn': mergeFile(flightJS['zh-cn']),
				'flight-plugin-zh-hk': mergeFile(flightJS['zh-hk']),
				'flight-plugin-en-us': mergeFile(flightJS['en-us']),
				'flight-plugin-ja-jp': mergeFile(flightJS['ja-jp']),
				'flight-plugin-ko-kr': mergeFile(flightJS['ko-kr']),
				'main-tichethotels-merge-zh-cn': mergeFile(tickethotelJS['zh-cn']),
				'main-tichethotels-merge-zh-hk': mergeFile(tickethotelJS['zh-hk']),
				'main-tichethotels-merge-en-us': mergeFile(tickethotelJS['en-us']),
				'main-tichethotels-merge-ja-jp': mergeFile(tickethotelJS['ja-jp']),
				'main-tichethotels-merge-ko-kr': mergeFile(tickethotelJS['ko-kr']),
				'flight-date-merge': protocol + '//ajax.springairlines.com/Content/FlightDateMergeJs.js?vs=' + fCtrol + NOW.getUTCFullYear() + formateD(NOW.getUTCMonth()) + formateD(NOW.getUTCDate()) + formateD(NOW.getUTCHours()),
				'orderdetails': 'site5/orderdetails.js',
				'fn-openapp': 'plugin5/fn-openapp.js',
				'getcoupon': 'site5/getcoupon.js',
				//回数券相关
				'app5/flight-search-hsq-ex': 'app5/flight-search-hsq-ex.js',
				'app5/main-search-new-hsq': 'app5/main-search-new-hsq.js',
				'main-home-hsq': 'site5/main-home-hsq.js',
				'app/main-search-hsq': 'app/main-search-hsq.js',
				'ui-citytip-hsq': 'plugin/ui-citytip-hsq.js',
				'tmpl-search-v5-hsq': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-search-v5-hsq.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-search-mobile-v5-hsq': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-search-mobile-v5-hsq.html%3Fvs=' + tmpVer + '&callback=define',
				//日文老年人专享优惠活动
				'tmpl-search-v5-act': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-search-v5-act.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-search-mobile-v5-act': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-search-mobile-v5-act.html%3Fvs=' + tmpVer + '&callback=define',
				// 5.1 Account
				'main-account-info': 'site5/account/main-account-info.js',
				'main-account-info-edit': 'site5/account/main-account-info-edit.js',
				'main-account-info-paper': 'site5/account/main-account-info-paper.js',
				'main-account-info-ali': 'site5/account/main-account-info-ali.js',
				'main-account-passenger': 'site5/account/main-account-passenger.js',
				'main-account-passenger-edit': 'site5/account/main-account-passenger-edit.js',
				'main-account-share': 'site5/account/main-account-share.js',
				'main-account-regist': 'site5/account/main-account-regist.js',
				'main-account-regist-phone': 'site5/account/main-account-regist-phone.js',
				'main-account-overview': 'site5/account/main-account-overview.js',
				'main-account-safe-id-reset': 'site5/account/main-account-safe-id-reset.js',
				'main-account-safe-index': 'site5/account/main-account-safe-index.js',
				'main-account-safe-loginpass': 'site5/account/main-account-safe-loginpass.js',
				'main-account-safe-setting': 'site5/account/main-account-safe-setting.js',
				'main-account-safe-questionbind': 'site5/account/main-account-safe-questionbind.js',
				'main-account-safe-update-email': 'site5/account/main-account-safe-update-email.js',
				'main-account-safe-update-phone': 'site5/account/main-account-safe-update-phone.js',
				'main-member-equity': 'site5/account/main-member-equity.js',
				'main-account-tong': 'site5/account/main-account-tong.js',
				'main-account-related': 'site5/account/main-account-related.js',
				'account-score-details': 'site5/account/account-score-details.js',
				'account-score-edit': 'site5/account/account-score-edit.js',
				'account-score-index': 'site5/account/account-score-index.js',
				'account-score-list': 'site5/account/account-score-list.js',
				'account-orderlist': 'site5/account/account-orderlist.js',
				'main-account-coupon-index': 'site5/account/main-account-coupon-index.js',
				'account-score-details-new': 'site5/account/account-score-details-new.js',
				'main-account-info-certificate': 'site5/account/main-account-info-certificate.js',
				'main-account-benifit': 'site5/account/main-account-benifit',
				'tmpl-account-certificate': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fsite5%2Faccount%2Ftmpl-account-certificate.html%3Fvs=' + tmpVer + '&callback=define',

				//4.0机加酒相关
				'tmpl-ticket': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-ticket.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-disney': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-disney.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-single-increases': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-single-increases.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-increases': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-increases.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-seat': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-seat.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-food': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-food.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-increases-v5': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-increases-v5.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-increasesJP-v5': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-increasesJP-v5.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-increasesCn-v5': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-increasesCn-v5.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-g-base': 'https://ajax.springairlines.com/cache/springairlines/scripts/site/zh/g-base.js?vs=' + fCtrol,
				'tmpl-c-hotel': 'https://ajax.springairlines.com/cache/springairlines/scripts/site/zh/c-hotel.js?vs=' + fCtrol,

				'tmpl-individualinlet-v5': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-individualinlet-v5.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-book-confirm-v5': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-book-confirm-v5.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-book-confirm-mobile-v5': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-book-confirm-mobile-v5.html%3Fvs=' + tmpVer + '&callback=define',

				//'tmpl-faq': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-faq.html%3Fvs=' + tmpVer + '&callback=define',

				//搜索相关
				'tmpl-search-v5': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-search-v5.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-search-mobile-v5': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-search-mobile-v5.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-searchJP-v5': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-searchJP-v5.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-searchJP-mobile-v5': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-searchJP-mobile-v5.html%3Fvs=' + tmpVer + '&callback=define',

				'tmpl-price-calendar-v5': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-price-calendar-v5.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-search-flight-new': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fsite5%2Fsearch%2Ftmpl-search-flight-new.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-flighthotel-v5': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-flighthotel-v5.html%3Fvs=' + tmpVer + '&callback=define',
				'main-search-tickethotels-v3-html': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Fmain-search-tickethotels-v3.html%3Fvs=' + tmpVer + '&callback=define',
				//支付页订单详情
				'tmpl-pay-order-detail-pc': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-pay-order-detail-pc.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-pay-order-detail-m': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-pay-order-detail-m.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-pay-flight-pc': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-pay-flight-pc.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-pay-flight-m': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-pay-flight-m.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-pay-desc': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-pay-desc.html%3Fvs=' + tmpVer + '&callback=define',
				'tmpl-search-box': 'https://ajax.springairlines.com/Convert/GetNewUrlContent/?path=http%3A%2F%2Fajax.springairlines.com%2Fcache%2Fjs%2Fmodules%2Fdata%2Ftmpl-search-box.html%3Fvs=' + tmpVer + '&callback=define'

			},
			paths: {
				app: 'site',
				app5: 'site5'
			},
			map: [
				[/\.js(?!\?)(?!\,)(?!\&)/, '.js?vs=' + verCtrol]
			],

			vars: {
				lang: 'zh-cn',
				paths: {
					'zh-cn': '',
					'zh-hk': 'big5',
					'en-us': 'en',
					'ko-kr': 'kr',
					'th-th': 'th'
				},
				mappath: {
					'zh-cn': 0,
					'zh-hk': 2,
					'en-us': 1,
					'ko-kr': 16,
					'th-th': 10,
					"ja-jp": 4
				}
			},

			preload: [
			this.JSON ? null : 'lib/json2.min']
		});
}();

RATE = {
	"THB": 0.1886,
	"CNY": 1,
	"JPY": 0.0513,
	"USD": 6.1237,
	"HKD": 0.7896,
	"KRW": 0.0056,
	"MOP": 0.7783,
	"TWD": 0.195,
	"SGD": 4.6187
};

MoneyCode = {
	'0': 'CNY',
	'1': 'USD',
	'2': 'HKD',
	'4': 'JPY',
	'6': 'TWD',
	'10': 'SGD',
	'13': 'THB',
	'16': 'KRW',
	'00': 'CNY'
};

if (!Array.prototype.indexOf) {
	Array.prototype.indexOf = function(elt /*, from*/ ) {
		var len = this.length >>> 0;
		var from = Number(arguments[1]) || 0;
		from = (from < 0) ? Math.ceil(from) : Math.floor(from);
		if (from < 0) from += len;
		for (; from < len; from++) {
			if (from in this && this[from] === elt) return from;
		}
		return -1;
	};
}

//在PC网站的所有页面中，针对低版本浏览器，展示APP引导和浏览器升级引导。

function explorerTooLow() {
	var template = '<div class="show-add-shadow" id="popShadow" style="display:block"></div>' + '<div id="explorer2low" class="wrap">' + '<div class="hd">版本升级 <i class="iconfont" style="font-size:18px;" onclick="closePop()">&#xe652;</i></div>' + '<div class="bd"><p class="text">' + '尊敬的用户，您当前浏览器版本过低，会影响您的用户体验。建议您使用手机访问春航客户端浏览：' + '</p>' + '<p class="txt-center">' + '<img src="https://media.springairlines.com/cache/style/site5/img/qrcode/dibanben1.png" width="120" height="120" alt="">' + '</p>' + '<p class="text2">或升级浏览器：</p>' + '<p class="last-line"><a class="u-explorerBtn" href="http://www.google.cn/chrome/browser/desktop/" target="_blank"><img src="https://media.springairlines.com/cache/style/site5/img/qrcode/i-1.png" width="20" height="20" alt="">下载Chrome</a>' + '<a class="u-explorerBtn" href="http://www.firefox.com.cn/" target="_blank"><img src="https://media.springairlines.com/cache/style/site5/img/qrcode/i-2.png" width="20" height="20" alt="">下载Firefox</a>' + '</p>' + '</div>' + '</div>';

	var rules = ".show-add-shadow{display:none;width: 100%;height: 100%; position: fixed;top: 0;bottom: 0;left: 0;  z-index: 10000;background-color: #000;opacity: 0.7;filter:alpha(opacity=70);}" + "#explorer2low.wrap{width: 480px;position: fixed;z-index: 10001;top: 50%;left: 50%;margin-left: -240px;margin-top: -220px}" + "#explorer2low.wrap .hd{background: #00ab6f;color: #fff;padding:10px 20px;font-size: 16px }" + "#explorer2low.wrap .hd .iconfont{position: absolute;top: 10px;right: 20px;cursor: pointer}" + "#explorer2low.wrap .bd{padding: 40px;font-size:15px}" + "#explorer2low.wrap .bd .text{margin-bottom:30px}" + "#explorer2low.wrap .bd .txt-center{text-align: center;margin-bottom:30px}" + "#explorer2low.wrap .bd .text2{margin-bottom: 20px}" + "#explorer2low.wrap .bd .last-line{text-align: center;}" + "#explorer2low.wrap .bd .last-line img{margin-right:10px;vertical-align: middle;}" + "#explorer2low.wrap .bd .last-line .u-explorerBtn{width: 140px;height: 36px;display: inline-block;margin-right:20px;border: 1px solid #dddddd;line-height: 36px}" + "#explorer2low.wrap .bd .last-line .u-explorerBtn:hover{color: #00ab6f}";
	var styleElement = document.createElement('style');
	styleElement.type = "text/css";
	styleElement.styleSheet.cssText = rules;
	seajs.data.ifFirstViewFlash = 0;


	var timer = setInterval(function() {
		var body = document.getElementsByTagName('body')[0];
		var head = document.getElementsByTagName('head')[0];
		if (!getCookie("app2low")) {
			if (location.host == "www.ch.com" && location.pathname == "/") {
				if (getCookie("tooLowShow") || seajs.data.ifFirstViewFlash == 0) return
				head.appendChild(styleElement);
				body.insertAdjacentHTML('beforeend', template);
				setCookie("tooLowShow", 1, 1);
			} else {
				head.appendChild(styleElement);
				body.insertAdjacentHTML('beforeend', template);
			}
			clearInterval(timer);
		}
	}, 2000)

	setTimeout(function() {
		clearInterval(timer);
	}, 15000)

}


function closePop() {
	setCookie("app2low", 1, 1);
	document.getElementById('explorer2low').style.display = "none";
	document.getElementById('popShadow').style.display = "none";
}

function setCookie(c_name, value, expiredays) {
	var exdate = new Date();
	exdate.setDate(exdate.getDate() + expiredays);
	document.cookie = c_name + "=" + escape(value) + ((expiredays == null) ? "" : ";domain=.ch.com;path=/;expires=" + exdate.toGMTString());
}

function getCookie(c_name) {
	if (document.cookie.length > 0) {
		c_start = document.cookie.lastIndexOf(c_name + "=");
		if (c_start != -1) {
			c_start = c_start + c_name.length + 1;
			c_end = document.cookie.indexOf(";", c_start);
			if (c_end == -1) {
				c_end = document.cookie.length;
			}
			return unescape(document.cookie.substring(c_start, c_end));
		}
	}
	return "";
}

var hrefReg = /(?!.*hk.ch.com|.*zh_hk|.*en.ch.com|.*en_us|.*th.ch.com|.*th-TH|.*jp.ch.com|.*ja_jp|.*kr.ch.com|.*ko_kr|.*PopPC|.*AuthHepler)^.*$/;
if (hrefReg.test(window.location.href) && navigator.appName == "Microsoft Internet Explorer" && navigator.appVersion.split(";")[1].replace(/[ ]/g, "") == "MSIE6.0") {
	explorerTooLow()
} else if (hrefReg.test(window.location.href) && navigator.appName == "Microsoft Internet Explorer" && navigator.appVersion.split(";")[1].replace(/[ ]/g, "") == "MSIE7.0") {
	explorerTooLow();
} else if (hrefReg.test(window.location.href) && navigator.appName == "Microsoft Internet Explorer" && navigator.appVersion.split(";")[1].replace(/[ ]/g, "") == "MSIE8.0") {
	explorerTooLow();
}

(function() {
	//设置日文登陆dpi
	var _location = decodeURIComponent(decodeURIComponent(location.href));
	if (_location.indexOf("passport.ch.com/ja_jp/Login/Mobile2") > 0 && /jp\.ch\.com\/+flights/ig.test(_location)) {
		document.getElementsByTagName('html')[0].setAttribute('data-dpr', 1);
	}
	//等待事件处理逻辑
	var WaitEvent = function() {
			this.aEvent = this.aEvent || [];
			this.status = false;
		};
	WaitEvent.prototype = {
		dispatch: function() {
			//只触发一次然后每次都执行fn()因为全局对象拿到了
			if (!this.status) {
				this.status = true;
				if (this.aEvent) {
					for (var i = 0; i < this.aEvent.length; i++) {
						this.aEvent[i]();
					}
				}
			}
		},
		collect: function(fn) {
			if (!this.status) {
				this.aEvent.push(fn);
			} else {
				fn();
			}
		}
	};
	window.eventList = [];
	window.eventFactory = function(key) {
		var isFind = false;
		var aCurrentEventList = null;
		for (var i = 0; i < window.eventList.length; i++) {
			if (window.eventList[i].key == key) {
				isFind = true;
				aCurrentEventList = window.eventList[i].value;
				break;
			}
		}
		if (!isFind) {
			var temp = new WaitEvent();
			window.eventList.push({
				key: key,
				value: temp
			});
			aCurrentEventList = temp;
		}
		return aCurrentEventList;
	}
})();