﻿//当前依赖方地址
var _currentRPAddr = "";
//接收令牌地址
var _currentReceiveTokenAddr = "";
//STS地址
var _stsAddr = "";
//STS是否使用HTTPS
var _stsIsNeedHttps = false;
//语言
var _lang = "";
//本地用于向STS提交登录数据的页面
var _postLoginDataPath = "";
//本地登录成功后的后续处理页面
var _loginSucessPath = "";
//是否保持登录状态
var _keepLoginState = "";

//普通会员注册后自动登陆（注册页面由依赖方自己提供）
//phoneNumberOrEmail-电话号码或邮箱地址
//thePassWord-密码（已经过MD5编码后的字符串）
//stsAddr-STS的地址,以/结尾，如http://localhost:1208/
//isneedssl-STS是否使用HTTPS链接
//language-语言，可取值："zh_cn","en_us","ja_jp","zh_hk","ko_kr","th_th"
//currentRPAddr-当前依赖方地址,以/结尾，如http://localhost:6753/
//localLoginFailedProcessVPath-依赖方本地用于进行登录失败后续处理的页面虚拟路径，如/LoginFailedProcess.aspx
//tokenPostBackAddr-依赖方本地用于接收令牌POST的地址，如/RecvToken.aspx
//IsKeepLoginState-是否保持登录状态，可取值为：on-表示保持登录状态，保持的天数由STS配置文件中KeepLoginStateDays指定，非"on"的其他值或空字符串表示不保持登录状态

function NormalMemberLoginAfterRPRegisted(
phoneNumberOrEmail, thePassWord, language, currentRPAddr, loginSuccessCmd, loginFailedCmd) {
	//保存参数
	_currentRPAddr = currentRPAddr;
	_currentReceiveTokenAddr = _currentRPAddr;
	_stsAddr = "https://" + (window.gInternational ? "global-passport.ch.com" : "passport.ch.com") + "/";
	_stsIsNeedHttps = true;
	_postLoginDataPath = "/authClient/AuthHepler/AutoLoginIndex"; //依赖方本地用于向STS提交登录数据的页面虚拟路径，如/NormalMemberAutoLogin.aspx
	_loginSucessPath = "/authClient/AuthHepler/LoginTempIndex?strCmd=" + loginSuccessCmd; //依赖方本地用于进行登录成功的后续处理页面虚拟路径，如 / LoginSucessProcess.aspx
	_lang = language;
	var loginFailedPath = encodeURIComponent(_currentRPAddr + "/authClient/AuthHepler/AutoLoginFailedIndex?strCmd=" + loginFailedCmd);
	_keepLoginState = "off";

	//调用自动登录
	NormalMemberLogin(phoneNumberOrEmail, thePassWord, _lang, loginFailedPath);
}

//普通会员自动登录添加隐藏框架

function NormalMemberLogin(phonenumber, password, language, loginFailedPath) {
	jQuery('#LoginIframe_FA416D66785849BE997533A4A15D8B39').remove();

	//添加登录IFRAME
	var iframeHtml = '<iframe id="LoginIframe_FA416D66785849BE997533A4A15D8B39" src="' + _postLoginDataPath + '" ' + 'onload="loginFormLoad(\'' + phonenumber + '\',\'' + password + '\',\'' + language + '\',\'' + loginFailedPath + '\');" style="width:0px;height:0px;display:none;"></iframe>';
	jQuery(iframeHtml).appendTo('body');
}


//普通会员自动登录提交

function loginFormLoad(phonenumber, password, language, loginFailedPath, device) {
	var loginFrame = document.getElementById('LoginIframe_FA416D66785849BE997533A4A15D8B39');
	try {
		if (null == loginFrame) {
			return;
		}
		if (null == loginFrame.contentWindow) {
			return;
		}
		if (null == loginFrame.contentWindow.document) {
			return;
		}
	} catch (e) {
		return;
	}
	var loginDocument = loginFrame.contentWindow.document;
	if (null == loginDocument) {
		return;
	}
	var username = loginDocument.getElementById('UserNameInput');
	var pwd = loginDocument.getElementById('PasswordInput');
	var lang = loginDocument.getElementById('Language');
	var loginFailedRedirectUrlInputCtl = loginDocument.getElementById('loginFailedRedirectUrlInput');
	var theSubForm = loginDocument.getElementById('form_login');
	if (null != theSubForm && null != username && null != pwd && null != lang && null != loginFailedRedirectUrlInputCtl) {
		username.value = phonenumber;
		pwd.value = password;
		lang.value = language;
		loginFailedRedirectUrlInputCtl.value = loginFailedPath;
		var loginUrl = createLoginUrl(
		_stsIsNeedHttps, _loginSucessPath, "normalmemberautologin", "", _currentRPAddr, _currentReceiveTokenAddr, _stsAddr, "", device);
		theSubForm.action = loginUrl;
		theSubForm.submit();
	}
}

/// <summary>
/// 创建登录链接地址
/// </summary>
/// <param name="isneedssl">STS是否需要SSL连接</param>
/// <param name="returnvpath">登录后跳转回到哪个虚拟路径页面上，获取自动登录地址时此参数可为空字符串，如：“/Business/ShowBusinessData.aspx”</param>
/// <param name="urltype">想获取那种类型的登录链接地址，可选值：“jumplogin”跳转登录地址；“mobile”M站登录地址；“poplogin”交互登录地址；“normalmemberautologin”普通会员自动登录地址；“sharememberautologin”共享会员自动注册登录地址;“mobile”M站登录地址；“dynamicpwdlogin”动态密码登录地址</param>
/// <param name="langtype">语言类型，传递空字符串让STS自动获取语言，当urltype为normalmemberautologin时此参数被忽略：英语(美国) “en_us”；中文(中华人民共和国) “zh_cn”；中文(中国香港特别行政区) “zh_hk”；日语 “ja_jp”；韩文 “ko_kr”；泰文 “th_th”；
/// <param name="wtrealm">当前依赖方地址，以“/”结尾，如：“http://admin.ch.com:5002/”。</param>
/// <param name="wreply">当前依赖方接收STS服务POST回来的令牌的地址，如：“http://admin.ch.com:5002/RecvToken.aspx”，为空时为当前依赖方根下的默认页面</param>
/// <param name="stsurl">安全令牌服务地址，以“/”结尾，如：“http://sts.ch.com:5001/”。</param>
/// <param name="logoutvpath">当前依赖方统一注销地址，如"/Business/Logout.aspx"，.NET可省略此参数</param>
///  isb2g 企业差旅
/// <returns>生成的登录链接地址</returns>

function createLoginUrl(isneedssl, returnvpath, urltype, langtype, wtrealm, wreply, stsurl, logoutvpath, device, isb2g) {

	if (device == null || device == "" || device == undefined) {
		device = "pc";
		if (langtype == "ja_jp") {
			device = "mobile";
		}
	}

	var currentTime = new Date();
	var _wct = currentTime.getUTCFullYear() + "-" + currentTime.getUTCMonth() + "-" + currentTime.getUTCDay() + "T" + currentTime.getUTCHours() + ":" + currentTime.getUTCMinutes() + ":" + currentTime.getUTCSeconds() + "Z";
	var _rm = "0";
	var _id = "passive";
	var _wa = "wsignin1.0";

	var _ru = "";
	if (returnvpath.toLowerCase().substr(0, 4) == "http") {
		_ru = returnvpath;
	} else {
		if (wtrealm[wtrealm.length - 1] == '/') {
			_ru = wtrealm.substr(0, wtrealm.length - 1) + returnvpath;
		} else {
			_ru = wtrealm + returnvpath;
		}
	}

	var _wtrealm = wtrealm;
	var _stsurl = stsurl;

	var _wreply = wreply;
	if (_wreply.toLowerCase().substr(0, 4) != "http") {
		if (_wreply.substr(0, 1) == "/") {
			_wreply = wtrealm + _wreply.substring(1);
		} else {
			_wreply = wtrealm + _wreply;
		}
	}

	var _theLoginUrl = "";
	if (_stsurl[_stsurl.length - 1] == '/') {
		_stsurl = _stsurl.substr(0, _stsurl.length - 1)
	}

	if (urltype == 'LoginSafe') {
		_theLoginUrl = _stsurl + "/" + langtype + "/Login/LoginSafe";
	} else if (device == "mobile") {
		//跳转登录
		if (urltype == "jumplogin") {
			_theLoginUrl = _stsurl + "/" + langtype + "/Login/Normal";
		}
		//M站登录地址
		else if (urltype == "mobile") {
			_theLoginUrl = _stsurl + "/" + langtype + "/Login/Mobile";
		} else if (urltype == "mobile2" && langtype == "ja_jp") {
			_theLoginUrl = _stsurl + "/" + langtype + "/Login/Mobile2"; // 日文5.0手机站点和日文M网站登录页面不一样，需特殊设置
		}
		//弹出框交互登录
		else if (urltype == "poplogin") {
			_theLoginUrl = _stsurl + "/" + langtype + "/Login/Pop";
		}
	} else if (device == "pc") {
		//跳转登录
		if (urltype == "jumplogin") {
			_theLoginUrl = _stsurl + "/" + langtype + "/Login/NormalPC";
		}
		//M站登录地址
		else if (urltype == "mobile") {
			_theLoginUrl = _stsurl + "/" + langtype + "/Login/MobilePC";
		}
		//弹出框交互登录
		else if (urltype == "poplogin") {
			_theLoginUrl = _stsurl + "/" + langtype + "/Login/PopPC";
		}
	}

	//普通会员自动登录
	if (urltype == "normalmemberautologin") {
		_theLoginUrl = _stsurl + "/Default/NormalMemberAutoLogin";
	}

	//共享会员自动注册登录
	else if (urltype == "sharememberautologin") {
		_theLoginUrl = _stsurl + "/Default/ShareMemberAutoLogin";
	}
	//动态密码登录地址
	else if (urltype == "dynamicpwdlogin") {
		_theLoginUrl = _stsurl + "/Default/LoginByDynamicPwd";
	}

	if (isneedssl) {
		var testHead = _theLoginUrl.substr(0, 5).toLowerCase();
		if (testHead != "https") {
			_theLoginUrl = "https" + _theLoginUrl.substr(4);
		}
	}
	var rm_E = encodeURIComponent(_rm);
	var id_E = encodeURIComponent(_id);
	var ru_E = encodeURIComponent(_ru);
	var wctx_E = encodeURIComponent("rm=" + rm_E + "&id=" + id_E + "&ru=" + ru_E);
	var wct_E = encodeURIComponent(_wct);
	var wtrealm_E = encodeURIComponent(_wtrealm);
	var wreply_E = encodeURIComponent(_wreply);
	var logoutvpath_E = encodeURIComponent(logoutvpath);
	var _ReturnRrl = encodeURIComponent("/?wa=" + _wa + "&wtrealm=" + wtrealm_E + "&wctx=" + wctx_E + "&wct=" + wct_E + "&wreply=" + wreply_E);
	var outPutStr = (_theLoginUrl + "?ReturnUrl=" + _ReturnRrl + "&wa=" + _wa + "&wtrealm=" + wtrealm_E + "&wctx=" + wctx_E + "&wct=" + wct_E + "&wreply=" + wreply_E + "&logoutvpath=" + logoutvpath_E);
	if (isb2g) {
		outPutStr += '&B2G';
	}
	return outPutStr;
}

//显示用户登录框

function ShowLoginDlgAndDoLogin_A052F153D71B4D37AE1752A21B4BD9F8(height, el, isneedssl, returnvpath, urltype, langtype, wtrealm, wreply, stsurl, device, caseHeight) {
	var theLoginUrl = createLoginUrl(isneedssl, returnvpath, urltype, langtype, wtrealm, wreply, stsurl, "", device, el.indexOf("B2G") >= 0);
	var this_height = height;
	if ((this_height + "").indexOf("rem") < 0 && (this_height + "").indexOf("%") < 0) {
		this_height = height + 'px';
	}
	var thisModal = $('<div class="modal-body" id="MxsLoginDlg" style="position:relative;width:100%;">' + '<iframe id="MxsLoginIframe" scrolling="no" frameborder="0" src="' + theLoginUrl + '" style="border:none;width:100%;height:' + this_height + ';"></iframe>' + '</div>');
	if (device == "mobile") {
		thisModal.find("iframe").attr("scrolling", "yes");
	}
	$(el).append(thisModal);
	//模态框关闭事件
	thisModal.on('click', ".close", function(e) {
		jQuery(el).hide();
	});
	//模态框显示事件
	thisModal.on('shown.bs.modal', function(e) {});
	//显示模态框
	thisModal.show();
	//$("#login").height(height);
	//特殊情况：
	//需要手动设置容器高度的时候传入参数（手机）
	if (caseHeight != null && caseHeight != undefined && caseHeight != '') {
		$(el).css('height', caseHeight);
	} else {
		$(el).height(height);
	}
	// id不一定是login update by 何志伟
	thisModal.height(height);
}

//在登录成功后关闭登录窗口

function CloseDlgFunc_B3836847EEA342B2849BC8B01F32FA88() {
	//关闭登录窗口
	jQuery('#MxsLoginDlg').hide();

	//localStorage.setItem("login", new Date());
}