var getSearch = function(hash) {
		if (!hash || hash.split("?").length < 2) {
			return {};
		}
		var pairs = hash.split("?")[1].split("&"),
			length = pairs.length,
			params = {};
		for (var i = 0; i < length; i++) {
			var pair = pairs[i].split("=");
			params[pair[0]] = pair[1] ? pair[1] : null;
		}
		return params;
	};
window.gInternational = false, params = {};
if (document.currentScript) {
	params = getSearch(document.currentScript.src);
} else {
	var reg = new RegExp(/api\/auth\.js/),
		length = document.scripts.length;
	for (var i = 0; i < length; i++) {
		if (reg.test(document.scripts[i].src)) {
			params = getSearch(document.scripts[i].src);
			break;
		}
	}
}
if (params.cdnurlarea == 1) {
	window.gInternational = true;
}!
function(t, r) {
	function e() {
		if (r.currentScript) return r.currentScript.src;
		var e;
		try {
			a.b.c()
		} catch (n) {
			e = n.stack, !e && t.opera && (e = (String(n).match(/of linked script \S+/g) || []).join(" "))
		}
		if (e) return e = e.split(/[@ ]/g).pop(), e = "(" == e[0] ? e.slice(1, -1) : e, e.replace(/(:\d+)?:\d+$/i, "");
		for (var c, o = r.getElementsByTagName("script"), i = 0; c = o[i++];) if ("interactive" == c.readyState) return c.className = c.src;
		return ""
	}
	var n = t.SA = t.SA || {},
		c = "domReady";
	n.passport || (n.passport = function() {
		return {
			render: function(t, e, a) {
				var o = this,
					a = a || {},
					i = [];
				for (var f in a) i.push(f + ":" + a[f]);
				i = i.join(","), i && (o.authConf += "&conf=" + i), !
				function() {
					var e = r.getElementById(t),
						n = r.createElement("iframe");
					e && (!
					function(t) {
						for (var r in t) n.setAttribute(r, t[r], 0)
					}({
						frameborder: "0",
						height: "360",
						width: "320",
						scrolling: "no",
						allowTransparency: "true",
						src: "https://" + (window.gInternational ? "global-oldpassport.ch.com" : "oldpassport.ch.com") + "/LoginFrame" + o.authConf,
						border: "0"
					}), e.appendChild(n))
				}(), o.callback = "function" == typeof e ? e : function() {
					location.reload()
				}
			}
		}
	}(), n[c] = function() {
		function t() {
			try {
				r.documentElement.doScroll("left"), e(), clearInterval(n)
			} catch (t) {}
		}

		function e() {
			for (var t in a) {
				try {
					a[t]()
				} catch (r) {}
				delete a[t]
			}
			c = !0
		}
		var n, a = {},
			c = "complete" === r.readyState;
		return r.attachEvent ? n = setInterval(t, 10) : r.addEventListener("DOMContentLoaded", e, !1), function(t) {
			c ? t() : a[t] = t
		}
	}(), n.passport.authConf = ((e() || "").match(/\?[^\?]+$/) || [])[0] || "")
}(this, document);