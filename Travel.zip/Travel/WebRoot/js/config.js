!
function(t, n) {
	var e = window;
	"function" == typeof module && module.exports;
	e.Spring = n()
}(0, function() {
	return window.Spring ||
	function(t) {
		return t instanceof Spring ? t : this instanceof Spring ? void 0 : new Spring(t)
	}
}), function(t) {
	var n = new function() {
			window._load_size = 0;
			var t = function(n, e) {
					var o = this;
					if (e < n.length) {
						var a = n[e];
						if ("[object Array]" === Object.prototype.toString.call(a)) for (var i = _toDo = a.length, l = 0; l < i; l++) o.addJs.call(o, a[l], function(n, e) {
							_toDo--, 0 === _toDo && t.call(o, n, e + 1)
						}, n, e);
						else "string" == typeof a ? o.addJs.call(o, a, function() {
							t.call(o, n, e + 1)
						}) : t.call(o, n, e + 1)
					}
				};
			this.addList = function() {
				var n, e = this,
					o = Array.prototype.slice.call(arguments);
				0 == window._load_size ? (window._load_size = o.length, t.call(this, o, 0), clearInterval(n)) : n = setInterval(function() {
					0 == window._load_size && (window._load_size = o.length, t.call(e, o, 0), clearInterval(n))
				}, 100)
			}, this.addJs = function(t, n, e, o) {
				var a = document.createElement("script"),
					i = Array.prototype.slice.call(arguments, 2);
				a.charset = o || "UTF-8", a.src = t, a.type = "text/javascript", a.async = 1, document.getElementsByTagName("head")[0].appendChild(a), a.onload = a.onreadystatechange = function() {
					this.readyState && "loaded" !== this.readyState && "complete" !== this.readyState || (window._load_size = window._load_size - 1, window._load_size < 0 && (window._load_size = 0), null != n && n.apply(this, i), a.onload = a.onreadystatechange = null)
				}
			}
		};
	t.load = n
}(window.Spring);