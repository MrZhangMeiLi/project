var ERROR_ARY = [],
	_STATUS_ = !1,
	TIME_STAMP = [(new Date).getTime(), Math.ceil(100 * Math.random(10))].join("");
window.jsErrLog = window.jsErrLog || {}, window.onerror = function(n, r, i, o, a) {
	return setTimeout(function() {
		var e = {};
		e.file_loc = r, e.line_no = i, e.msg = n, e.col_no = o || 0, a && a.stack ? (e.name = a.name, e.stack = CHstat.jsonToString(a.stack)) : e.stack = "", jsErrLog.errData = e;
		var t = jsErrLog.getLinkedSrc(jsErrLog.errData);
		jsErrLog.send(t)
	}, 0), !1
}, jsErrLog.getEventType = function(e) {
	return e || 1
}, jsErrLog.getErrName = function(e) {
	return e || "TypeError"
}, jsErrLog.catchErrMethod = function(n) {
	setTimeout(function() {
		var e = {};
		e.file_loc = n.file_loc || "", e.line_no = n.line_no || 0, e.msg = n.msg, e.col_no = n.col_no || 0, e.stack = n.stack || "", e.name = n.name, e.eType = 2, jsErrLog.errData = e;
		var t = jsErrLog.getLinkedSrc(jsErrLog.errData);
		jsErrLog.send(t)
	}, 0)
}, jsErrLog.send = function(e) {
	_STATUS_ ? CHstat.stat({
		tracker: "tracker",
		type: "error",
		link: e
	}) : ERROR_ARY.push(e)
}, jsErrLog.getLinkedSrc = function(e) {
	var t = "&ER=" + e.file_loc;
	return t += "&LN=" + e.line_no, t += "&CN=" + e.col_no, t += "&EN=" + jsErrLog.getErrName(e.name), t += "&ET=" + jsErrLog.getEventType(e.eType), t += "&MSG=" + encodeURIComponent(e.msg.toString()), t += "&ES=" + encodeURIComponent(CHstat.jsonToString(e.stack)).substring(0, 500), t += "&T=1"
}, function() {
	var c, i = window,
		u = "nameStorage:",
		d = /^([^=]+)(?:=(.*))?$/,
		o = encodeURIComponent,
		f = decodeURIComponent,
		g = {},
		e = {};

	function n() {
		var e, t = [],
			n = !0;
		for (var r in g) g.hasOwnProperty(r) && (n = !1, e = g[r] || "", t.push(o(r) + "=" + o(e)));
		i.name = n ? c : u + o(c) + "?" + t.join("&")
	}!
	function(e) {
		if (e && 0 === e.indexOf(u)) {
			var t = e.split(/[:?]/);
			t.shift(), c = f(t.shift()) || "";
			for (var n, r, i, o = t.join("").split("&"), a = 0, s = o.length; a < s; a++)(n = o[a].match(d)) && n[1] && (r = f(n[1]), i = f(n[2]) || "", g[r] = i)
		} else c = e || ""
	}(i.name), e.setItem = function(e, t) {
		e && void 0 !== t && (g[e] = String(t), n())
	}, e.getItem = function(e) {
		return g.hasOwnProperty(e) ? g[e] : null
	}, e.removeItem = function(e) {
		g.hasOwnProperty(e) && (g[e] = null, delete g[e], n())
	}, e.clear = function() {
		g = {}, n()
	}, e.valueOf = function() {
		return g
	}, e.toString = function() {
		var e = i.name;
		return 0 === e.indexOf(u) ? e : u + e
	}, function t(t, e, n) {
		t && (t.addEventListener ? t.addEventListener(e, n, !1) : t.attachEvent && t.attachEvent("on" + e, function(e) {
			n.call(t, e)
		}))
	}(i, "beforeunload", function() {
		n()
	}), i.nameStorage = e
}(), function() {
	"use strict";
	var e = window,
		t = e.CHstat ||
	function(e) {
		return e instanceof t ? e : this instanceof t ? void(this._wrapped = e) : new t(e)
	};
	e.CHstat = t
}(), CHstat.statJSON = {}, function(s) {
	function o(e) {
		return null === e ? "Null" : e === undefined ? "Undefined" : Object.prototype.toString.call(e).slice(8, -1)
	}
	s.cookie = function(e, t, n) {
		if (void 0 === t) {
			var r = null;
			if (document.cookie && "" != document.cookie) for (var i = document.cookie.split(";"), o = 0; o < i.length; o++) {
				var a = CHstat.trim(i[o]);
				if (a.substring(0, e.length + 1) == e + "=") {
					r = decodeURIComponent(a.substring(e.length + 1));
					break
				}
			}
			return r
		}
		n = n || {}, null === t && (t = "", n.expires = -1);
		var s, c = "";
		n.expires && ("number" == typeof n.expires || n.expires.toUTCString) && ("number" == typeof n.expires ? (s = new Date).setTime(s.getTime() + 24 * n.expires * 60 * 60 * 1e3) : s = n.expires, c = "; expires=" + s.toUTCString());
		var u = n.path ? "; path=" + n.path : "",
			d = n.domain ? "; domain=" + n.domain : "",
			f = n.secure ? "; secure" : "";
		document.cookie = [e, "=", encodeURIComponent(t), c, u, d, f].join("")
	}, s.trim = function(e) {
		if ("" != e && e) {
			for (var t = (e = e.replace(/^(\s| )+/, "")).length - 1; 0 <= t; t--) if (/\S/.test(e.charAt(t))) {
				e = e.substring(0, t + 1);
				break
			}
			return e
		}
		return e
	}, s.parseJSON = function(e) {
		try {
			if (window.JSON && window.JSON.parse) return window.JSON.parse(e)
		} catch (t) {}
		return null === e ? e : "string" == typeof e && (e = CHstat.trim(e)) && /^[\],:{}\s]*$/.test(e.replace(/\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g, "@").replace(/"[^"\\\r\n]*"|true|false|null|-?(?:\d+\.|)\d+(?:[eE][+-]?\d+|)/g, "]").replace(/(?:^|:|,)(?:\s*\[)+/g, "")) ? new Function("return " + e)() : void 0
	}, s.jsonToString = function(e) {
		var t = navigator.userAgent;
		if (250 < t.length && (t = t.substring(0, 250)), !(t = t.toLowerCase()).match(/(msie\s|trident.*rv:)([\w.]+)/)) return JSON.stringify(e);
		var n = typeof e;
		switch ("object" == n && (n = Array == e.constructor ? "array" : RegExp == e.constructor ? "regexp" : "object"), n) {
		case "undefined":
		case "unknown":
			return;
		case "function":
		case "boolean":
		case "regexp":
			return e.toString();
		case "number":
			return isFinite(e) ? e.toString() : "null";
		case "string":
			return '"' + e.replace(/(\\|\")/g, "\\$1").replace(/\n|\r|\t/g, function() {
				var e = arguments[0];
				return "\n" == e ? "\\n" : "\r" == e ? "\\r" : "\t" == e ? "\\t" : ""
			}) + '"';
		case "object":
			if (null === e) return "null";
			var r = [];
			for (var i in e) {
				(a = s.jsonToString(e[i])) !== undefined && r.push(s.jsonToString(i) + ":" + a)
			}
			return "{" + r.join(",") + "}";
		case "array":
			r = [];
			for (var o = 0; o < e.length; o++) {
				var a;
				(a = s.jsonToString(e[o])) !== undefined && r.push(a)
			}
			return "[" + r.join(",") + "]"
		}
	}, s.deepCopy = function(e) {
		var t, n = o(e);
		if ("Object" === n) t = {};
		else {
			if ("Array" !== n) return e;
			t = []
		}
		for (var r in e) {
			var i = e[r];
			"Object" == o(i) ? t[r] = arguments.callee(i) : "Array" == o(i) ? t[r] = arguments.callee(i) : t[r] = e[r]
		}
		return t
	}
}(CHstat), function() {
	function o(e) {
		var t = new Array;

		function r(e) {
			for (var t = 32; t--;) e.push("0")
		}
		function n(e, t) {
			switch (t) {
			case "N":
				return e.toString().replace(/,/g, "");
			case "D":
				return (e.slice(0, 8) + "-" + e.slice(8, 12) + "-" + e.slice(12, 16) + "-" + e.slice(16, 20) + "-" + e.slice(20, 32)).replace(/,/g, "");
			case "B":
				return "{" + n(e, "D") + "}";
			case "P":
				return "(" + n(e, "D") + ")";
			default:
				return new o
			}
		}
		"string" == typeof e ?
		function i(e, t) {
			if (32 != (t = (t = t.replace(/\{|\(|\)|\}|-/g, "")).toLowerCase()).length || -1 != t.search(/[^0-9,a-f]/i)) r(e);
			else for (var n = 0; n < t.length; n++) e.push(t[n])
		}(t, e) : r(t), this.rquals = function(e) {
			return !(!e || !e.isGuid) && this.toString() == e.toString()
		}, this.isGuid = function() {}, this.toString = function(e) {
			return n(t, "string" == typeof e && ("N" == e || "D" == e || "B" == e || "P" == e) ? e : "D")
		}
	}
	o.empty = new o, o.newGuid = function() {
		for (var e = "", t = 32; t--;) e += Math.floor(16 * Math.random()).toString(16);
		return new o(e)
	}, o.init = function() {
		if (!CHstat.cookie("_st")) {
			var e = window.location.hostname.match(/(?:[^\.]*?\.)*([^\.]*?\.[^\.]*)/)[1],
				t = o.newGuid();
			CHstat.cookie("_st", t.toString("N"), {
				path: "/",
				domain: e,
				expires: 999
			})
		}
	};
	try {
		o.init()
	} catch (e) {
		jsErrLog.catchErrMethod({
			file_loc: e.filenNme || "",
			line_no: e.lineNumber || 65535 & e.number || 0,
			msg: e.message,
			stack: e.stack || "",
			name: e.name
		})
	}
}(), function(a) {
	window.Cache = null;
	var t = encodeURIComponent,
		n = window,
		r = document,
		i = navigator,
		o = (decodeURIComponent, encodeURI, n.location.protocol),
		s = /^(((www|pay|booking|my|pages|livechat)\.springtour)|(trip|tripbooking|trippay|mytrip|trippages)\.ch)\.com$/,
		c = function(e) {
			if (!(this instanceof c)) return new c(e);
			a._environment = s.test(n.location.hostname) ? "online" : "dev";
			var t = o + "//" + (s.test(n.location.hostname) ? "clk.springtour.com/" : "10.32.0.96/");
			this.NR = t + "b.gif", a.gioGif = this.ERROR = t + "e.gif", this.init(e)
		},
		u = c.prototype;
	u.init = function(e) {
		this.getLocalGif(), window.Cache || this.setCacheData(), this.requestNext(e), this.sendErrorGif()
	}, u.getLocalGif = function() {
		var e = a.parseJSON(this.nameStorageData("_statJSON_")) || {};
		a.statJSON = e
	}, u.getSite = function() {
		var e = 21,
			t = n.location.host;
		return /^((www|pay|booking|my).springtour.com)/.test(t) && (e = 21), /.ch.com/.test(t) && (e = 28), a._map_site = e
	}, u.getForeverId = function() {
		return a.cookie("_st") || ""
	}, u.getStartCity = function() {
		return a.cookie("cityId") || "61"
	}, u.getMemberId = function() {
		try {
			return WIN_CONFIG_SP.BiMid
		} catch (e) {
			return jsErrLog.catchErrMethod({
				file_loc: e.filenNme || "",
				line_no: e.lineNumber || 65535 & e.number || 0,
				msg: e.message,
				stack: e.stack || "",
				name: e.name
			}), ""
		}
	}, u.getOrderId = function() {
		var e = r.getElementById("infoCookie_panel"),
			t = n.location.search.match(/(?:\?|&)OrderId=([^&]*)(?:\&|$)/i);
		return !(t = t ? t[1] : "") && e && (t = e.getAttribute("data-orderid") || ""), t
	}, u.getProductId = function() {
		var e = r.getElementById("infoCookie_panel"),
			t = "";
		return e && (t = e.getAttribute("data-productid") ? e.getAttribute("data-productid") : e.getAttribute("data-id")), t || (t = ~~n.location.pathname.split("/").pop() || 0), t
	}, u.getType = function(e) {
		return e || "pageview"
	}, u.getEventType = function(e) {
		return e || 1
	}, u.getFormId = function() {
		var e = window.location.href.match(/#(([\w_一-龥]+)\w*)/);
		return [e ? t(t(e[1])) : "", "_", TIME_STAMP].join("")
	}, u.getUA = function() {
		var e = i.userAgent;
		return 250 < e.length && (e = e.substring(0, 250)), e
	}, u.getBrower = function() {
		var e = this.getUA().toLowerCase(),
			t = null,
			n = null,
			r = null,
			i = /(msie\s|trident.*rv:)([\w.]+)/;
		try {
			-1 != e.indexOf("maxthon") ? (t = "Maxthon", n = e.match(/maxthon\/([\d.]+)/)[1]) : e.match(i) ? (t = "MSIE", n = e.match(i)[2]) : -1 != e.indexOf("firefox") ? (t = "Firefox", n = e.match(/(firefox)\/([\w.]+)/)[2]) : -1 != e.indexOf("chrome") ? (t = "Chrome", n = e.match(/(chrome)\/([\w.]+)/)[2]) : -1 != e.indexOf("opera") ? (t = "Opera", n = e.match(/(opera).+version\/([\w.]+)/)[2]) : -1 != e.indexOf("safari") ? (t = "Safari", n = e.match(/version\/([\w.]+).*(safari)/)[1]) : -1 != e.indexOf("qqbrowser") ? (t = "QQBrowser", n = e.match(/qqbrowser\/([\d.]+)/)[1]) : -1 != e.indexOf("ucbrowser") ? (t = "UCBrowser", n = e.match(/ucbrowser\/([\d.]+)/)[1]) : -1 != e.indexOf("lbbrowser") ? (t = "LBBrowser", n = "none") : -1 != e.indexOf("micromessenger") && (t = "WebChat", n = e.match(/micromessenger\/([\d.]+)/)[1])
		} catch (o) {
			u.catchError(o)
		}
		try {
			r = -1 < e.indexOf("360ee") ? "360ee" : -1 < e.indexOf("360se") ? "360se" : -1 < e.indexOf("se") ? "sogo" : -1 < e.indexOf("aoyou") ? "aoyou" : -1 < e.indexOf("theworld") ? "theworld" : -1 < e.indexOf("worldchrome") ? "worldchrome" : -1 < e.indexOf("greenbrowser") ? "greenbrowser" : -1 < e.indexOf("baidu") ? "baidu" : -1 < e.indexOf("edge") ? "edge" : "none"
		} catch (o) {
			u.catchError(o)
		}
		return {
			name: t || "ot",
			version: n || "none",
			shell: r || ""
		}
	}, u.getPlatform = function() {
		var e = this.getUA(),
			t = "Win32" == i.platform || "Windows" == i.platform,
			n = "Mac68K" == i.platform || "MacPPC" == i.platform || "Macintosh" == i.platform || "MacIntel" == i.platform;
		if (n) return "Mac";
		if ("X11" == i.platform && !t && !n) return "Unix";
		if (-1 < String(i.platform).indexOf("Linux")) return -1 < e.indexOf("Android") ? "Android" : "Linux";
		if (t) {
			if (-1 < e.indexOf("Windows NT 5.0") || -1 < e.indexOf("Windows 2000")) return "Win2000";
			if (-1 < e.indexOf("Windows NT 5.1") || -1 < e.indexOf("Windows XP")) return "WinXP";
			if (-1 < e.indexOf("Windows NT 5.2") || -1 < e.indexOf("Windows 2003")) return "Win2003";
			if (-1 < e.indexOf("Windows NT 6.0") || -1 < e.indexOf("Windows Vista")) return "WinVista";
			if (-1 < e.indexOf("Windows NT 6.1") || -1 < e.indexOf("Windows 7")) return "Win7";
			if (-1 < e.indexOf("Windows NT 6.2") || e.indexOf("Windows NT 6.3") || -1 < e.indexOf("Windows 8")) return "Win8";
			if (-1 < e.indexOf("Windows NT 10.0") || -1 < e.indexOf("Windows 10")) return "Win10"
		}
		return i.platform || "other"
	}, u.getPageTitle = function() {
		return t(t(document.title.substring(0, 20)))
	}, u.getVlstatUrl = function() {
		return encodeURI(encodeURI(document.URL.substring(0, 160)).replace(/\&/g, "!~!"))
	}, u.getVlstatRefurl = function() {
		return encodeURI(encodeURI(document.referrer.substring(0, 160)).replace(/\&/g, "!~!"))
	}, u.updateUrl = function(e) {
		return e = e || "", encodeURI(encodeURI(e.substring(0, 50)).replace(/\&/g, "!~!"))
	}, u.getArea = function(e) {
		return t(t(e = e || ""))
	}, u.getCps = function() {
		return a.cookie("c_source") || ""
	}, u.setCacheData = function() {
		var e = [],
			t = this.getBrower();
		e.push("CH=" + this.getSite()), e.push("&C=" + this.getForeverId()), e.push("&M=" + this.getMemberId()), e.push("&T=" + this.getPageTitle()), e.push("&S=" + this.getCps()), e.push("&Y=" + this.getStartCity()), e.push("&BN=" + t.name), e.push("&BV=" + t.version), e.push("&PF=" + this.getPlatform()), e.push("&SW=" + screen.width + "x" + screen.height), e.push("&H=" + this.getVlstatUrl()), e.push("&R=" + this.getVlstatRefurl()), window.Cache = e
	}, u.dynamicData = function(e) {
		e = e || {};
		var t = [],
			n = a.deepCopy(window.Cache),
			r = e.productId || this.getProductId(),
			i = e.orderId || this.getOrderId(),
			o = this.getType(e.type);
		switch (t.push("&P=" + r), t.push("&O=" + i), t.push("&TYPE=" + o), e.type) {
		case "click":
			t.push("&ET=" + this.getEventType(e.event)), t.push("&A=" + this.getArea(e.area));
			break;
		case "booking":
			t.push("&F=" + this.getFormId());
			break;
		case "pay":
			break;
		case "error":
			t.push("&A=" + this.updateUrl(e.area));
			break;
		default:
			t.push("&F=" + this.getFormId())
		}
		return n && (n[n.length - 2] = "&H=" + this.getVlstatUrl()), n && n.splice(2, 0, t.join("")), n
	}, u.dynamicDataTracker = function(e) {
		e = e || {};
		var t = a.deepCopy(window.Cache);
		return t && t.splice(2, 0, e.link), t
	}, u.catchError = function(e) {
		jsErrLog.catchErrMethod({
			file_loc: e.filenNme || "",
			line_no: e.lineNumber || 65535 & e.number || 0,
			msg: e.message,
			stack: e.stack || "",
			name: e.name
		})
	}, u.requestNext = function(e) {
		e = e || {};
		var t = [],
			n = "";
		try {
			"tracker" === e.tracker ? (t = this.dynamicDataTracker(e), n = this.ERROR + "?" + t.join("") + "&rnd=" + Math.random()) : (t = this.dynamicData(e), n = this.NR + "?" + t.join("") + "&rnd=" + Math.random()), this.callGif(n)
		} catch (r) {
			this.catchError(r)
		}
	}, u.callGif = function(e) {
		var t = this,
			n = "_imglog_" + (new Date).getTime();
		a.statJSON[n] = e;
		var r = new Image(1, 1);
		r.onload = r.onerror = function() {
			r = null, delete a.statJSON[n], t.nameStorageData("_statJSON_", a.jsonToString(a.statJSON))
		}, r.src = e, t.nameStorageData("_statJSON_", a.jsonToString(a.statJSON)), t.sendLocalGif(n)
	}, u.sendLocalGif = function(n) {
		var r = this;
		for (var e in a.statJSON)!
		function(e) {
			if (!a.statJSON[e]) return;
			if (e === n) return;
			var t = new Image(1, 1);
			t.onload = t.onerror = function() {
				t = null, delete a.statJSON[e], r.nameStorageData("_statJSON_", a.jsonToString(a.statJSON))
			}, t.src = a.statJSON[e]
		}(e)
	}, u.sendErrorGif = function() {
		var i = this,
			o = i.arrayUnique(ERROR_ARY),
			e = o.length;
		if (!e) return ERROR_ARY = o, !1;
		for (var t = 0; t < e; t++)!
		function(e) {
			var t = i.dynamicDataTracker({
				link: o[e]
			});
			if (!t) return;
			var n = i.ERROR + "?" + t.join("") + "&rnd=" + Math.random(),
				r = new Image(1, 1);
			r.onload = r.onerror = function() {
				r = null, ERROR_ARY.splice(e, 1, "")
			}, r.src = n
		}(t)
	}, u.arrayUnique = function(e) {
		for (var t = {}, n = [], r = 0; r < e.length; r++)!t[e[r]] && e[r].length && (t[e[r]] = !0, n.push(e[r]));
		return n
	}, u.nameStorageData = function(e, t) {
		return !!e && (window.nameStorage ? void 0 === t ? nameStorage.getItem(e) : void nameStorage.setItem(e, t) : null)
	};
	try {
		a.stat = function d(e) {
			if (!(this instanceof d)) return new d(e);
			c.call(this, e)
		}, a.stat(), _STATUS_ = !0
	} catch (e) {
		_STATUS_ = !1, u.catchError(e)
	}
}(CHstat), function(r) {
	var n = r.PageView || {};
	n.version = 1, n.autoRun = !0, n.pageMarks = r.pageMarks || {}, n.init = function() {
		n.isDone = !1, n.addEventListener("beforeunload", n.beforeUnload, !1), "complete" == document.readyState ? (r.performance && r.performance.timing && r.performance.timing.loadEventEnd && (n.pageMark("firstByte", r.performance.timing.responseStart), n.pageMark("onload", r.performance.timing.loadEventEndd), n.loadFinish()), n.autoRun && n.loadFinish()) : n.addEventListener("load", n.onload, !1)
	}, n.pageMark = function(e, t) {
		e && (n.pageMarks[e] = parseInt(t) || (new Date).getTime())
	}, n.onload = function() {
		n.pageMark("onload"), r.performance && r.performance.timing && r.performance.timing.loadEventEnd && n.pageMark("onload", r.performance.timing.loadEventEnd), n.autoRun && n.loadFinish()
	}, n.loadFinish = function(e) {
		n.isDone = !0, n.sendPageView(), "function" == typeof e && e()
	}, n.sendPageView = function() {
		var e = n.getLinkSrc();
		CHstat.stat({
			tracker: "tracker",
			type: "time",
			link: e
		})
	}, n.getLinkSrc = function() {
		var e = "&ER=";
		return e += "&LN=", e += "&CN=", e += "&EN=", e += "&ET=", e += "&MSG=", e += "&ES=", e += "&T=2", e += "&LT=" + n.getLoadTime(), e += "&DT=" + n.getDomLoadTime()
	}, n.getLoadTime = function() {
		var e = n.pageMarks.onload,
			t = n.findStartTime();
		return parseInt(e - t)
	}, n.getDomLoadTime = function() {
		var e = n.pageMarks.DOMContentLoaded,
			t = n.findStartTime();
		return r.performance && r.performance.timing && r.performance.timing.domContentLoadedEventEnd && (t = n.findStartTime()), parseInt(e - t)
	}, n.findStartTime = function() {
		var e = n.findStartWebTiming() || n.findStartCookie();
		return e || (e = n.pageMarks.firstbyte), e
	}, n.findStartWebTiming = function() {
		var e = undefined,
			t = window.performance;
		return void 0 !== t && "undefined" != typeof t.timing && "undefined" != typeof t.timing.navigationStart && (e = t.timing.navigationStart), e
	}, n.findStartCookie = function() {
		for (var e = document.cookie.split(" "), t = 0; t < e.length; t++) if (0 === e[t].indexOf("PageView=")) {
			for (var n, r, i = e[t].substring("PageView=".length).split("&"), o = 0; o < i.length; o++) if (0 === i[o].indexOf("s=")) n = i[o].substring(2);
			else if (0 === i[o].indexOf("r=")) {
				var a = i[o].substring(2);
				r = escape(document.referrer) == a
			}
			if (r && n) return n
		}
		return undefined
	}, n.beforeUnload = function() {
		document.cookie = "PageView=s=" + Number(new Date) + "&r=" + escape(document.location) + "; path=/"
	}, n.addEventListener = function(e, t, n) {
		return r.addEventListener ? r.addEventListener(e, t, n) : r.attachEvent("on" + e, t)
	}, n.init()
}(window), function() {
	var e, t, n, r, i, o = CHstat._map_site,
		a = document.body.className.match(new RegExp("(\\s|^)ch(\\s|$)")) || -1 < location.href.indexOf("trippages.ch"),
		s = s || [];
	window._vds = s, a ? s.push(["setAccountId", "online" === CHstat._environment ? "9671c64d0abba7c8" : "9560f9893ebeee97"]) : s.push(["setAccountId", "online" === CHstat._environment ? "9d20a05b219ce415" : "9560f9893ebeee97"]), s.push(["trackBot", !1]), function() {
		var e = document.createElement("script");
		e.type = "text/javascript", e.async = !0, e.src = ("https:" == document.location.protocol ? "https://" : "http://") + "dn-growing.qbox.me/vds-gate.js";
		var t = document.getElementsByTagName("script")[0];
		e.onload = e.onreadystatechange = function() {
			if (!this.readyState || "loaded" === this.readyState || "complete" === this.readyState) {
				"function" == typeof func && func(), this.onload = this.onreadystatechange = null, this.parentNode.removeChild(this);
				var e = new Image(1, 1);

				function t(e) {
					var t = e ? "有图片的流量" : "无图片的流量";
					window._vds.track("flow_Event", {
						flow_var: t
					})
				}
				e.onload = function() {
					t(!(e = null))
				}, e.onerror = function() {
					e = null, t(!1)
				}, e.src = CHstat.gioGif
			}
		}, t.parentNode.insertBefore(e, t)
	}(), e = window, t = document, n = "ga", e.GoogleAnalyticsObject = n, e.ga = e.ga ||
	function() {
		(e.ga.q = e.ga.q || []).push(arguments)
	}, e.ga.l = 1 * new Date, r = t.createElement("script"), i = t.getElementsByTagName("script")[0], r.async = 1, r.src = "//www.google-analytics.com/analytics.js", i.parentNode.insertBefore(r, i), a ? (28 === o && (ga("create", "UA-19705401-16", "auto"), ga("send", "pageview")), ga("create", "UA-54697886-3", "auto", {
		name: "lang"
	}), ga("require", "displayfeatures"), ga("lang.require", "displayfeatures"), ga("chsite.send", "pageview"), ga("lang.send", "pageview")) : (ga("create", "UA-19705401-1", "springtour.com"), ga("set", "cityId", CHstat.cookie("cityId")), ga("send", "pageview"))
}(), function() {
	if ("online" === CHstat._environment) {
		var e = document.createElement("script"),
			t = window.location.protocol.split(":")[0];
		e.async = 1, e.src = "https" === t ? "https://zz.bdstatic.com/linksubmit/push.js" : "http://push.zhanzhang.baidu.com/push.js";
		var n = document.getElementsByTagName("script")[0];
		n.parentNode.insertBefore(e, n)
	}
}();