package zc.travel.hotel.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import zc.travel.hotel.dao.HotelDao;
import zc.travel.hotel.vo.Hotel;

@Transactional
public class HotelService {
	private HotelDao hotelDao;

	public void setHotelDao(HotelDao hotelDao) {
		this.hotelDao = hotelDao;
	}

	public List<Hotel> find() {

		return hotelDao.find();
	}

	public void save(Hotel hotel) {
		hotelDao.save(hotel);
	}

}
