package zc.travel.hotel.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import zc.travel.hotel.vo.Hotel;

public class HotelDao extends HibernateDaoSupport {

	public List<Hotel> find() {
		String hql = "from Hotel";
		this.getHibernateTemplate().find(hql);
		return null;
	}

	public void save(Hotel hotel) {
		this.getHibernateTemplate().save(hotel);
	}

}
