package zc.travel.hotel.action;

import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import zc.travel.hotel.service.HotelService;
import zc.travel.hotel.vo.Hotel;
import zc.travel.order.service.OrderService;
import zc.travel.order.vo.Order;

public class HotelAction extends ActionSupport implements ModelDriven<Hotel> {
	private Hotel hotel = new Hotel();

	@Override
	public Hotel getModel() {
		return hotel;
	}

	/**
	 * toHotelPage
	 */
	public String toHotelPage() {
		return "toHotelPage";
	}

	/**
	 * toHotel_orderPage
	 */
	public String toHotel_orderPage() {
		return "toHotel_orderPage";
	}

	/**
	 * 注入service
	 */
	private HotelService hotelService;

	public void setHotelService(HotelService hotelService) {
		this.hotelService = hotelService;
	}

	/**
	 * 注入OrderService
	 */
	private OrderService orderService;

	public void setOrderService(OrderService orderService) {
		this.orderService = orderService;
	}

	/**
	 * hotel_order
	 */
	public String hotel_order() {
		hotelService.save(hotel);
		ServletActionContext.getRequest().getSession().setAttribute("hotelall", hotel);
		// 显示选择酒店，完成订单前的酒店信息显示，从order表查
		List<Order> Orderlists = orderService.finshOrder(hotel.getGowhere());
		ServletActionContext.getRequest().getSession().setAttribute("orderlists", Orderlists);
		return "choosehotel";
	}

}
