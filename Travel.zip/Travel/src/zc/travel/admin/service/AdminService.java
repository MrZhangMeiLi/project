package zc.travel.admin.service;

import java.util.List;

import zc.travel.admin.dao.AdminDao;
import zc.travel.admin.vo.Admin;
import zc.travel.sight.vo.Sight;
import zc.travel.user.vo.User;

public class AdminService {

	private AdminDao adminDao;

	public void setAdminDao(AdminDao adminDao) {
		this.adminDao = adminDao;
	}

	public void save(Admin admin) {
		// 将数据存入到数据库
		// user.setUid(UUIDUtils.getUUID());
		adminDao.save(admin);
	}

	// 用户登录的方法
	public Admin login(Admin admin) {
		return adminDao.login(admin);
	}

	public void admin_delete(Admin admin) {
		// String aid = admin.getAid();
		adminDao.admin_delete(admin);

	}

	public List<User> findAll() {
		return adminDao.findAll();
	}

	public void DeleteUser(String uid) {
		adminDao.DeleteUser(uid);

	}

	public void admin_update(Admin admin) {
		adminDao.admin_update(admin);
	}

	public List<Sight> findPlace() {
		return adminDao.findPlace();
	}

	public void DeleteSight(String sid) {
		adminDao.DeleteSight(sid);

	}

	public void saveAll(String sid, String sa, String sp, String sp1, String sp2, String img, String sname) {
		adminDao.saveAll(sid, sa, sp, sp1, sp2, img, sname);
	}

	public void Add(String sid, String sa, String sp, String sp1, String sp2, String img, String sname) {
		adminDao.Add(sid, sa, sp, sp1, sp2, img, sname);
	}

}
