package zc.travel.admin.action;

import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import zc.travel.admin.service.AdminService;
import zc.travel.admin.vo.Admin;
import zc.travel.sight.vo.Sight;
import zc.travel.user.vo.User;

public class AdminAction extends ActionSupport implements ModelDriven<Admin> {

	/**
	 * 跳转至admin后台
	 */
	public String toAdmin() {
		List<User> lists = adminService.findAll();
		ServletActionContext.getRequest().getSession().setAttribute("lists", lists);
		return "toadmin";
	}

	/**
	 * 获取要操作的uid
	 */
	private String uid;

	public void setUid(String uid) {
		this.uid = uid;
	}

	/**
	 * 跳转到注册页面
	 * 
	 * @return
	 */
	public String registPage() {
		return "registPage";
	}

	/**
	 * 跳转到登录页面
	 * 
	 * @return
	 */
	public String loginPage() {
		return "loginPage";
	}

	// 接收验证码:
	private String checkcode;

	public void setCheckcode(String checkcode) {
		this.checkcode = checkcode;
	}

	// 注入UserService
	private AdminService adminService;

	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}

	private Admin admin = new Admin();

	public Admin getModel() {
		return admin;
	}

	/**
	 * 用户注册的方法:
	 */
	public String regist() {
		// 判断验证码程序:
		// 从session中获得验证码的随机值:
		String checkcode1 = (String) ServletActionContext.getRequest().getSession().getAttribute("checkcode");
		if (checkcode != null && !checkcode.equalsIgnoreCase(checkcode1)) {
			ServletActionContext.getRequest().getSession().setAttribute("yzmerror", "验证码错误！");
			return "false";
		}
		adminService.save(admin);
		return "success";
	}

	/**
	 * 登录的方法
	 */
	public String login() {
		Admin existAdmin = adminService.login(admin);
		// 判断
		if (existAdmin == null) {
			// 登录失败
			this.addActionError("登录失败:用户名或密码错误或用户未激活!");
			return "false";
		} else {
			// 登录成功
			// 将用户的信息存入到session中
			ServletActionContext.getRequest().getSession().setAttribute("existAdmin", existAdmin);
			// 页面跳转
			List<User> lists = adminService.findAll();
			ServletActionContext.getRequest().getSession().setAttribute("lists", lists);
			return "success";
		}

	}

	/**
	 * 管理员退出的方法
	 */
	public String quit() {
		// 销毁session
		ServletActionContext.getRequest().getSession().setAttribute("existAdmin", null);
		return "quit";
	}

	/**
	 * 管理员注销的方法
	 */
	public String admin_delete() {
		// 销毁session
		Admin admin = (Admin) ServletActionContext.getRequest().getSession().getAttribute("existAdmin");
		adminService.admin_delete(admin);
		ServletActionContext.getRequest().getSession().setAttribute("existAdmin", null);
		return "admin_delete";
	}

	/**
	 * 管理员修改信息页面
	 */
	public String admin_updatePage() {
		return "admin_updatePage";
	}

	/**
	 * 管理员修改信息方法
	 * 
	 * @return
	 */
	public String admin_update() {
		// 登录成功
		// 获取登录状态的管理员信息
		Admin adminlogin = (Admin) ServletActionContext.getRequest().getSession().getAttribute("existAdmin");
		admin.setAid(adminlogin.getAid());// 设置更新信息的aid值
		// admin.setAphone(adminlogin.getAphone());
		adminService.admin_update(admin);
		// 页面跳转
		List<User> lists = adminService.findAll();
		ServletActionContext.getRequest().getSession().setAttribute("lists", lists);
		return "success";
	}

	/**
	 * 管理员注销用户方法
	 */
	public String adminDeleteUser() {
		adminService.DeleteUser(uid);
		return "success";
	}

	/**
	 * 去修改地点页面信息的jsp
	 */
	public String tolast_placePage() {
		// 搜索全部
		List<Sight> sightlists = adminService.findPlace();
		ServletActionContext.getRequest().getSession().setAttribute("sightlists", sightlists);
		return "tolast_placePage";
	}

	private String sid;

	public void setSid(String sid) {
		this.sid = sid;
	}

	/**
	 * adminDeleteSight删除信息
	 */
	public String adminDeleteSight() {
		adminService.DeleteSight(sid);
		return "success";
	}

	/**
	 * adminUpdateSight，修改Sight表信息的方法
	 */
	public String adminUpdateSight() {
		// 搜索全部
		List<Sight> sightlists = adminService.findPlace();
		ServletActionContext.getRequest().getSession().setAttribute("sightlists", sightlists);
		ServletActionContext.getRequest().getSession().setAttribute("sightID", sid);
		return "toupdateSightPage";
	}

	private String sa;
	private String sp;
	private String sp1;
	private String sp2;
	private String img;
	private String sname;

	public void setSa(String sa) {
		this.sa = sa;
	}

	public void setSp(String sp) {
		this.sp = sp;
	}

	public void setSp1(String sp1) {
		this.sp1 = sp1;
	}

	public void setSp2(String sp2) {
		this.sp2 = sp2;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	/**
	 * 确认修改
	 */
	public String adminRightSight() {
		adminService.saveAll(sid, sa, sp, sp1, sp2, img, sname);
		List<Sight> sightlists = adminService.findPlace();
		ServletActionContext.getRequest().getSession().setAttribute("sightlists", sightlists);
		return "success";
	}

	/**
	 * addSightPage.jsp
	 */
	public String addSightPage() {
		return "addSightPage";
	}

	/**
	 * 添加数据信息adminAddSight
	 */
	public String adminAddSight() {
		adminService.Add(sid, sa, sp, sp1, sp2, img, sname);
		List<Sight> sightlists = adminService.findPlace();
		ServletActionContext.getRequest().getSession().setAttribute("sightlists", sightlists);
		return "success";
	}

}
