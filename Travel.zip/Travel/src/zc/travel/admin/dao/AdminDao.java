package zc.travel.admin.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import zc.travel.admin.vo.Admin;
import zc.travel.sight.vo.Sight;
import zc.travel.user.vo.User;

public class AdminDao extends HibernateDaoSupport {

	// 注入sight
	private Sight sight;

	public void setSight(Sight sight) {
		this.sight = sight;
	}

	// 注册用户存入数据库代码实现
	public void save(Admin admin) {
		this.getHibernateTemplate().save(admin);
	}

	// 用户登录的方法
	public Admin login(Admin admin) {
		String hql = "from Admin where aname = ? and apassword = ?";
		List<Admin> list = this.getHibernateTemplate().find(hql, admin.getAname(), admin.getApassword());
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	public void admin_delete(Admin admin) {
		this.getHibernateTemplate().delete("Admin", admin);
	}

	public List<User> findAll() {
		String hql = "from User";
		List<User> list = this.getHibernateTemplate().find(hql);
		return list;
	}

	public void DeleteUser(String uid) {
		List<User> list = this.getHibernateTemplate().find("from User where uid = ?", uid);
		this.getHibernateTemplate().delete("User", list.get(0));
	}

	public void admin_update(Admin admin) {
		this.getHibernateTemplate().update(admin);

	}

	public List<Sight> findPlace() {
		List<Sight> sightlists = this.getHibernateTemplate().find("from Sight");
		return sightlists;
	}

	public void DeleteSight(String sid) {
		List<Sight> sightlist = this.getHibernateTemplate().find("from Sight where sid = ?", sid);
		this.getHibernateTemplate().delete("Sight", sightlist.get(0));

	}

	public void saveAll(String sid, String sa, String sp, String sp1, String sp2, String img, String sname) {
		sight.setSid(sid);
		sight.setSa(sa);
		sight.setSp(sp);
		sight.setSp1(sp1);
		sight.setSp2(sp2);
		sight.setImg(img);
		sight.setSname(sname);
		this.getHibernateTemplate().update(sight);
	}

	public void Add(String sid, String sa, String sp, String sp1, String sp2, String img, String sname) {
		sight.setSid(sid);
		sight.setSa(sa);
		sight.setSp(sp);
		sight.setSp1(sp1);
		sight.setSp2(sp2);
		sight.setImg(img);
		sight.setSname(sname);
		this.getHibernateTemplate().save(sight);
	}

}
