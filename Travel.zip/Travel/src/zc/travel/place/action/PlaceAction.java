package zc.travel.place.action;

import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import zc.travel.place.service.PlaceService;
import zc.travel.place.vo.Place;
import zc.travel.sight.service.SightService;
import zc.travel.sight.vo.Sight;

public class PlaceAction extends ActionSupport implements ModelDriven<Place> {
	private Place place = new Place();

	public Place getModel() {
		return place;
	}

	private PlaceService placeService;

	public void setPlaceService(PlaceService placeService) {
		this.placeService = placeService;
	}

	private SightService sightService;

	public void setSightService(SightService sightService) {
		this.sightService = sightService;
	}

	/**
	 * 用户搜索地点方法
	 */
	public String toPlace() {
		if (place.getPname() != null) {
			List<Place> placelists = placeService.findPlace(place.getPname());
			if (placelists.get(0) != null) {
				List<Sight> lists = sightService.findAll(placelists.get(0).getPname());
				ServletActionContext.getRequest().getSession().setAttribute("canadalists", lists);
				return "canada";
			}
		}
		return "false";
	}

}