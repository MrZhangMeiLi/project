package zc.travel.place.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import zc.travel.place.dao.PlaceDao;
import zc.travel.place.vo.Place;

@Transactional
public class PlaceService {
	private PlaceDao placeDao;

	public void setPlaceDao(PlaceDao placeDao) {
		this.placeDao = placeDao;
	}

	public List<Place> findPlace(String pname) {
		return placeDao.findPlace(pname);
	}

}
