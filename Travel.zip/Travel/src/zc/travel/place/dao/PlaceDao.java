package zc.travel.place.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import zc.travel.place.vo.Place;

public class PlaceDao extends HibernateDaoSupport {

	private Place place;

	public void setPlace(Place place) {
		this.place = place;
	}

	public List<Place> findPlace(String pname) {
		String hql = "from Place where pname = ?";
		List<Place> placelists = this.getHibernateTemplate().find(hql, pname);
		return placelists;
	}

}
