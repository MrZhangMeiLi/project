package zc.travel.user.action;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import zc.travel.user.service.UserService;
import zc.travel.user.vo.User;

public class UserAction extends ActionSupport implements ModelDriven<User> {
	/**
	 * 跳转到注册页面
	 * 
	 * @return
	 */
	public String registPage() {
		return "registPage";
	}

	/**
	 * 跳转到登录页面
	 * 
	 * @return
	 */
	public String loginPage() {
		return "loginPage";
	}

	/**
	 * 跳转到个人中心
	 */
	public String personPage() {
		return "personPage";
	}

	/**
	 * 跳转到注册会员页面
	 */
	public String registMemberPage() {
		return "registMemberPage";
	}

	/**
	 * 跳转到用户信息修改页面
	 */
	public String user_updatePage() {
		return "user_updatePage";
	}

	// 接收验证码:
	private String checkcode;

	public void setCheckcode(String checkcode) {
		this.checkcode = checkcode;
	}

	private String checkcodeemail;

	public void setCheckcodeemail(String checkcodeemail) {
		this.checkcodeemail = checkcodeemail;
	}

	// 注入UserService
	private UserService userService;

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	private User user = new User();

	public User getModel() {
		return user;
	}

	/**
	 * 用户注册的方法:
	 */
	public String regist() {
		// 判断验证码程序:
		// 从session中获得验证码的随机值:
		Boolean flag = true;
		String checkcode1 = (String) ServletActionContext.getRequest().getSession().getAttribute("checkcodeRal");
		System.out.println(
				"checkcode1:" + checkcode1 + " " + "checkcode:" + checkcode + " checkcodeemail:" + checkcodeemail);
		if (checkcode != null && checkcode != "" && !checkcode.equalsIgnoreCase(checkcode1)) {
			ServletActionContext.getRequest().setAttribute("yzmerror", "手机验证码错误！");
			flag = false;
			return "false";
		} else if (checkcodeemail != null && checkcodeemail != "" && !checkcodeemail.equalsIgnoreCase(checkcode1)) {
			ServletActionContext.getRequest().setAttribute("yzmerror", "email验证码错误！");
			flag = false;
			return "false";
		}
		if (flag) {
			userService.save(user);
		}
		return "success";
	}

	/**
	 * 登录的方法
	 */
	public String login() {
		String phoneORemail = user.getPhone();
		if (phoneORemail.indexOf("@") != -1) {
			user.setEmail(phoneORemail);
			// user.setPhone(null);
		}
		User existUser = userService.login(user);
		existUser.setPhone(phoneORemail);
		// 判断
		if (existUser == null || existUser.getPassword() == null) {
			// 登录失败
			// this.addActionError("登录失败:用户名或密码错误或用户未激活!");
			return "false";
		} else {
			// 登录成功
			// 将用户的信息存入到session中
			ServletActionContext.getRequest().getSession().setAttribute("existUser", existUser);
			// 页面跳转
			return "success";
		}

	}

	/**
	 * 用户退出的方法
	 */
	public String quit() {
		// 销毁session
		ServletActionContext.getRequest().getSession().invalidate();
		return "quit";
	}

	/**
	 * 用户注销的方法
	 */
	public String user_delete() {
		// 销毁session
		User user = (User) ServletActionContext.getRequest().getSession().getAttribute("existUser");
		userService.user_delete(user);
		ServletActionContext.getRequest().getSession().setAttribute("existUser", null);
		return "user_delete";
	}

	/**
	 * 注册会员方法
	 */
	public String registMember() {
		String phoneORemail = user.getPhone();
		if (phoneORemail.indexOf("@") != -1) {
			user.setEmail(phoneORemail);
			// user.setPhone(null);
		}
		User member = userService.login(user);
		if (member != null) {
			member.setState("1");// 修改状态为会员
			userService.update(member);
		} else {
			// 未注册用户
			return "false";
		}
		return "success";
	}

	/**
	 * 会员登录
	 */
	public String memberlogin() {
		String phoneORemail = user.getPhone();
		if (phoneORemail.indexOf("@") != -1) {
			user.setEmail(phoneORemail);
		}
		User member = userService.login(user);
		System.out.println("phone: " + member.getPhone());
		System.out.println("state: " + member.getState());
		if (member != null && member.getState().equals("1")) {
			// 存在会员
			ServletActionContext.getRequest().getSession().setAttribute("existUser", member);
			return "success";
		}
		return "false";
	}

	/**
	 * 用户修改个人信息方法
	 */
	public String user_update() {
		String phoneORemail = user.getPhone();
		if (phoneORemail.indexOf("@") != -1) {
			user.setEmail(phoneORemail);
			user.setPhone(null);
		}
		User oldMessage = (User) ServletActionContext.getRequest().getSession().getAttribute("existUser");
		if (user.getPhone() != null) {
			oldMessage.setPhone(user.getPhone());
		} else if (user.getEmail() != null) {
			oldMessage.setEmail(user.getEmail());
		}
		oldMessage.setPassword(user.getPassword());
		userService.update(oldMessage);
		return "success";
	}
}