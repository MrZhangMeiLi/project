package zc.travel.user.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import zc.travel.user.vo.User;

public class UserDao extends HibernateDaoSupport {
	// 注册用户存入数据库代码实现
	public void save(User user) {
		this.getHibernateTemplate().save(user);
	}

	// 用户登录的方法
	public User login(User user) {
		String hql = "from User where phone = ? and password = ? or email = ? and password = ?";
		List<User> list = this.getHibernateTemplate().find(hql, user.getPhone(), user.getPassword(), user.getEmail(),
				user.getPassword());
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	public void user_delete(User user) {
		this.getHibernateTemplate().delete("User", user);

	}

	public void update(User member) {
		this.getHibernateTemplate().update(member);

	}
}
