package zc.travel.user.service;

import org.springframework.transaction.annotation.Transactional;

import zc.travel.user.dao.UserDao;
import zc.travel.user.vo.User;

@Transactional
public class UserService {
	private UserDao userDao;

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public void save(User user) {
		// 将数据存入到数据库
		// user.setUid(UUIDUtils.getUUID());
		user.setState("0");// 非会员状态
		userDao.save(user);
	}

	// 用户登录的方法
	public User login(User user) {
		return userDao.login(user);
	}

	public void user_delete(User user) {
		userDao.user_delete(user);

	}

	public void update(User member) {
		userDao.update(member);

	}

}
