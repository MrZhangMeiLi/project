package zc.travel.sight.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import zc.travel.sight.dao.SightDao;
import zc.travel.sight.vo.Sight;

@Transactional
public class SightService {
	private SightDao sightDao;

	public void setSightDao(SightDao sightDao) {
		this.sightDao = sightDao;
	}

	public List<Sight> findAll(String pname) {
		return sightDao.findAll(pname);
	}

}
