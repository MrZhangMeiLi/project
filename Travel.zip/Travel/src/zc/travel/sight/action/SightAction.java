package zc.travel.sight.action;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import zc.travel.sight.service.SightService;
import zc.travel.sight.vo.Sight;

public class SightAction extends ActionSupport implements ModelDriven<Sight> {
	private Sight sight = new Sight();

	@Override
	public Sight getModel() {
		return sight;
	}

	private SightService sightService;

	public void setSightService(SightService sightService) {
		this.sightService = sightService;
	}

}
