package zc.travel.sight.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import zc.travel.sight.vo.Sight;

public class SightDao extends HibernateDaoSupport {

	public List<Sight> findAll(String pname) {
		List<Sight> lists = this.getHibernateTemplate().find("from Sight where sname = ?", pname);
		return lists;
	}

}
