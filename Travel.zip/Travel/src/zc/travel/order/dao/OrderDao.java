package zc.travel.order.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import zc.travel.hotel.vo.Hotel;
import zc.travel.order.vo.Order;

public class OrderDao extends HibernateDaoSupport {

	public List<Order> finshOrder(String gowhere) {
		String hql = "from Order where gowhere = ?";
		List<Order> lists = this.getHibernateTemplate().find(hql, gowhere);
		return lists;
	}

	public void finshhotelOrder(Hotel hotel) {
		this.getHibernateTemplate().update(hotel);
	}

}
