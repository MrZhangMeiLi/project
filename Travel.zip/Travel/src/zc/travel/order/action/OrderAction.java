package zc.travel.order.action;

import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import zc.travel.hotel.vo.Hotel;
import zc.travel.order.service.OrderService;
import zc.travel.order.vo.Order;

public class OrderAction extends ActionSupport implements ModelDriven<Order> {
	private Order order = new Order();

	@Override
	public Order getModel() {
		return order;
	}

	private Hotel hotel;

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	private OrderService orderService;

	public void setOrderService(OrderService orderService) {
		this.orderService = orderService;
	}

	public String finshhotelOrder() {
		if (ServletActionContext.getRequest().getSession().getAttribute("existUser") == null) {
			return "false";
		} else {
			List<Order> orderlist = (List<Order>) ServletActionContext.getRequest().getSession()
					.getAttribute("orderlists");
			String place = orderlist.get(0).getGpsa();// 入住地点
			String price = orderlist.get(0).getPrice();// 入住金额
			Hotel hotel = (Hotel) ServletActionContext.getRequest().getSession().getAttribute("hotelall");
			hotel.setPlace(place);
			hotel.setPrice(price);
			orderService.finshhotelOrder(hotel);
			return "success";
		}

	}
}
