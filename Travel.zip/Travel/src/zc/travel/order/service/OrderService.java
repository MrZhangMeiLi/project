package zc.travel.order.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import zc.travel.hotel.vo.Hotel;
import zc.travel.order.dao.OrderDao;
import zc.travel.order.vo.Order;

@Transactional
public class OrderService {
	private OrderDao orderDao;

	public void setOrderDao(OrderDao orderDao) {
		this.orderDao = orderDao;
	}

	public List<Order> finshOrder(String gowhere) {
		return orderDao.finshOrder(gowhere);
	}

	public void finshhotelOrder(Hotel hotel) {
		orderDao.finshhotelOrder(hotel);

	}

}
